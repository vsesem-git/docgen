#!/usr/bin/env python3
"""Собрать Word-программы из опубликованного расписания web-kodeks.ru."""
from __future__ import annotations

import argparse
import copy
import json
import re
import sys
from collections import Counter
from copy import deepcopy
from dataclasses import dataclass
from datetime import date, datetime, time, timezone
from pathlib import Path
from urllib.parse import urljoin, urlsplit, urlunsplit

import requests
from bs4 import BeautifulSoup, Tag
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.shared import Pt, RGBColor
from docx.text.paragraph import Paragraph
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


ROOT = Path(__file__).resolve().parent
HOME = 'http://www.web-kodeks.ru/'
HOSTS = {'web-kodeks.ru', 'www.web-kodeks.ru'}
MONTHS = ('января февраля марта апреля мая июня июля августа сентября октября ноября декабря').split()
DATE_PATTERN = re.compile(r'(?<!\d)(\d{1,2})\s+(' + '|'.join(MONTHS) + r')\s+(20\d\d)(?!\d)', re.I)
RANGE_PATTERN = re.compile(r'(\d{1,2}[:.]\d{2})\s*(?:до|[–—−-])\s*(\d{1,2}[:.]\d{2})', re.I)
EMAIL_PATTERN = re.compile(r'[A-Za-z0-9][A-Za-z0-9._%+-]*@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+')
PHONE_PATTERN = re.compile(r'(?:\+7\s*)?\(\d{3}\)\s*\d{3}[\s-]\d{2}[\s-]\d{2}|\+7[ -]?[\d ()-]{10,17}\d')
GREEN = '234B35'


class SourceError(ValueError):
    """Страница не даёт надёжно извлечь обязательные данные."""


@dataclass(frozen=True)
class ListingItem:
    url: str
    title: str = ''
    day: date | None = None
    date_text: str = ''


@dataclass(frozen=True)
class Topic:
    title: str
    details: str


@dataclass(frozen=True)
class Event:
    url: str
    menu_title: str
    title: str
    organizer: str
    kind: str
    with_whom: str
    day: date
    start: time
    end: time
    abstract: str
    audience: str
    speakers: tuple[tuple[str, str], ...]
    topics: tuple[Topic, ...]
    closing: str
    fee: str
    access_and_discounts: str
    format_text: str
    phone: str
    email: str
    warnings: tuple[str, ...]

    @property
    def day_month(self) -> str:
        return f'{self.day.day} {MONTHS[self.day.month - 1]}'

    @property
    def date_ru(self) -> str:
        return f'{self.day_month} {self.day.year} года'

    @property
    def hours(self) -> str:
        return f'{self.start:%H:%M}–{self.end:%H:%M}'

    @property
    def slug(self) -> str:
        return urlsplit(self.url).path.strip('/').split('/')[-1]


def normalize(s: str) -> str:
    s = re.sub(r'\s+', ' ', s).strip()
    return re.sub(r' +([,.;:!?])', r'\1', s)


def proofread(s: str) -> str:
    # Только явные опечатки из расписания. Содержательные факты не заменяются.
    swaps = {
        'обспечение': 'обеспечение',
        'земельно-правововым': 'земельно-правовым',
        'гособронзаказа': 'гособоронзаказа',
        'XML-cхем': 'XML-схем',
        'требования к обустройству и обслуживания': 'требования к обустройству и обслуживанию',
        'Требования к обустройству и обслуживания': 'Требования к обустройству и обслуживанию',
        'при обращения с коммунальными отходами': 'при обращении с коммунальными отходами',
        'Рекомендацию по ведению': 'Рекомендации по ведению',
        'нежилых помещениям': 'нежилых помещений',
        'I-м квартале': 'I квартале',
        'бразузеры': 'браузеры',
        'Google Chromе': 'Google Chrome',
    }
    for old, new in swaps.items():
        s = s.replace(old, new)
    if s.startswith('словия '):
        s = 'У' + s
    return s


def text(node: Tag, omit: str | None = None) -> str:
    if omit:
        node = copy.copy(node)
        for part in node.select(omit):
            part.decompose()
    return proofread(normalize(node.get_text(' ', strip=True)))


def same_site(value: str, base: str = HOME) -> str:
    value = value.strip()
    u = urlsplit(urljoin(base, value))
    if (u.scheme not in {'http', 'https'} or u.hostname not in HOSTS
            or u.username or u.password or u.port not in {None, 80, 443}):
        raise SourceError(f'Ожидалась ссылка на web-kodeks.ru: {value!r}')
    return urlunsplit((u.scheme, u.netloc.lower(), u.path or '/', u.query, ''))


def canonical_event(value: str) -> str:
    u = urlsplit(same_site(value))
    if not u.path.strip('/'):
        raise SourceError('Ожидалась ссылка на карточку вебинара, а не на главную.')
    # Главная сайта публикует карточки на HTTP; не угадываем внешние адреса.
    return urlunsplit(('http', 'www.web-kodeks.ru', u.path.rstrip('/'), u.query, ''))


def session() -> requests.Session:
    s = requests.Session()
    retry = Retry(total=2, connect=2, read=2, status=2, backoff_factor=.5,
                  status_forcelist=(429, 500, 502, 503, 504), allowed_methods={'GET'})
    s.mount('http://', HTTPAdapter(max_retries=retry))
    s.mount('https://', HTTPAdapter(max_retries=retry))
    s.headers['User-Agent'] = 'KodeksWebinarProgram/1.0 (public webinar schedule reader)'
    return s


def download(s: requests.Session, url: str) -> requests.Response:
    for _ in range(4):
        url = same_site(url)
        r = s.get(url, timeout=(6, 20), allow_redirects=False)
        if r.is_redirect:
            url = same_site(r.headers['Location'], base=url)
            continue
        r.raise_for_status()
        return r
    raise SourceError(f'Слишком много переадресаций: {url}')


def listing(s: requests.Session) -> list[ListingItem]:
    home = download(s, HOME)
    html = home.content.decode('utf-8-sig')
    # Именно этот JSON загружает интерфейс «Ближайшие вебинары».
    endpoint = re.search(r'''(?:['"])([\w/.-]*getWebs\.php)(?:['"])''', html, re.I)
    if endpoint:
        raw = download(s, same_site(endpoint[1], base=home.url)).json()
        entries = list(raw.values()) if isinstance(raw, dict) else raw
        if not isinstance(entries, list):
            raise SourceError('Неизвестный формат списка вебинаров.')
        found = []
        for row in entries:
            if not isinstance(row, dict) or not row.get('url'):
                raise SourceError('В списке вебинаров есть элемент без ссылки.')
            day = date.fromisoformat(row['date']) if row.get('date') else None
            found.append(ListingItem(canonical_event(row['url']), normalize(row.get('title', '')),
                                     day, normalize(row.get('dateText', ''))))
    else:
        html = BeautifulSoup(html, 'html.parser')
        courses = html.select_one('ul.js-get-webinars, ul.mainpage__vebinars__menu')
        if courses is None or re.search(r'display\s*:\s*none', courses.get('style', ''), re.I):
            raise SourceError('Актуальный список на главной не найден. Передайте ссылки через --url.')
        found = []
        for a in courses.select('a[href]'):
            label, title = a.select_one('.date'), a.select_one('.underline')
            if label and title:
                found.append(ListingItem(canonical_event(a['href']), text(title), date_text=text(label)))
    if not found:
        raise SourceError('На главной нет опубликованных вебинаров.')
    unique: dict[str, ListingItem] = {}
    for entry in found:
        if entry.url in unique and unique[entry.url] != entry:
            raise SourceError(f'Одна карточка указана для разных записей: {entry.url}')
        unique[entry.url] = entry
    return list(unique.values())


def timestamp(s: str) -> time:
    h, m = (int(x) for x in re.split(r'[:.]', s))
    return time(h, m)


def parse_range(line: str) -> tuple[time, time] | None:
    m = RANGE_PATTERN.search(line)
    return (timestamp(m[1]), timestamp(m[2])) if m else None


def format_summary(soup: BeautifulSoup, hours: tuple[time, time]) -> str:
    paragraphs = [text(n.parent, '.place__title') for n in soup.select('#tab3 + .place .place__title')]
    if not paragraphs:
        return ''
    source = ' '.join(paragraphs)
    repeated_hours = parse_range(source)
    if repeated_hours and repeated_hours != hours:
        raise SourceError('Время в шапке отличается от времени в разделе «Формат».')
    if ('могут заранее' in source and any(v in source for v in ('общий чат', 'общем чате'))
            and 'в начале вебинара' in source and 'через 3 дня' in source
            and 'За день до начала' in source and 'За 20 минут' in source):
        return ('Вопросы можно подготовить заранее и задать в общем чате. Материалы доступны '
                'в начале вебинара, видеозапись — через 3 дня после окончания. Ссылку и инструкцию '
                'пришлют за день до трансляции. Проверить звук и изображение рекомендуют за 20 минут до начала.')
    # Для страниц с другим порядком трансляции оставляем их собственный текст.
    return source


def parse_event(html: bytes | str, item: ListingItem) -> Event:
    if isinstance(html, bytes):
        html = html.decode('utf-8-sig')
    soup = BeautifulSoup(html, 'html.parser')
    mast = soup.select_one('.first-frame__content:has(.first-frame__content__title)')
    if mast is None:
        raise SourceError('Нет заголовка карточки вебинара.')
    full_title = text(mast.select_one('.first-frame__content__title'))
    meta = [text(t) for t in mast.select('.first-frame__content__text')]
    timing = next((m for m in meta if DATE_PATTERN.search(m) and parse_range(m)), '')
    dm, hours = DATE_PATTERN.search(timing), parse_range(timing)
    if not dm or not hours or hours[1] <= hours[0] or 'московск' not in timing.casefold():
        raise SourceError('Не удалось подтвердить полную дату и время трансляции по Москве.')
    day = date(int(dm[3]), MONTHS.index(dm[2].lower()) + 1, int(dm[1]))
    if item.day and item.day != day:
        raise SourceError(f'Дата в списке ({item.day}) не совпадает с карточкой ({day}).')
    if item.date_text and not re.match(rf'^0?{day.day}\s+{MONTHS[day.month - 1]}\b', item.date_text, re.I):
        raise SourceError(f'Дата в списке («{item.date_text}») не совпадает с карточкой ({day}).')

    kind_line = next((m for m in meta if m != timing and 'вебинар' in m.lower()), '')
    kind, _, who = kind_line.partition(' с участием ')
    columns = soup.select('#conception > .layout > .clearfix > .content__half-col')
    if len(columns) < 2:
        raise SourceError('Не найдены аннотация и описание аудитории.')
    abstract, about = (text(n, '.h5') for n in columns[:2])
    audience_text = re.split(r'\s*В работе вебинара\b', about, maxsplit=1)[0]
    audience_match = re.search(r'\b(руководителей и специалистов|специалистов|представителей)\b.*', audience_text, re.I)
    if audience_match:
        audience = 'Для ' + audience_match[0].rstrip('.') + '.'
    else:
        audience = audience_text

    speakers = []
    for n in soup.select('.experts .expert__item'):
        name_n = n.select_one('.expert__item__name')
        role = text(n, '.expert__item__name')
        if name_n and text(name_n) and role:
            speakers.append((text(name_n), role.rstrip(' .;') + '.'))
        elif text(n):
            raise SourceError('В карточке эксперта нет имени или описания должности.')

    topics, closing = [], []
    for n in soup.select('.programm .programm__item'):
        label = n.select_one('.programm__item__title')
        if label is None:
            continue
        name, details = text(label), text(n, '.programm__item__title')
        if re.match(r'^(ответы на вопросы|практические рекомендации)\b', name, re.I) and not details:
            closing.append(name.strip(' .;:').lower())
        elif name:
            topics.append(Topic(name, details))
    if not (full_title and kind and abstract and audience and speakers and topics):
        raise SourceError('Не найден один из обязательных блоков: название, описание, аудитория, эксперты или программа.')

    footer = soup.select_one('div.footer ul.footer__content')
    brand = next((text(n) for n in footer.find_all('li', recursive=False) if 'Кодекс' in text(n)), '') if footer else ''
    legal = re.match(r'^(АНО|ООО|АО)\b', brand)
    if not brand:
        raise SourceError('В подвале карточки не найдено название организатора.')
    organizer = f'{legal[0]} «КЦ „Кодекс“»' if legal else 'КЦ «Кодекс»'

    warnings = []
    fee = extra = phone = email = ''
    for n in soup.select('.conditions .conditions__text__item'):
        h = n.select_one('.conditions__text__title')
        if h is None:
            continue
        heading, details = text(h).casefold(), text(n, '.conditions__text__title')
        if 'стоимост' in heading:
            cost, inclusion, tail = details.partition('Участие в вебинаре включает в себя:')
            fee, extra = cost.strip(), ('В стоимость входит: ' + tail.strip()) if inclusion else ''
        if 'регистрац' in heading:
            pm, em = PHONE_PATTERN.search(details), EMAIL_PATTERN.search(details)
            phone, email = (pm[0] if pm else ''), (em[0] if em else '')
    if not fee:
        warnings.append('На странице не найдена стоимость; в документе она не указана.')
    if not (phone and email):
        warnings.append('На странице не найден телефон или email; добавлена ссылка на карточку.')
    format_text = format_summary(soup, hours)
    return Event(item.url, item.title, full_title, organizer, kind, who, day, *hours, abstract,
                 audience, tuple(speakers), tuple(topics), ' и '.join(dict.fromkeys(closing)),
                 fee, extra, format_text, phone, email, tuple(warnings))


def add(p: Paragraph, value: str, *, bold: bool = False, color: str | None = None, size=11):
    r = p.add_run(value)
    r.font.name = 'Arial Narrow'
    r.font.size = Pt(size)
    r.bold = bold
    if color is not None:
        r.font.color.rgb = RGBColor.from_string(color)
    lang = OxmlElement('w:lang')
    lang.set(qn('w:val'), 'ru-RU')
    r._r.get_or_add_rPr().append(lang)
    return r


def link(p: Paragraph, label: str, url: str) -> None:
    target = p.part.relate_to(url, RT.HYPERLINK, is_external=True)
    outer = OxmlElement('w:hyperlink')
    outer.set(qn('r:id'), target)
    r = add(p, label, bold=True, color=GREEN)
    r.font.underline = True
    outer.append(r._r)
    p._p.append(outer)


def lower_title(s: str) -> str:
    first = s.split(maxsplit=1)[0].strip('«„"')
    return s[:1].lower() + s[1:] if len(first) > 1 and not first.isupper() else s


def full_stop(s: str) -> str:
    return s.rstrip() + ('' if s.endswith(('.', '!', '?')) else '.')


def safe_filename(s: str) -> str:
    s = re.sub(r'[:/\\|]+', ' — ', s)
    return normalize(re.sub(r'["<>?*\x00-\x1f]', '', s)).strip(' .')[:175].rstrip(' .')


def render(event: Event, output: Path, layout: Path, edit: dict) -> None:
    doc = Document(layout)
    ps = {p.text: p for p in doc.paragraphs if p.text}
    title_sentence = event.title[:1] + event.title[1:].lower()
    # При регистре обычного предложения из титула восстанавливаются аббревиатуры.
    for abbr in ('ТКО', 'ЖКХ', 'МКД', 'ВС', 'РФ', 'ГОЗ', 'СНТ', 'НДС', 'УК', 'СЗЗ', 'ВКХ'):
        title_sentence = re.sub(rf'\b{abbr}\b', abbr, title_sentence, flags=re.I)
    replacements = {
        '{{ORGANIZER}}': event.organizer,
        '{{DATE}}': event.date_ru,
        '{{TIME}}': f'{event.hours} МСК',
        '{{HEADER_TOPIC}}': f'{title_sentence}',
        '{{AUDIENCE}}': event.audience,
        '{{FORM_TITLE}}': title_sentence,
        '{{FORM_DATE}}': f'{event.date_ru}, {event.hours} (МСК)',
    }
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    for r in p.runs:
                        if r.text in replacements:
                            r.text = replacements[r.text]
    # Блок аннотации и ведущих наследует абзацное форматирование эталона.
    p = ps['{{ABSTRACT}}'].clear()
    lead = re.match(r'^(К 2027 году|В 2027 году|В течение 2026 года|С 01\.01\.2027)\b', event.abstract)
    if lead:
        add(p, lead[0], bold=True)
        add(p, event.abstract[lead.end():])
    else:
        add(p, event.abstract)
    p = ps['{{INTRO}}'].clear()
    add(p, event.date_ru, bold=True)
    add(p, f' {event.organizer} проведёт {event.kind}')
    add(p, f' с участием {event.with_whom}.' if event.with_whom else '.')
    add(ps['{{TITLE}}'].clear(), event.title, bold=True, color=GREEN, size=13)
    p = ps['{{BENEFIT}}'].clear()
    benefit = edit.get('benefit') or ('разобраться в ключевых вопросах программы: '
                                      + '; '.join(lower_title(t.title) for t in event.topics[:4]) + '.')
    add(p, 'УЧАСТИЕ В ВЕБИНАРЕ ПОЗВОЛИТ', bold=True, color=GREEN)
    add(p, ' ' + benefit)

    for model, records in (('{{EXPERT}}', event.speakers), ('{{TOPIC}}', event.topics)):
        prototype = ps[model]
        for i, entry in enumerate(records, 1):
            e = deepcopy(prototype._p)
            prototype._p.addprevious(e)
            p = Paragraph(e, prototype._parent).clear()
            if model == '{{EXPERT}}':
                add(p, entry[0], bold=True)
                add(p, ' — ' + entry[1])
            else:
                name = edit.get('rename_topics', {}).get(str(i), entry.title)
                add(p, f'{i}. {full_stop(name)}', bold=True)
                if entry.details:
                    add(p, ' ' + entry.details)
        prototype._p.getparent().remove(prototype._p)
    p = ps['{{QUESTIONS}}'].clear()
    if event.closing:
        v = event.closing[:1].upper() + event.closing[1:]
        add(p, f'{len(event.topics) + 1}. {full_stop(v)}', bold=True)
    else:
        p._p.getparent().remove(p._p)

    p = ps['{{CONDITIONS}}'].clear()
    add(p, f'{event.date_ru}, {event.hours} (по московскому времени).', bold=True)
    if event.fee:
        add(p, ' ' + event.fee.replace('в вебинаре –', 'в вебинаре —'), bold=True)
    if event.access_and_discounts:
        add(p, ' ' + event.access_and_discounts)
    p = ps['{{FORMAT}}'].clear()
    if event.format_text:
        add(p, 'Подключение и материалы. ', bold=True)
        add(p, event.format_text)
    else:
        p._p.getparent().remove(p._p)
    p = ps['{{CONTACTS}}'].clear()
    add(p, 'Регистрация: ', bold=True, color=GREEN)
    if event.phone:
        digits = re.sub(r'\D', '', event.phone)
        target = ('+7' + digits if len(digits) == 10 else '+' + digits)
        link(p, event.phone, 'tel:' + target)
        add(p, '  ·  ', bold=True, color=GREEN)
    if event.email:
        link(p, event.email, 'mailto:' + event.email)
        add(p, '  ·  ', bold=True, color=GREEN)
    link(p, 'Страница вебинара', event.url)

    doc.core_properties.title = title_sentence
    doc.core_properties.subject = f'Программа вебинара — {event.date_ru}'
    doc.core_properties.comments = f'Источник содержания: {event.url}'
    doc.core_properties.created = datetime.now(timezone.utc)
    doc.core_properties.modified = doc.core_properties.created
    doc.core_properties.revision = 1
    # Режим xb не перезаписывает уже существующие пользовательские программы.
    with output.open('xb') as dest:
        try:
            doc.save(dest)
        except Exception:
            dest.close()
            output.unlink(missing_ok=True)
            raise


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--url', action='append', default=[], help='отдельная ссылка или код карточки; можно повторять')
    ap.add_argument('--output', type=Path, default=Path('programmy'), help='папка для DOCX (по умолчанию: programmy)')
    ap.add_argument('--from-date', type=date.fromisoformat, help='начало периода включительно (ГГГГ-ММ-ДД)')
    ap.add_argument('--to-date', type=date.fromisoformat, help='конец периода включительно (ГГГГ-ММ-ДД)')
    ap.add_argument('--editorial', type=Path, default=ROOT / 'editorial.json', help='редакторские уточнения, привязанные к дате и карточке')
    args = ap.parse_args(argv)
    if args.from_date and args.to_date and args.from_date > args.to_date:
        ap.error('--from-date должна быть не позже --to-date')
    try:
        edits = json.loads(args.editorial.read_text(encoding='utf-8'))
        if not isinstance(edits, dict) or any(not isinstance(entry, dict) for entry in edits.values()):
            raise SourceError('В редакторском JSON ожидается объект с настройками для каждой даты и карточки.')
        layout = ROOT / 'layout.docx'
        if not layout.is_file():
            raise OSError('Нет layout.docx рядом со скриптом.')
        args.output.mkdir(parents=True, exist_ok=True)
        with session() as s:
            items = listing(s) if not args.url else [ListingItem(canonical_event(v)) for v in args.url]
            results, errors = [], []
            for item in {i.url: i for i in items}.values():
                if item.day and ((args.from_date and item.day < args.from_date) or (args.to_date and item.day > args.to_date)):
                    continue
                try:
                    event = parse_event(download(s, item.url).content, item)
                    if (args.from_date and event.day < args.from_date) or (args.to_date and event.day > args.to_date):
                        continue
                    results.append(event)
                except (requests.RequestException, ValueError, TypeError) as exc:
                    errors.append(f'{item.url}: {exc}')
            count = 0
            stems = {e.url: safe_filename(f'{e.day_month} - {e.menu_title or e.title}') for e in results}
            occurrences = Counter(v.casefold() for v in stems.values())
            for event in sorted(results, key=lambda e: (e.day, e.start, e.url)):
                stem = stems[event.url]
                if occurrences[stem.casefold()] > 1:
                    stem += ' — ' + safe_filename(event.slug)
                destination = args.output / (stem + '.docx')
                try:
                    editorial = edits.get(f'{event.day.isoformat()}/{event.slug}', {})
                    render(event, destination, layout, editorial)
                    count += 1
                    print(f'{event.date_ru}, {event.hours} МСК — {destination.name}')
                    for warning in event.warnings:
                        print(f'  Внимание: {warning}', file=sys.stderr)
                except FileExistsError:
                    errors.append(f'{destination}: файл уже есть; используйте другую папку, чтобы не затереть правки.')
                except (OSError, ValueError, KeyError) as exc:
                    errors.append(f'{destination}: {exc}')
            for error in errors:
                print(f'Ошибка: {error}', file=sys.stderr)
            print(f'Готово: {count} DOCX. Ошибок: {len(errors)}.')
            if not count and not errors:
                print('В выбранном периоде нет опубликованных вебинаров.')
            return 1 if errors else 0
    except (requests.RequestException, OSError, ValueError, TypeError) as exc:
        print(f'Ошибка: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
