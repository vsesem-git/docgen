from pathlib import Path
p=Path('webinar_cmk_generator/gui.py')
s=p.read_text()
def rep(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
def between(a,b,new):
    global s
    i=s.index(a)
    s=s[:i]+new+s[s.index(b,i):]
rep('import io\n','import io\nimport ipaddress\n')
rep('import secrets\n','import secrets\nimport signal\nimport socket\n')
rep('import sqlite3\n','import sqlite3\nimport sys\n')
rep('from datetime import datetime\n','')
rep('from schedule_data import CHECK_TIMES, MOSCOW, ROOT, Schedule, event_key, fetch_schedule, load_snapshot, next_slot','from schedule_data import ROOT, Schedule, event_key, fetch_schedule, load_snapshot')
rep('from storage import Store, data_dir\nfrom telegram_notify import configured as telegram_configured', 'from storage import DEFAULT_WEB_PORT, Store, data_dir, validate_web_port\nfrom telegram_notify import TelegramError\nfrom web_monitor import ControlError, WebMonitor')
rep('        self.store.seed(snapshot)\n','        self.store.seed(snapshot)\n        self.watch = WebMonitor(self.store)\n')
between('    def monitor_payload(', '    def start_scan(', '''    def monitor_payload(self, admin: bool = False) -> dict:
        return self.watch.status(admin)

''')
rep('''    def __init__(self, address: tuple[str, int], app: App):
        super().__init__(address, Handler)
        self.app = app
''','''    def __init__(self, address: tuple[str, int], app: App, *, fixed_port: bool = False):
        self.app = app
        self.fixed_port = fixed_port
        super().__init__(address, Handler)
        self.loopback_only = ipaddress.ip_address(self.server_address[0]).is_loopback
        if self.loopback_only:
            self.app.watch.start()

    def server_close(self) -> None:
        self.app.watch.close()
        super().server_close()
''')
rep("    server_version = 'CMK-GUI/1.1'", "    server_version = 'CMK-GUI/1.2'")
rep('''    def do_HEAD(self) -> None:
        self.do_GET()''','''    def admin_authority(self) -> str | None:
        # A local client or an SSH tunnel, not a reverse proxy/DNS-rebound Host.
        if not self.server.loopback_only or not ipaddress.ip_address(self.client_address[0]).is_loopback:
            return None
        if any(self.headers.get(h) for h in ('Forwarded','X-Forwarded-Host','X-Forwarded-For','X-Forwarded-Proto')):
            return None
        values = self.headers.get_all('Host', [])
        if len(values) != 1:
            return None
        host = values[0].lower()
        match = re.fullmatch(r'(localhost|127(?:\\.[0-9]{1,3}){3})(?::([0-9]{1,5}))?', host)
        if not match or (match[2] is not None and not 1 <= int(match[2]) <= 65535):
            return None
        try:
            if match[1] != 'localhost' and not ipaddress.ip_address(match[1]).is_loopback:
                return None
        except ValueError:
            return None
        return host

    def require_admin(self, *, write: bool = False) -> None:
        host = self.admin_authority()
        if not host:
            raise ApiError('Управление доступно только через локальную панель или SSH-туннель.', 403)
        if write and self.headers.get_all('Origin', []) != ['http://' + host]:
            raise ApiError('Откройте панель по её локальному HTTP-адресу и повторите действие.', 403)

    def settings_payload(self) -> dict:
        return {'admin': self.admin_authority() is not None, 'fixed_port': self.server.fixed_port,
                'active_port': self.server.server_port, 'saved_port': self.app.store.web_port()}

    def set_port(self, value: object) -> None:
        if self.server.fixed_port:
            raise ApiError('Порт задан через --port. Уберите этот параметр, чтобы управлять портом из панели.', 409)
        try:
            port = validate_web_port(value)
        except ValueError as exc:
            raise ApiError(str(exc)) from None
        if port != self.server.server_port:
            try:
                with socket.socket(self.server.address_family) as probe:
                    probe.bind((self.server.server_address[0], port))
            except OSError:
                raise ApiError(f'Порт {port} занят или недоступен. Выберите другой порт.', 409) from None
        self.app.store.set_web_port(port)

    def watch_action(self, data: dict) -> None:
        action, watch = data.get('action'), self.app.watch
        if action == 'pair':
            self.json(watch.begin_pair(data.get('token')), 202)
        elif action == 'test':
            self.json(watch.begin_test(), 202)
        elif action == 'cancel':
            self.json(watch.cancel_task(data.get('id')))
        elif action == 'schedule':
            watch.toggle(data.get('enabled'))
            self.json(self.app.monitor_payload(True))
        elif action == 'check':
            watch.check_now()
            self.json(self.app.monitor_payload(True), 202)
        elif action == 'disconnect':
            watch.disconnect()
            self.json(self.app.monitor_payload(True))
        else:
            raise ApiError('Действие мониторинга не найдено.', 404)

    def do_HEAD(self) -> None:
        self.do_GET()''')
rep('''            elif route == '/api/watchdog':
                self.json(self.app.monitor_payload())''','''            elif route == '/api/watchdog':
                self.json(self.app.monitor_payload(self.admin_authority() is not None))
            elif (task := re.fullmatch(r'/api/watchdog/task/([a-zA-Z0-9_-]+)', route)):
                self.require_admin()
                self.json(self.app.watch.get_task(task[1]))
            elif route == '/api/settings':
                self.json(self.settings_payload())''')
rep('''            elif route == '/api/export':
                self.json(self.app.make_programs(self.read_json()), 201)
            else:''','''            elif route == '/api/export':
                self.json(self.app.make_programs(self.read_json()), 201)
            elif route == '/api/watchdog':
                self.require_admin(write=True)
                self.watch_action(self.read_json())
            elif route == '/api/settings':
                self.require_admin(write=True)
                self.set_port(self.read_json().get('port'))
                self.json(self.settings_payload())
            else:''')
s=s.replace("        except ApiError as exc:\n            self.json({'error': str(exc)}, exc.status)", "        except (ApiError, ControlError) as exc:\n            self.json({'error': str(exc)}, exc.status)\n        except TelegramError as exc:\n            self.json({'error': str(exc)}, 400)")
between('def main() -> None:', "if __name__ == '__main__':", '''def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', default='127.0.0.1', help='интерфейс; по умолчанию только этот компьютер')
    ports = parser.add_mutually_exclusive_group()
    ports.add_argument('--port', type=int, help=f'порт текущего запуска, скрывает изменение из панели; иначе сохранённый или {DEFAULT_WEB_PORT}')
    ports.add_argument('--set-port', type=int, metavar='PORT', help='сохранить порт для будущих запусков, не открывая панель')
    parser.add_argument('--no-browser', action='store_true', help='не открывать вкладку браузера автоматически')
    parser.add_argument('--data-dir', type=Path, help='общая папка истории, расписания и настроек')
    args = parser.parse_args(argv)
    directory = data_dir(args.data_dir)
    if args.set_port is not None:
        try:
            port = validate_web_port(args.set_port)
            Store(directory).set_web_port(port)
        except ValueError as exc:
            parser.error(str(exc))
        except (OSError, sqlite3.Error):
            print('Не удалось сохранить порт. Проверьте права на папку данных.', file=sys.stderr)
            return 1
        print(f'Порт {port} сохранён. Он вступит в силу при следующем запуске панели (без --port).')
        return 0
    if args.port is not None and not 0 <= args.port <= 65535:
        parser.error('Укажите порт от 0 до 65535.')
    try:
        app = App(directory)
        port = args.port if args.port is not None else app.store.web_port()
    except (OSError, ValueError, sqlite3.Error):
        print('Не удалось прочитать настройки или историю. Проверьте папку данных.', file=sys.stderr)
        return 1
    try:
        with Server((args.host, port), app, fixed_port=args.port is not None) as server:
            host = '127.0.0.1' if args.host == '0.0.0.0' else args.host
            url = f'http://{host}:{server.server_port}/'
            print(f'Панель ЦМК запущена: {url}\\nДля остановки нажмите Ctrl+C.', flush=True)
            if not args.no_browser:
                timer = Timer(.35, webbrowser.open, args=(url,))
                timer.daemon = True
                timer.start()

            def stop_on_signal(_signum, _frame):
                raise KeyboardInterrupt

            previous = signal.signal(signal.SIGTERM, stop_on_signal)
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                pass
            finally:
                signal.signal(signal.SIGTERM, previous)
    except OSError:
        print(f'Не удалось открыть панель на {args.host}:{port}. Проверьте, что порт свободен, или задайте другой через --set-port.', file=sys.stderr)
        return 1
    finally:
        app.pool.shutdown(wait=False, cancel_futures=True)
    return 0


''')
rep("if __name__ == '__main__':\n    main()", "if __name__ == '__main__':\n    raise SystemExit(main())")
p.write_text(s)
