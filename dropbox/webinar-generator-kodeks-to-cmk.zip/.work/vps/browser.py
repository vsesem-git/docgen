from dataclasses import replace
from datetime import date,timedelta
from pathlib import Path
from socket import socket
from tempfile import TemporaryDirectory
from threading import Event
from time import sleep
from unittest.mock import patch
from playwright.sync_api import expect,sync_playwright

from check_web import test_server,until
from schedule_data import Schedule, load_snapshot, utc_stamp
from telegram_notify import CONFIG, TelegramError
from watchdog import check_once, TEST_MESSAGE

shots=Path('.work/vps')
secret='123456:'+'browser_fixture_only_'*2
fresh_event=replace(load_snapshot().entries[-1], url='http://www.web-kodeks.ru/test-cmk-vps',
                    day=max(date.today(),load_snapshot().entries[-1].day)+timedelta(days=2),menu_title='Новая карточка для проверки')
seed=load_snapshot()
verified=Schedule((*seed.entries,fresh_event),seed.home,utc_stamp())
confirm=Event()
sent=[]

class DemoBot:
    def __init__(self, key):
        assert key==secret
    def pair_private(self, on_code, *, cancelled):
        on_code('cmk_test_bot','CMK-A11B22C33D')
        for i in range(400):
            if cancelled(): raise TelegramError('Привязка отменена.')
            if confirm.wait(.015): return 919191
        raise TelegramError('Код просрочен.')
    def send(self, chat, text): sent.append((chat,text))

def stub_check(store, **kwargs):
    return check_once(store,scan=lambda:verified,bot_factory=DemoBot,**kwargs)

with TemporaryDirectory() as d, patch('web_monitor.Bot',DemoBot),patch('web_monitor.check_once',side_effect=stub_check),sync_playwright() as pw:
  with test_server(d) as (app,s):
    browser=pw.chromium.launch()
    endpoint=f'http://127.0.0.1:{s.server_port}/'
    errors=[]
    pg=browser.new_page(viewport={'width':1440,'height':1024},locale='ru-RU',accept_downloads=True)
    pg.on('pageerror',lambda e:errors.append(str(e)))
    pg.goto(endpoint)
    expect(pg.locator('#events-body tr')).to_have_count(16)
    pg.get_by_role('button',name='Мониторинг',exact=True).click()
    expect(pg.locator('#monitor-state')).to_have_text('Расписание приостановлено')
    expect(pg.locator('#monitor-restricted')).to_be_hidden()
    token=pg.get_by_label('Токен от BotFather')
    expect(token).to_be_enabled()
    token.fill(secret); pg.get_by_role('button',name='Привязать бота',exact=True).click()
    expect(pg.get_by_text('CMK-A11B22C33D',exact=True)).to_be_visible()
    expect(token).to_have_value('')
    expect(pg.locator('#pair-bot')).to_have_attribute('href','https://t.me/cmk_test_bot')
    assert not (Path(d)/CONFIG).exists()
    pg.screenshot(path=shots/'pairing.png',animations='disabled')
    pg.get_by_role('button',name='Отменить привязку').click()
    expect(pg.locator('#monitor-feedback')).to_contain_text('Операция отменена')
    assert not sent
    token.fill(secret); pg.get_by_role('button',name='Привязать бота',exact=True).click()
    expect(pg.locator('#pair-code')).to_have_text('CMK-A11B22C33D')
    confirm.set()
    expect(pg.locator('#monitor-telegram')).to_have_text('Чат подключён')
    expect(pg.locator('#monitor-feedback')).to_contain_text('Тестовое сообщение отправлено')
    assert sent==[(919191,TEST_MESSAGE)]
    pg.get_by_role('button',name='Отправить тест',exact=True).click()
    expect(pg.locator('#monitor-feedback')).to_contain_text('Telegram подтвердил отправку')
    assert sent==[(919191,TEST_MESSAGE)]*2
    pg.get_by_role('button',name='Включить расписание',exact=True).click()
    expect(pg.locator('#monitor-state')).to_have_text('Расписание включено')
    assert app.store.web_monitor_enabled()
    pg.get_by_role('button',name='Проверить сейчас',exact=True).click()
    expect(pg.locator('#monitor-note')).to_contain_text('Уведомлено о карточках: 1',timeout=12_000)
    assert len(sent)==3 and 'Новая карточка для проверки' in sent[-1][1]
    pg.get_by_role('button',name='Проверить сейчас',exact=True).click()
    expect(pg.locator('#monitor-note')).to_contain_text('Нет новых карточек',timeout=12_000)
    assert len(sent)==3
    pg.get_by_role('button',name='Приостановить расписание').click()
    expect(pg.locator('#monitor-state')).to_have_text('Расписание приостановлено')
    assert not app.store.web_monitor_enabled()
    pg.get_by_role('button',name='Закрыть мониторинг',exact=True).click()
    expect(pg.locator('.badge-new')).to_have_text('Новое')
    pg.get_by_role('button',name='Настройки сервера').click()
    field=pg.get_by_label('Новый порт (1024–65535)')
    expect(field).to_be_enabled()
    with socket() as dummy:
        dummy.bind(('127.0.0.1',0)); dummy.listen(); port=dummy.getsockname()[1]
        field.fill(str(port)); pg.get_by_role('button',name='Сохранить порт').click()
        expect(pg.locator('#port-feedback')).to_contain_text('занят')
    field.fill(str(port)); pg.get_by_role('button',name='Сохранить порт').click()
    expect(pg.locator('#port-feedback')).to_contain_text(f'Порт {port} сохранён')
    assert app.store.web_port()==port
    expect(pg.locator('#active-port')).to_have_text(str(s.server_port))
    pg.screenshot(path=shots/'port.png',animations='disabled')
    pg.get_by_role('button',name='Закрыть настройки',exact=True).click()
    pg.get_by_role('button',name='Сформировать Word',exact=True).click()
    expect(pg.get_by_role('link',name='Скачать Word',exact=True)).to_be_visible()
    expect(pg.get_by_role('link',name='Скачать ZIP',exact=True)).to_be_visible()
    mobile=browser.new_page(viewport={'width':320,'height':780},locale='ru-RU',is_mobile=True,has_touch=True)
    mobile.goto(endpoint)
    expect(mobile.locator('#events-body tr')).to_have_count(17)
    assert mobile.evaluate('document.documentElement.scrollWidth')==320
    mobile.get_by_role('button',name='Мониторинг',exact=True).tap()
    expect(mobile.get_by_role('button',name='Отправить тест')).to_be_enabled()
    mobile.screenshot(path=shots/'mobile-monitor.png',animations='disabled')
    assert not errors,errors
  with test_server(d,port=port) as (app,s):
    after=browser.new_page(locale='ru-RU')
    after.goto(f'http://127.0.0.1:{port}/')
    after.get_by_role('button',name='Мониторинг',exact=True).click()
    expect(after.locator('#monitor-telegram')).to_have_text('Чат подключён')
    after.on('dialog',lambda dialog: dialog.accept())
    after.get_by_role('button',name='Отвязать бота').click()
    expect(after.locator('#monitor-telegram')).to_have_text('Чат не подключён')
    assert not (Path(d)/CONFIG).exists()
    browser.close()
print('Browser: Telegram pairing/cancellation/rerun, simulated notifications, manual schedule, new highlight, valid port and restart, preserved export, and 320px — OK')
