from pathlib import Path

def file(name):
    global p,s
    p=Path('webinar_cmk_generator/ui')/name
    s=p.read_text()
def rep(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
def between(a,b,new):
    global s
    i=s.index(a)
    s=s[:i]+new+s[s.index(b,i):]

file('index.html')
rep('''    <symbol id="i-archive"''','''    <symbol id="i-settings" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M10 3h4l.6 2.4 1.5.8 2.4-.7 2 3.5-1.8 1.7v1.7l1.8 1.7-2 3.5-2.4-.7-1.5.8L14 21h-4l-.6-2.3-1.5-.8-2.4.7-2-3.5L5.3 13v-1.7L3.5 9.6l2-3.5 2.4.7 1.5-.8z"/></symbol>
    <symbol id="i-copy" viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></symbol>
    <symbol id="i-archive"''')
rep('''        <button type="button" class="button button-help" id="open-help"''','''        <button type="button" class="button button-help settings-button" id="open-settings" aria-label="Настройки сервера" title="Настройки сервера" aria-haspopup="dialog"><svg class="icon"><use href="#i-settings"/></svg><span>Настройки</span></button>
        <button type="button" class="button button-help" id="open-help"''')
between('  <dialog id="monitor-dialog"', '  <div id="toast"', '''  <dialog id="monitor-dialog" class="dialog monitor-dialog" aria-labelledby="monitor-heading">
    <div class="dialog-head"><div><p class="eyebrow dialog-kicker">ПРОВЕРКА РАСПИСАНИЯ</p><h2 id="monitor-heading">Мониторинг Telegram</h2></div><form method="dialog"><button type="submit" class="button button-icon" aria-label="Закрыть мониторинг"><svg class="icon"><use href="#i-close"/></svg></button></form></div>
    <div class="dialog-body monitor-body">
      <p class="admin-notice" id="monitor-restricted" hidden><svg class="icon"><use href="#i-shield"/></svg><span>Здесь доступен просмотр. Для управления откройте панель локально или через SSH-туннель.</span></p>
      <div class="monitor-overview">
        <div class="monitor-summary" id="monitor-summary">
          <strong id="monitor-state" role="status">Проверяем состояние…</strong>
          <span id="monitor-last"></span><span id="monitor-next"></span><span id="monitor-note"></span>
        </div>
        <div class="monitor-timebox"><span class="eyebrow">ЕЖЕДНЕВНО · МСК</span><div class="monitor-times" id="monitor-times"><span>07:00</span><span>13:30</span><span>20:00</span></div></div>
      </div>
      <section class="control-section" aria-labelledby="monitor-controls-heading">
        <div><h3 id="monitor-controls-heading">Автопроверка сайта</h3><p>Сайт проверяет служба на компьютере или VPS. Вкладку можно закрыть.</p></div>
        <div class="control-actions"><button type="button" id="monitor-toggle" class="button button-outline" disabled><svg class="icon"><use href="#i-clock"/></svg><span>Включить расписание</span></button><button type="button" id="monitor-check-now" class="button button-outline" disabled><svg class="icon"><use href="#i-refresh"/></svg><span>Проверить сейчас</span></button></div>
      </section>
      <section class="control-section" aria-labelledby="telegram-heading">
        <div class="control-title"><div><h3 id="telegram-heading">Привязка бота</h3><p>Чат получает дату, тему и ссылку на новые вебинары.</p></div><span class="telegram-pill" id="monitor-telegram">Проверяем…</span></div>
        <p id="telegram-env-note" class="help-note" hidden>Привязка задана через окружение службы. Для замены через панель уберите переменные CMK_TELEGRAM_*.</p>
        <form id="telegram-form" method="post" autocomplete="off">
          <label for="telegram-token">Токен от BotFather</label>
          <div class="control-input-row"><input id="telegram-token" type="password" maxlength="125" autocomplete="new-password" placeholder="Вставьте токен" autocapitalize="none" spellcheck="false" required disabled><button type="submit" id="telegram-connect" class="button button-primary" disabled>Привязать бота</button></div>
        </form>
        <div class="pair-box" id="pair-box" hidden>
          <p>Откройте <a id="pair-bot" href="#" target="_blank" rel="noopener noreferrer"></a>, нажмите «Запустить» и отправьте код в личном чате:</p>
          <div class="pair-code-row"><code id="pair-code"></code><button type="button" id="pair-copy" class="button button-outline"><svg class="icon"><use href="#i-copy"/></svg><span>Скопировать</span></button></div>
          <p class="subtle" id="pair-remaining"></p>
        </div>
        <p class="control-feedback" id="monitor-feedback" role="status" hidden></p>
        <div class="control-actions telegram-actions">
          <button type="button" id="telegram-test" class="button button-outline" disabled hidden>Отправить тест</button>
          <button type="button" id="telegram-disconnect" class="button button-quiet" disabled hidden>Отвязать бота</button>
          <button type="button" id="telegram-cancel" class="button button-quiet" disabled hidden>Отменить привязку</button>
        </div>
      </section>
    </div>
    <div class="dialog-footer align-right"><form method="dialog"><button type="submit" class="button button-outline">Закрыть</button></form></div>
  </dialog>
  <dialog id="settings-dialog" class="dialog help-dialog settings-dialog" aria-labelledby="settings-heading">
    <div class="dialog-head"><div><p class="eyebrow dialog-kicker">ДОСТУП К ПАНЕЛИ</p><h2 id="settings-heading">Настройки сервера</h2></div><form method="dialog"><button type="submit" class="button button-icon" aria-label="Закрыть настройки"><svg class="icon"><use href="#i-close"/></svg></button></form></div>
    <div class="dialog-body">
      <div class="ports-summary"><div><span>Сейчас на сервере</span><strong id="active-port">—</strong></div><div><span>Порт в настройках</span><strong id="saved-port">—</strong></div></div>
      <form id="port-form" method="post"><label for="server-port">Новый порт (1024–65535)</label><div class="control-input-row"><input id="server-port" type="number" inputmode="numeric" min="1024" max="65535" step="1" required disabled><button type="submit" id="save-port" class="button button-primary" disabled>Сохранить порт</button></div></form>
      <p class="help-note port-help" id="port-help">Загружаем параметры…</p>
      <p class="control-feedback" id="port-feedback" role="status" hidden></p>
    </div>
    <div class="dialog-footer align-right"><form method="dialog"><button type="submit" class="button button-outline">Закрыть</button></form></div>
  </dialog>
''')
p.write_text(s)

file('app.js')
rep("  'monitor-telegram', 'monitor-last', 'monitor-next', 'monitor-note', 'toast', 'toast-icon', 'toast-text', 'toast-close'", """  'monitor-telegram', 'monitor-last', 'monitor-next', 'monitor-note', 'monitor-restricted', 'monitor-toggle',
  'monitor-check-now', 'monitor-feedback', 'telegram-form', 'telegram-token', 'telegram-connect', 'telegram-test',
  'telegram-disconnect', 'telegram-cancel', 'telegram-env-note', 'pair-box', 'pair-bot', 'pair-code', 'pair-copy',
  'pair-remaining', 'open-settings', 'settings-dialog', 'port-form', 'server-port', 'save-port', 'active-port',
  'saved-port', 'port-help', 'port-feedback', 'toast', 'toast-icon', 'toast-text', 'toast-close'""")
between('async function refreshMonitor()', 'let refreshing = false;', '''const monitorUi = { data: null, pending: false, task: null, pollId: null, loading: false };
const taskActive = task => ['starting', 'waiting', 'finishing', 'cancelling'].includes(task?.state);

function feedback(id, message = '', error = false) {
  const box = el[id];
  box.textContent = message;
  box.hidden = !message;
  box.classList.toggle('is-error', error);
}

function renderMonitor(data) {
  const wasChecking = monitorUi.data?.checking;
  monitorUi.data = data;
  el['monitor-restricted'].hidden = Boolean(data.admin);
  el['monitor-times'].replaceChildren(...data.times.map(t => make('span', '', t)));
  el['monitor-state'].textContent = data.checking ? 'Проверяем расписание…'
    : data.managed && data.enabled ? 'Расписание включено'
    : data.external ? 'Запущен отдельный мониторинг'
    : data.managed ? 'Расписание приостановлено' : 'Автопроверка не запущена';
  el['monitor-summary'].classList.toggle('is-running', data.running || data.checking);
  el['monitor-telegram'].textContent = (data.configured ? 'Чат подключён' : 'Чат не подключён')
    + (data.pending ? ` · в очереди: ${data.pending}` : '');
  el['monitor-telegram'].classList.toggle('is-connected', data.configured);
  el['monitor-last'].textContent = data.last_finish ? `Последняя проверка: ${checkedTime.format(new Date(data.last_finish))} МСК` : 'Проверок ещё не было';
  el['monitor-next'].textContent = data.next_check ? `Следующая: ${checkedTime.format(new Date(data.next_check))} МСК` : '';
  el['monitor-note'].textContent = data.last_note || '';
  el['monitor-note'].classList.toggle('is-error', data.last_ok === false);
  if (data.task && !monitorUi.pollId) followTelegramTask(data.task);
  renderMonitorControls();
  if (wasChecking && !data.checking) refreshStored();
}

function renderMonitorControls() {
  const opt = monitorUi.data;
  const locked = !opt?.admin || monitorUi.pending;
  const job = monitorUi.task;
  const busy = taskActive(job);
  el['monitor-toggle'].disabled = locked || !opt?.managed;
  el['monitor-toggle'].querySelector('span').textContent = opt?.enabled ? 'Приостановить расписание' : 'Включить расписание';
  el['monitor-check-now'].disabled = locked || !opt?.managed || Boolean(opt.checking);
  el['telegram-token'].disabled = el['telegram-connect'].disabled = locked || busy || Boolean(opt?.env_managed);
  el['telegram-connect'].textContent = opt?.configured ? 'Перепривязать бота' : 'Привязать бота';
  el['telegram-env-note'].hidden = !opt?.env_managed;
  el['telegram-form'].hidden = Boolean(opt?.env_managed);
  el['telegram-test'].hidden = !opt?.configured;
  el['telegram-test'].disabled = locked || busy;
  el['telegram-disconnect'].hidden = !opt?.configured || Boolean(opt?.env_managed);
  el['telegram-disconnect'].disabled = locked || busy;
  el['telegram-cancel'].hidden = !(job?.kind === 'pair' && ['starting','waiting','cancelling'].includes(job.state));
  el['telegram-cancel'].disabled = locked || job?.state === 'cancelling';
}

async function refreshMonitor() {
  if (monitorUi.loading) return;
  monitorUi.loading = true;
  try {
    renderMonitor(await api('/api/watchdog'));
  } catch {
    el['monitor-state'].textContent = 'Не удалось получить состояние. Откройте окно заново.';
  } finally {
    monitorUi.loading = false;
  }
}

function renderTelegramTask(task) {
  monitorUi.task = task;
  el['pair-box'].hidden = task.state !== 'waiting';
  if (!el['pair-box'].hidden) {
    el['pair-bot'].href = task.bot_url;
    el['pair-bot'].textContent = '@' + task.username;
    el['pair-code'].textContent = task.code;
    el['pair-remaining'].textContent = `Код действует ещё ${task.remaining} с.`;
  } else {
    el['pair-code'].textContent = '';
    el['pair-bot'].removeAttribute('href');
  }
  const message = task.state === 'waiting' ? '' : task.message;
  if (el['monitor-feedback'].textContent !== message) feedback('monitor-feedback', message, task.state === 'error');
  renderMonitorControls();
}

async function followTelegramTask(start) {
  renderTelegramTask(start);
  if (monitorUi.pollId === start.id) return;
  if (!taskActive(start)) {
    refreshMonitor();
    return;
  }
  monitorUi.pollId = start.id;
  let task = start;
  try {
    while (taskActive(task) && monitorUi.pollId === start.id) {
      await delay(1050);
      task = await api('/api/watchdog/task/' + encodeURIComponent(start.id));
      if (monitorUi.pollId !== start.id) break;
      renderTelegramTask(task);
    }
  } catch (error) {
    renderTelegramTask({ ...task, state: 'error', message: error.message || 'Не удалось получить состояние привязки.' });
  } finally {
    if (monitorUi.pollId === start.id) monitorUi.pollId = null;
    refreshMonitor();
  }
}

async function monitorAction(action, params = {}, success = '') {
  if (!monitorUi.data?.admin || monitorUi.pending) return;
  monitorUi.pending = true;
  feedback('monitor-feedback');
  renderMonitorControls();
  try {
    const result = await api('/api/watchdog', {action, ...params});
    if (result.id) followTelegramTask(result);
    else {
      renderMonitor(result);
      feedback('monitor-feedback', success);
    }
  } catch (error) {
    feedback('monitor-feedback', error.message || 'Не удалось выполнить действие.', true);
  } finally {
    monitorUi.pending = false;
    renderMonitorControls();
  }
}

el['open-monitor'].addEventListener('click', () => {
  el['monitor-dialog'].showModal();
  refreshMonitor();
});
el['monitor-dialog'].addEventListener('close', () => { el['telegram-token'].value = ''; });
el['monitor-toggle'].addEventListener('click', () => {
  const enabled = !monitorUi.data?.enabled;
  monitorAction('schedule', {enabled}, enabled ? 'Расписание сохранено и включено.' : 'Следующие автоматические проверки приостановлены.');
});
el['monitor-check-now'].addEventListener('click', () => monitorAction('check', {}, 'Проверка запущена. Результат появится выше.'));
el['telegram-form'].addEventListener('submit', e => {
  e.preventDefault();
  const secret = el['telegram-token'].value.trim();
  el['telegram-token'].value = '';
  if (secret) monitorAction('pair', {token: secret});
});
el['telegram-test'].addEventListener('click', () => monitorAction('test'));
el['telegram-disconnect'].addEventListener('click', () => {
  if (window.confirm('Отвязать этот чат? История вебинаров останется.')) monitorAction('disconnect', {}, 'Чат отвязан. Новые уведомления останутся в очереди.');
});
el['telegram-cancel'].addEventListener('click', () => {
  if (monitorUi.task) monitorAction('cancel', {id: monitorUi.task.id});
});
el['pair-copy'].addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(el['pair-code'].textContent);
    toast('Код скопирован.');
  } catch {
    const range = document.createRange();
    range.selectNodeContents(el['pair-code']);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
  }
});

let serverSettings = null;
let settingsBusy = false;
function renderSettings(data) {
  serverSettings = data;
  el['active-port'].textContent = data.active_port;
  el['saved-port'].textContent = data.saved_port;
  el['server-port'].value = data.saved_port;
  el['server-port'].disabled = el['save-port'].disabled = !data.admin || data.fixed_port || settingsBusy;
  el['port-help'].textContent = !data.admin ? 'Изменение доступно из локальной панели или через SSH-туннель.'
    : data.fixed_port ? 'Порт задан параметром --port. Запустите панель без этого параметра, чтобы менять сохранённый порт.'
    : 'Новый порт вступит в силу после перезапуска панели. На VPS: sudo systemctl restart cmk-webinars. Затем обновите назначение SSH-туннеля.';
}

el['open-settings'].addEventListener('click', async () => {
  el['settings-dialog'].showModal();
  el['server-port'].disabled = el['save-port'].disabled = true;
  feedback('port-feedback');
  try {
    renderSettings(await api('/api/settings'));
  } catch (error) {
    feedback('port-feedback', error.message || 'Не удалось прочитать настройки.', true);
  }
});
el['port-form'].addEventListener('submit', async e => {
  e.preventDefault();
  if (settingsBusy || !serverSettings?.admin || serverSettings.fixed_port) return;
  const port = el['server-port'].valueAsNumber;
  if (!Number.isInteger(port) || port < 1024 || port > 65535) {
    feedback('port-feedback', 'Укажите целое число от 1024 до 65535.', true);
    return;
  }
  settingsBusy = true;
  el['server-port'].disabled = el['save-port'].disabled = true;
  try {
    const result = await api('/api/settings', {port});
    renderSettings(result);
    feedback('port-feedback', port === result.active_port ? `Порт ${port} сохранён и уже используется.`
      : `Порт ${port} сохранён. Сейчас панель остаётся на порту ${result.active_port}.`);
  } catch (error) {
    feedback('port-feedback', error.message || 'Не удалось сохранить порт.', true);
  } finally {
    settingsBusy = false;
    el['server-port'].disabled = el['save-port'].disabled = !serverSettings?.admin || serverSettings.fixed_port;
  }
});

''')
rep('''setInterval(() => {
  refreshStored();
  if (el['monitor-dialog'].open) refreshMonitor();
}, 30_000);''','''setInterval(refreshStored, 30_000);
setInterval(() => { if (el['monitor-dialog'].open) refreshMonitor(); }, 3000);''')
p.write_text(s)
