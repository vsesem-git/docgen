from contextlib import contextmanager
from dataclasses import replace
from datetime import date, datetime, timedelta
from http.client import HTTPConnection
from pathlib import Path
from socket import socket
from tempfile import TemporaryDirectory
from threading import Thread
from time import monotonic, sleep
from unittest.mock import patch
import json
import os
import unittest

from gui import App, Server, main
from schedule_data import Schedule, load_snapshot, utc_stamp, MOSCOW
from watchdog import check_once

@contextmanager
def test_server(directory, host='127.0.0.1', port=0, **options):
    a = App(Path(directory)); s = Server((host,port),a,**options)
    t = Thread(target=s.serve_forever,daemon=True); t.start()
    try:
        yield a,s
    finally:
        s.shutdown(); s.server_close(); t.join(); a.pool.shutdown()


def req(port, path, payload=None, headers=None):
    conn=HTTPConnection('127.0.0.1',port,timeout=8)
    try:
        conn.request('GET' if payload is None else 'POST',path,json.dumps(payload).encode() if payload is not None else None,
                     {'Content-Type':'application/json',**(headers or {})})
        response=conn.getresponse()
        data=response.read()
        return response.status, dict(response.getheaders()), (json.loads(data) if 'application/json' in response.headers.get('Content-Type','') else data)
    finally: conn.close()


def until(predicate,timeout=4):
    end=monotonic()+timeout
    while monotonic()<end:
        if value:=predicate(): return value
        sleep(.025)
    raise AssertionError('condition not reached')


class Web(unittest.TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.d=Path(self.tmp.name)
        self.fake_token='123456:'+'unit_testing_only_'*2

    def test_tunnel_and_csrf(self):
        with test_server(self.d) as (app,s):
            p=s.server_port
            effective_authority='127.0.0.1:17860'
            code,_,d=req(p,'/api/watchdog',headers={'Host':effective_authority})
            self.assertTrue(d['admin'] and d['managed'] and not d['enabled'])
            for bad in [{}, {'Origin':'https://unrelated.example'}, {'Host':'attacker.example:17860','Origin':'http://attacker.example:17860'},
                        {'Host':effective_authority,'Origin':'http://'+effective_authority,'X-Forwarded-For':'192.0.2.1'}]:
                self.assertEqual(403,req(p,'/api/watchdog',{'action':'pair','token':self.fake_token},bad)[0])
            auth={'Host':effective_authority,'Origin':'http://'+effective_authority}
            self.assertEqual(200,req(p,'/api/watchdog',{'action':'schedule','enabled':True},auth)[0])
            self.assertTrue(app.store.web_monitor_enabled())
            self.assertFalse(req(p,'/api/watchdog',headers={'Host':'rebind.example'})[2]['admin'])
            self.assertEqual(403,req(p,'/api/watchdog/task/absent',headers={'Host':'rebind.example'})[0])
            c,headers,_=req(p,'/')
            self.assertEqual(200,c)
            self.assertIn("frame-ancestors 'none'",headers['Content-Security-Policy'])
        with test_server(self.d,'0.0.0.0') as (app,s):
            p=s.server_port
            self.assertFalse(req(p,'/api/watchdog')[2]['admin'])
            self.assertFalse(req(p,'/api/watchdog')[2]['managed'])
            self.assertEqual(403,req(p,'/api/watchdog',{'action':'test'},{'Origin':f'http://127.0.0.1:{p}'})[0])
            self.assertNotIn('frame-ancestors',req(p,'/')[1]['Content-Security-Policy'])

    def test_port_validation_persists_and_fixed_is_locked(self):
        with test_server(self.d) as (app,s):
            p=s.server_port; local={'Origin':f'http://127.0.0.1:{p}'}
            with socket() as busy:
                busy.bind(('127.0.0.1',0)); busy.listen()
                occupied=busy.getsockname()[1]
                self.assertEqual(409,req(p,'/api/settings',{'port':occupied},local)[0])
            self.assertEqual(400,req(p,'/api/settings',{'port':True},local)[0])
            self.assertEqual(400,req(p,'/api/settings',{'port':80},local)[0])
            c,_,saved=req(p,'/api/settings',{'port':occupied},local)
            self.assertEqual((200,p,occupied),(c,saved['active_port'],saved['saved_port']))
        with test_server(self.d, port=occupied) as (a,s):
            self.assertEqual(a.store.web_port(), s.server_port)
        with test_server(self.d, fixed_port=True) as (a,s):
            self.assertTrue(req(s.server_port,'/api/settings')[2]['fixed_port'])
            self.assertEqual(409,req(s.server_port,'/api/settings',{'port':occupied},{'Origin':f'http://127.0.0.1:{s.server_port}'})[0])

    def test_schedule_after_restart_deduplicates_slot(self):
        events=load_snapshot()
        live=Schedule(events.entries,events.home,utc_stamp())
        tried=[]
        def stub(store,**kwargs):
            tried.append(1)
            return check_once(store,scan=lambda: live, **kwargs)
        class AtSlot:
            @staticmethod
            def now(tz): return datetime(2026,11,18,7,0,20,tzinfo=MOSCOW)
        from storage import Store
        Store(self.d).set_web_monitor_enabled(True)
        with patch('web_monitor.datetime',AtSlot),patch('web_monitor.check_once',side_effect=stub):
            with test_server(self.d) as (a,s):
                until(lambda: a.store.latest())
                until(lambda: a.store.monitor()['last_ok'])
            with test_server(self.d) as (a,s):
                self.assertTrue(req(s.server_port,'/api/watchdog')[2]['enabled'])
                self.assertTrue(req(s.server_port,'/api/watchdog')[2]['running'])
                sleep(.12)
                self.assertEqual([1],tried)

    def test_port_offline_command(self):
        self.assertEqual(0,main(['--data-dir',str(self.d),'--set-port','19090']))
        from storage import Store
        self.assertEqual(19090,Store(self.d).web_port())

if __name__=='__main__': unittest.main(verbosity=2)
