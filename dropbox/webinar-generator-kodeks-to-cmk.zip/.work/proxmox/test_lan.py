import base64, http.client, json, os, re, socket, ssl, subprocess, sys, tempfile, threading, time
from importlib.machinery import SourceFileLoader
from importlib.util import spec_from_loader, module_from_spec
from pathlib import Path
from unittest.mock import patch
from gui import App, Server
from lan_gateway import LanGateway, lan_ipv4, PROXY_HEADER

l=SourceFileLoader('deploy_lan','webinar_cmk_generator/deploy/cmk-lan-config')
m=module_from_spec(spec_from_loader(l.name,l)); sys.modules[m.__name__]=m; l.exec_module(m)


def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1',0)); return s.getsockname()[1]


def test():
    ip, port='192.168.55.20',free_port()
    # This fixture is not a person's credential.
    pw='validation-fixture-password-123'
    bcrypt=subprocess.check_output(['caddy','hash-password'],input=pw+'\n',text=True).strip()
    cfg=m.Config(ip,port,'cmk',bcrypt,'b7'*32)
    m.validate(cfg)
    host=f'{ip}:{port}'
    with tempfile.TemporaryDirectory() as d, patch.dict(os.environ,cfg.env):
        temp=Path(d)
        assert LanGateway.from_env().origin==cfg.origin
        app=App(temp/'data')
        with Server(('127.0.0.1',0),app,fixed_port=True) as backend:
            thread=threading.Thread(target=backend.serve_forever,daemon=True); thread.start()
            try:
                cf=temp/'Caddyfile'
                # Sandbox has no RFC1918 address. Bind the test TLS listener to loopback,
                # but keep the configured Host + certificate + browser Origin as the actual LAN IP.
                cf.write_text(cfg.caddyfile().replace('bind '+ip, 'bind 127.0.0.1')
                              .replace('reverse_proxy 127.0.0.1:17860','reverse_proxy 127.0.0.1:'+str(backend.server_port)))
                ca=temp/'caddy/pki/authorities/local/root.crt'
                log=temp/'caddy.log'
                with log.open('w+') as logf, subprocess.Popen(['caddy','run','--config',str(cf),'--adapter','caddyfile'],
                      env={**os.environ,'XDG_DATA_HOME':d,'XDG_CONFIG_HOME':d}, stdout=logf,stderr=logf,text=True) as process:
                    try:
                        auth='Basic '+base64.b64encode(f'cmk:{pw}'.encode()).decode()
                        def req(path, headers=None, data=None):
                            context=ssl.create_default_context(cafile=str(ca))
                            con=http.client.HTTPSConnection(ip,port,timeout=7,context=context)
                            con._create_connection=lambda addr, timeout, src: socket.create_connection(('127.0.0.1',port),timeout,src)
                            try:
                                con.request('GET' if data is None else 'POST', path,json.dumps(data) if data is not None else None,
                                            {'Content-Type':'application/json',**(headers or {})})
                                r=con.getresponse()
                                raw=r.read()
                                value=json.loads(raw) if 'application/json' in r.getheader('Content-Type','') else raw
                                return r.status,value,r.getheader('WWW-Authenticate','')
                            finally: con.close()

                        end=time.monotonic()+12
                        while time.monotonic()<end:
                            if process.poll() is not None: raise RuntimeError(log.read_text().replace(cfg.key,'[hidden]'))
                            try:
                                if ca.exists() and req('/api/settings')[0]==401: break
                            except OSError as e: last = str(e)
                            time.sleep(.16)
                        else:
                            print('ca exists:',ca.exists(), 'last:',locals().get('last'))
                            print('diagnostic files:',*[str(f.relative_to(temp)) for f in temp.rglob('*') if f.is_file()])
                            print(log.read_text().replace(cfg.key,'[hidden]'))
                            raise RuntimeError('No HTTPS listener with trusted CA and challenge')
                        unauth,_,challenge=req('/',{PROXY_HEADER:cfg.key})
                        assert unauth==401 and challenge.startswith('Basic')
                        code,data,_=req('/api/settings',{'Authorization':auth,PROXY_HEADER:'wrong'})
                        assert code==200 and data['admin'] and data['lan_url']==cfg.origin and data['active_port']==backend.server_port,data
                        code,body,_=req('/api/catalog',{'Authorization':auth})
                        assert code==200 and len(body['events'])==16
                        origin={'Authorization':auth,'Origin':cfg.origin}
                        assert req('/api/watchdog',{'Authorization':auth,'Origin':'https://other.private'},{'action':'schedule','enabled':True})[0]==403
                        assert req('/api/watchdog',origin,{'action':'schedule','enabled':True})[0]==200
                        assert app.store.web_monitor_enabled()
                        assert req('/api/settings',origin,{'port':9443})[0]==409
                        assert req('/api/watchdog',origin,{'action':'schedule','enabled':False})[0]==200
                        (event,)=body['events'][:1]
                        assert req('/api/export',origin,{'catalog':body['id'],'event_ids':[event['id']]})[0]==201
                        # Wrong/missing proxy marker cannot be used even from the backend port with an opt-in host.
                        h=http.client.HTTPConnection('127.0.0.1',backend.server_port,timeout=5)
                        h.request('GET','/api/settings',headers={'Host':host,'X-Forwarded-Proto':'https',PROXY_HEADER:'00'*32})
                        r=h.getresponse(); assert r.status==403; r.read(); h.close()
                        print('Actual Caddy: trusted IP TLS, unauthenticated/forged 401, signed proxy, Origin checks, monitor, DOCX export, and locked external port — OK')
                    finally:
                        process.terminate(); process.wait(timeout=9)
            finally:
                backend.shutdown(); thread.join(); app.pool.shutdown()

test()
