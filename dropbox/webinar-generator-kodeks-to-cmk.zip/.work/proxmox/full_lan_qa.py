import base64
import grp
import http.client
import io
import json
import os
import pwd
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
from contextlib import ExitStack
from importlib.machinery import SourceFileLoader
from importlib.util import spec_from_loader, module_from_spec
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile

ROOT = Path('webinar_cmk_generator').resolve()
sys.path.insert(0, str(ROOT))
loader = SourceFileLoader('lan_config_fixture', str(ROOT/'deploy/cmk-lan-config'))
module = module_from_spec(spec_from_loader(loader.name, loader))
sys.modules[loader.name] = module
loader.exec_module(module)

ip, client, other = '192.168.55.20','192.168.55.21','198.51.100.22'
password = 'fixture-password-only-A2'
raw_hash = subprocess.check_output(['caddy','hash-password'],input=password+'\n',text=True).strip()
first = module.Config(ip,8443,'cmk',raw_hash,'aa'*32)
second = module.replace(first,port=9443)
creds = 'Basic '+base64.b64encode(f'cmk:{password}'.encode()).decode()
causer, appuser = map(pwd.getpwnam, ['caddy','nobody'])

with tempfile.TemporaryDirectory(prefix='cmk-pve-smoke-') as t, ExitStack() as close:
    tmp=Path(t); tmp.chmod(0o755)
    etc=tmp/'etc'; db=tmp/'web-state'; proxy=tmp/'caddy-state'
    for path, user in [(db,appuser),(proxy,causer)]:
        path.mkdir(mode=0o700)
        os.chown(path,user.pw_uid,user.pw_gid)
    ca=proxy/'caddy/pki/authorities/local/root.crt'
    src=tmp/'app'; shutil.copytree(ROOT,src,ignore=shutil.ignore_patterns('__pycache__'))
    running=[]; logs=[]

    def stop():
        for p in running[:][::-1]:
            if p.poll() is None:
                p.terminate()
                try: p.wait(timeout=8)
                except subprocess.TimeoutExpired: p.kill(); p.wait()
        running.clear()

    def start(cmd, user, name, env):
        log=tmp/f'{len(logs)}-{name}.log'; logs.append(log)
        with log.open('wb') as f:
            running.append(subprocess.Popen(cmd, cwd=src, env={**os.environ,**env},
                stdout=f, stderr=subprocess.STDOUT, user=user.pw_uid, group=user.pw_gid,
                extra_groups=[], umask=0o077))

    def ctl(command,*units,strict=True):
        assert command in ('daemon-reload','restart','enable','disable'), command
        if command in ('restart','disable'): stop()
        if command=='restart':
            env=dict(line.split('=',1) for line in module.ENV.read_text().splitlines())
            start([sys.executable,str(src/'gui.py'),'--host','127.0.0.1','--port','17860','--no-browser','--data-dir',str(db)],
                  appuser,'backend',{**env,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1'})
            start(['/usr/bin/caddy','run','--config',str(module.CADDYFILE),'--adapter','caddyfile'],
                  causer,'caddy',{**env,'XDG_DATA_HOME':str(proxy),'XDG_CONFIG_HOME':str(proxy)})
        return True

    def req(cfg,path,auth=creds,origin=None,data=None,headers=None,source=client):
        context=ssl.create_default_context(cafile=str(ca))
        h=http.client.HTTPSConnection(cfg.ip,cfg.port,context=context,timeout=7,source_address=(source,0))
        hdr={'Content-Type':'application/json',**(headers or {})}
        if auth: hdr['Authorization']=auth
        if origin: hdr['Origin']=origin
        try:
            h.request('POST' if data is not None else 'GET',path,
                body=json.dumps(data).encode() if data is not None else None,headers=hdr)
            r=h.getresponse(); raw=r.read()
            return r.status,(json.loads(raw) if 'application/json' in r.getheader('Content-Type','') else raw)
        finally: h.close()

    close.callback(stop)
    with patch.multiple(module,ROOT=etc,CONFIG=etc/'config.json',ENV=etc/'gateway.env',CADDYFILE=etc/'Caddyfile',CA=ca,systemctl=ctl):
        try:
            module.apply(first,None)
            assert module.read_config()==first
            assert (module.ENV.stat().st_mode & 0o777)==0o600
            assert (module.CADDYFILE.stat().st_mode & 0o777)==0o640
            base, _ = req(first,'/api/catalog',auth=None,headers={'X-CMK-Lan-Key':first.key})
            assert base==401
            assert req(first,'/api/catalog',auth='Basic Y206d3Jvbmc=')[0]==401
            assert req(first,'/api/catalog',source=other)[0]==403
            assert req(first,'/api/settings',headers={'X-CMK-Lan-Key':'f'*64,'X-Forwarded-Proto':'http'})[1]['admin'] is True
            assert req(first,'/',origin=first.origin)[0]==200
            code,status=req(first,'/api/watchdog'); assert code==200
            assert status['times']==['07:00','13:30','20:00'], status
            assert req(first,'/api/watchdog',origin='https://192.168.55.21:8443',data={'action':'schedule','enabled':True})[0]==403
            assert req(first,'/api/watchdog',origin=first.origin,data={'action':'schedule','enabled':True})[0]==200
            assert req(first,'/api/watchdog',origin=first.origin,data={'action':'schedule','enabled':False})[0]==200
            status,catalog=req(first,'/api/catalog'); assert status==200 and len(catalog['events'])==16
            event=next(i for i in catalog['events'] if i['id'].split('/')[-1].lower()=='med')
            code, result=req(first,'/api/export',origin=first.origin,data={'catalog':catalog['id'],'event_ids':[event['id']]})
            assert code==201,result
            stem='18 декабря - Оплата труда медицинских работников в 2027 году'
            assert len(result['documents'])==1 and result['documents'][0]['filename']==stem+'.docx', result
            code, word=req(first,result['documents'][0]['url']); assert code==200
            code, archive=req(first,result['zip']['url']); assert code==200
            with ZipFile(io.BytesIO(archive)) as z:
                assert z.testzip() is None and z.namelist()==[stem+'/',f'{stem}/{stem}.docx']
                assert z.read(f'{stem}/{stem}.docx')==word
            try: socket.create_connection((ip,17860),timeout=.3)
            except ConnectionRefusedError: pass
            else: raise AssertionError('internal port reachable on LAN IP')
            cert=ca.read_bytes()
            module.apply(second,first)
            assert module.read_config()==second and ca.read_bytes()==cert
            try: req(first,'/api/catalog')
            except ConnectionRefusedError: pass
            else: raise AssertionError('old HTTPS port still reachable')
            assert req(second,'/api/settings')[1]['lan_url']==second.origin
            assert req(second,'/api/watchdog',origin=first.origin,data={'action':'schedule','enabled':True})[0]==403
            _,catalog=req(second,'/api/catalog')
            from urllib.parse import urlencode
            code, saved=req(second,'/api/saved?'+urlencode({'catalog':catalog['id'],'event':event['id']}))
            assert code==200 and saved==word
            with socket.socket() as blocked:
                blocked.bind((ip,9555)); blocked.listen()
                try: module.apply(module.replace(second,port=9555),second)
                except module.SetupError: assert module.read_config()==second
                else: raise AssertionError('occupied HTTPS port unexpectedly allowed')
            assert req(second,'/api/catalog')[0]==200
            from playwright.sync_api import sync_playwright, expect
            home=tmp/'browser-home'; certdb=home/'.pki/nssdb'; certdb.mkdir(parents=True)
            certinfo='sql:'+str(certdb)
            subprocess.run(['certutil','-N','-d',certinfo,'--empty-password'],check=True)
            subprocess.run(['certutil','-A','-d',certinfo,'-n','CMK Fixture CA','-t','C,,','-i',str(ca)],check=True)
            os.environ['PLAYWRIGHT_BROWSERS_PATH']='/home/user/.cache/ms-playwright'
            with sync_playwright() as pw:
                browser=pw.chromium.launch(args=['--no-sandbox','--no-proxy-server'],env={**os.environ,'HOME':str(home),'XDG_CONFIG_HOME':str(home/'.config')})
                context=browser.new_context(http_credentials={'username':'cmk','password':password},ignore_https_errors=False)
                page=context.new_page()
                errors=[]; page.on('pageerror',lambda err: errors.append(str(err)))
                response=page.goto(second.origin+'/',wait_until='domcontentloaded',timeout=12000)
                assert response and response.status==200
                page.locator('#open-monitor').click()
                expect(page.locator('#monitor-toggle')).to_be_enabled(timeout=8000)
                expect(page.locator('#monitor-restricted')).to_be_hidden()
                page.locator('#monitor-toggle').click()
                expect(page.locator('#monitor-toggle')).to_contain_text('Приостановить')
                page.locator('#monitor-toggle').click()
                expect(page.locator('#monitor-toggle')).to_contain_text('Включить')
                page.get_by_label('Закрыть мониторинг',exact=True).click()
                page.locator('#open-settings').click()
                expect(page.locator('#port-form')).to_be_hidden()
                expect(page.locator('#active-port')).to_have_text(str(second.port))
                expect(page.locator('#saved-port')).to_have_text('17860')
                assert not errors,errors
                browser.close()
            print('Chromium with imported CA and real TLS verification: login, monitor enable/pause, locked LAN port display — OK')
            print('Private network namespace: unchanged Caddyfile, service users, trusted TLS, RFC1918 source, 401/403, Origin, exact DOCX/ZIP and history, HTTPS move 8443→9443, unchanged CA, occupied port refusal — all passed')
        except BaseException:
            print('Service logs:')
            for p in logs:
                print(p.name,p.read_text().replace(first.key,'[hidden]').replace(raw_hash,'[hidden]'))
            raise
