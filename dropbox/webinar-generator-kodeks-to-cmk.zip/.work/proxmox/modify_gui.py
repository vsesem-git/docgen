from pathlib import Path
p=Path('webinar_cmk_generator/gui.py'); s=p.read_text()
def rep(a,b):
    global s
    assert s.count(a)==1,(a,s.count(a))
    s=s.replace(a,b)
def between(a,b,new):
    global s
    k=s.index(a); s=s[:k]+new+s[s.index(b,k):]
rep('from generate_webinars import safe_filename\n','from generate_webinars import safe_filename\nfrom lan_gateway import LanGateway, PROXY_HEADER\n')
rep('''        self.app = app
        self.fixed_port = fixed_port
        super().__init__(address, Handler)
        self.loopback_only = ipaddress.ip_address(self.server_address[0]).is_loopback
        if self.loopback_only:''','''        self.app = app
        self.fixed_port = fixed_port
        self.lan = LanGateway.from_env()
        super().__init__(address, Handler)
        self.loopback_only = ipaddress.ip_address(self.server_address[0]).is_loopback
        if self.lan and not self.loopback_only:
            self.server_close()
            raise ValueError('За LAN-прокси сама панель должна слушать только 127.0.0.1.')
        if self.loopback_only:''')
rep("server_version = 'CMK-GUI/1.2'","server_version = 'CMK-GUI/1.3'")
between('    def admin_authority(', '    def set_port(', '''    def admin_origin(self) -> str | None:
        if not self.server.loopback_only or not ipaddress.ip_address(self.client_address[0]).is_loopback:
            return None
        values = self.headers.get_all('Host', [])
        if len(values) != 1:
            return None
        host = values[0].lower()
        gateway = self.server.lan
        if gateway and gateway.authorizes(self.headers, host):
            return gateway.origin
        # Without the opt-in, a proxy header is not authorization.
        if any(h in self.headers for h in (PROXY_HEADER,'Forwarded','X-Forwarded-Host','X-Forwarded-For','X-Forwarded-Proto')):
            return None
        match = re.fullmatch(r'(localhost|127(?:\\.[0-9]{1,3}){3})(?::([0-9]{1,5}))?', host)
        if not match or (match[2] is not None and not 1 <= int(match[2]) <= 65535):
            return None
        try:
            if match[1] != 'localhost' and not ipaddress.ip_address(match[1]).is_loopback:
                return None
        except ValueError:
            return None
        return 'http://' + host

    def require_admin(self, *, write: bool = False) -> None:
        origin = self.admin_origin()
        if not origin:
            raise ApiError('Откройте локальную панель, SSH-туннель или защищённый HTTPS-адрес в LAN.', 403)
        if write and self.headers.get_all('Origin', []) != [origin]:
            raise ApiError('Повторите действие с основного адреса панели.', 403)

    def settings_payload(self) -> dict:
        origin = self.admin_origin()
        result = {'admin': origin is not None, 'fixed_port': self.server.fixed_port or self.server.lan is not None,
                  'active_port': self.server.server_port, 'saved_port': self.app.store.web_port()}
        if self.server.lan and origin:
            result.update(lan_port=self.server.lan.port, lan_url=self.server.lan.origin)
        return result

''')
rep('''    def set_port(self, value: object) -> None:
        if self.server.fixed_port:''','''    def set_port(self, value: object) -> None:
        if self.server.lan:
            raise ApiError('В режиме LAN HTTPS-порт меняется через cmk-lan-config port НОМЕР_ПОРТА.', 409)
        if self.server.fixed_port:''')
rep('''            parts = urlsplit(self.path)
            route = parts.path''','''            parts = urlsplit(self.path)
            route = parts.path
            if self.server.lan:
                self.require_admin()''')
rep('''                self.json(self.app.monitor_payload(self.admin_authority() is not None))''','''                self.json(self.app.monitor_payload(self.admin_origin() is not None))''')
rep('''            route = urlsplit(self.path).path
            if route''','''            route = urlsplit(self.path).path
            if self.server.lan:
                self.require_admin(write=True)
            if route''')
rep('''    except OSError:
        print(f'Не удалось открыть панель на {args.host}:{port}. Проверьте, что порт свободен, или задайте другой через --set-port.', file=sys.stderr)''','''    except ValueError as exc:
        print(f'Ошибка запуска: {exc}', file=sys.stderr)
        return 1
    except OSError:
        print(f'Не удалось открыть панель на {args.host}:{port}. Проверьте, что порт свободен, или задайте другой через --set-port.', file=sys.stderr)''')
p.write_text(s)
