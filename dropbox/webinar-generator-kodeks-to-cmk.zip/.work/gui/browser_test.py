from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
from docx import Document
from playwright.sync_api import sync_playwright, expect

root = Path('.work/gui')
base = 'http://127.0.0.1:7860/'
with sync_playwright() as pw:
    browser = pw.chromium.launch()
    page = browser.new_page(viewport={'width': 1380, 'height': 960}, locale='ru-RU', accept_downloads=True)
    js_errors, console_errors = [], []
    page.on('pageerror', lambda e: js_errors.append(str(e)))
    page.on('console', lambda msg: console_errors.append(msg.text) if msg.type=='error' and '400' not in msg.text else None)
    page.goto(base)
    rows = page.locator('#events-body tr')
    expect(rows).to_have_count(16)
    count = page.locator('#selected-count')
    expect(count).to_have_text('1')
    expect(page.locator('#catalog-status')).to_contain_text('Снимок от 18.11.2026')
    page.get_by_role('button', name='Справка', exact=True).click()
    expect(page.get_by_role('dialog', name='Как работать с панелью')).to_be_visible()
    page.get_by_role('button', name='Понятно').click()
    expect(page.locator('#help-dialog')).to_be_hidden()
    page.get_by_role('button', name='Смотреть программу').click()
    expect(page.locator('#program-dialog-body > ol > li')).to_have_count(9)
    expect(page.locator('#program-dialog-body > ul > li')).to_have_count(4)
    page.get_by_role('button', name='Закрыть программу').click()
    expect(page.locator('#program-dialog')).to_be_hidden()
    page.get_by_role('button', name='Сформировать Word').click()
    docx_link = page.get_by_role('link', name='Скачать Word')
    expect(docx_link).to_be_visible()
    with page.expect_download() as download:
        docx_link.click()
    docx = download.value
    print('Downloaded from UI:',docx.suggested_filename)
    assert docx.suggested_filename == '20 ноября - Новые условия подключения к сетям ЖКХ.docx'
    d = Document(docx.path()); assert len(d.tables)==3
    search = page.get_by_role('searchbox', name='Поиск вебинаров')
    search.fill(' 26.11.2026 ')
    expect(rows).to_have_count(1)
    expect(rows.first).to_contain_text('Санитарно-защитные зоны')
    expect(page.locator('#selection-hint')).to_contain_text('скрыто фильтрами: 1')
    search.fill('КЛИМАТ июль')
    expect(rows).to_have_count(0)
    expect(page.locator('#table-empty')).to_contain_text('По этим фильтрам')
    page.get_by_role('button', name='Очистить фильтры').click()
    expect(rows).to_have_count(16)
    page.get_by_role('button', name='Период', exact=True).click()
    page.get_by_label('Дата начала').fill('2026-12-11')
    page.get_by_label('Дата окончания').fill('2026-12-22')
    expect(rows).to_have_count(5)
    page.get_by_label('Дата окончания').fill('2026-11-15')
    expect(page.locator('#date-error')).to_be_visible()
    expect(rows).to_have_count(0)
    page.get_by_role('button', name='Сбросить даты').click()
    expect(rows).to_have_count(16)
    page.get_by_role('button', name='Период', exact=True).click()
    page.get_by_role('button', name='Снять выбор').click()
    expect(count).to_have_text('0')
    expect(page.get_by_role('button', name='Сформировать Word')).to_be_disabled()
    page.get_by_role('button', name='Вне главной').click()
    expect(rows).to_have_count(7)
    expect(rows.last).to_have_attribute('data-event','http://www.web-kodeks.ru/prom')
    page.get_by_role('checkbox', name='Выбрать все показанные вебинары').check()
    expect(count).to_have_text('7')
    page.get_by_role('button', name='Сформировать Word').click()
    zip_link = page.get_by_role('link', name='Скачать ZIP')
    expect(zip_link).to_be_visible()
    with page.expect_download() as download:
        zip_link.click()
    zip_file = download.value
    print('Downloaded from UI:',zip_file.suggested_filename)
    with ZipFile(zip_file.path()) as z:
        assert len(z.namelist())==7 and z.testzip() is None
        for filename in z.namelist():
            d=Document(BytesIO(z.read(filename)))
            assert len(d.tables)==3 and any('Ирина' in p.text for p in d.paragraphs)
    zip_file.save_as(root/'browser_test_bundle.zip')
    print('Filters/date validation, selection, docx/zip, detail and help: OK')
    # Error does not erase the list or choices.
    page.get_by_text('Один вебинар', exact=True).click()
    page.get_by_role('button', name='Обновить с сайта').click()
    expect(page.locator('#scan-status')).to_contain_text('укажите ссылку')
    source = page.locator('#start-url')
    source.fill('https://example.org/tpk')
    page.get_by_role('button', name='Обновить с сайта').click()
    expect(page.locator('#scan-status')).to_contain_text('Укажите ссылку на карточку web-kodeks.ru')
    expect(rows).to_have_count(7)
    expect(count).to_have_text('7')
    # Live single card from a fully pasted URL; do not follow its neighbors.
    source.fill('http://www.web-kodeks.ru/iten')
    page.get_by_role('button', name='Обновить с сайта').click()
    expect(page.locator('#catalog-status')).to_contain_text('Обновлено с сайта', timeout=60_000)
    expect(rows).to_have_count(1)
    expect(rows.first).to_have_attribute('data-event','http://www.web-kodeks.ru/iten')
    expect(count).to_have_text('1')
    print('Live single /iten and source validation: OK')
    # Start a new chain from a slug instead of the home page.
    page.get_by_text('По цепочке', exact=True).click()
    source.fill('mkd')
    page.get_by_role('button', name='Обновить с сайта').click()
    expect(rows).to_have_count(2, timeout=60_000)
    expect(rows.first).to_have_attribute('data-event','http://www.web-kodeks.ru/mkd')
    expect(rows.last).to_have_attribute('data-event','http://www.web-kodeks.ru/prom')
    print('Live custom chain /mkd → /prom: OK')
    assert not js_errors, js_errors
    assert not console_errors, console_errors
    page.close()
