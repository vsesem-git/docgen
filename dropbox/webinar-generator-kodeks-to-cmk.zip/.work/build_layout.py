from pathlib import Path
from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.shared import Cm, Pt, RGBColor
from docx.text.paragraph import Paragraph

# Adapt the newest approved programme without changing the Dropbox original.
# The layout retains the approved page, theme, main blocks and table geometry;
# the unrelated brand, private form fields and old event data are removed.
d = Document('.work/refs/template.docx')
brand, topic, form = d.tables
ps = list(d.paragraphs)
G = '234B35'
S = '51665A'
LINE = 'C6D5C9'
BG = 'EAF3E8'


def paragraph(p, text, size=11, color=None, bold=False, align=None):
    p.clear()
    r = p.add_run(text)
    r.font.name = 'Arial Narrow'
    r.font.size = Pt(size)
    r.bold = bold
    if color:
        r.font.color.rgb = RGBColor.from_string(color)
    if align is not None:
        p.alignment = align
    return p


def prval(parent, tag, attrs):
    n = parent.find(qn('w:' + tag))
    if n is None:
        n = OxmlElement('w:' + tag)
        parent.append(n)
    for k, v in attrs.items():
        n.set(qn('w:' + k), str(v))
    return n


def table_widths(t, widths):
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    for col, size in zip(t.columns, widths):
        col.width = Cm(size)
    for row in t.rows:
        start = 0
        for tc in row._tr.tc_lst:
            span = tc.grid_span
            tc.width = Cm(sum(widths[start:start+span]))
            start += span
    prval(t._tbl.tblPr, 'tblW', {'w': Cm(sum(widths)).twips, 'type': 'dxa'})


def borders(t, edges, color=LINE):
    b = prval(t._tbl.tblPr, 'tblBorders', {})
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        prval(b, edge, {'val': 'single' if edge in edges else 'nil',
                        'sz': 6, 'space': 0, 'color': color})


def margins(t, top=95, bottom=95, left=110, right=110):
    m = prval(t._tbl.tblPr, 'tblCellMar', {})
    for k, n in dict(top=top, bottom=bottom, left=left, right=right).items():
        prval(m, k, {'w': n, 'type': 'dxa'})


def compact(p, after=0, before=0, line=1.):
    fmt = p.paragraph_format
    fmt.space_before = Pt(before)
    fmt.space_after = Pt(after)
    fmt.line_spacing = line
    fmt.widow_control = True
    fmt.keep_with_next = False
    fmt.page_break_before = False


# A text masthead identifies the published organizer, not the author of the sample.
header = d.add_table(rows=1, cols=2)
brand._tbl.addprevious(header._tbl)
brand._tbl.getparent().remove(brand._tbl)
table_widths(header, (11.9, 6.5))
borders(header, ('bottom',), '234B35')
margins(header, top=0, bottom=108, left=0, right=0)
a, b = header.rows[0].cells
for c in (a, b):
    c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    prval(c._tc.getparent().get_or_add_trPr(), 'cantSplit', {})
compact(paragraph(a.paragraphs[0], '{{ORGANIZER}}', 19, G, True), after=4)
compact(paragraph(a.add_paragraph(), 'ПРОГРАММА ВЕБИНАРА', 9, S, True))
compact(paragraph(b.paragraphs[0], '{{DATE}}', 12, G, True, WD_ALIGN_PARAGRAPH.RIGHT), after=3)
compact(paragraph(b.add_paragraph(), '{{TIME}}', 10, S, False, WD_ALIGN_PARAGRAPH.RIGHT))
compact(ps[0]); ps[0].paragraph_format.line_spacing = Pt(3)

# Retain the topic/audience table from the approved Word document in normal flow.
for n in topic._tbl.xpath('./w:tblPr/w:tblpPr|./w:tblPr/w:tblInd'):
    n.getparent().remove(n)
table_widths(topic, (9.75, 8.65)); margins(topic); borders(topic, ('top','bottom','left','right','insideV'))
for c, label, slot in zip(topic.rows[0].cells, ('О ВЕБИНАРЕ', 'ДЛЯ КОГО'), ('{{HEADER_TOPIC}}', '{{AUDIENCE}}')):
    c.text = ''
    c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
    compact(paragraph(c.paragraphs[0], label, 9, G, True), after=3)
    compact(paragraph(c.add_paragraph(), slot, 11, None, True, WD_ALIGN_PARAGRAPH.LEFT))
    prval(c._tc.get_or_add_tcPr(), 'shd', {'val':'clear', 'fill':'F6F9F5'})

# The filled reference becomes reusable run/paragraph prototypes.
slots = {2:'{{ABSTRACT}}', 3:'{{INTRO}}', 4:'{{TITLE}}', 5:'{{BENEFIT}}', 7:'{{EXPERT}}',
         12:'{{TOPIC}}', 22:'{{QUESTIONS}}', 24:'{{CONDITIONS}}', 25:'{{CONTACTS}}'}
# Format notes belong within participation conditions, before the contacts.
format_node = OxmlElement('w:p')
ps[24]._p.addnext(format_node)
format_p = Paragraph(format_node, d)
paragraph(format_p, '{{FORMAT}}')
compact(format_p, before=1, after=4)
for idx, slot in slots.items():
    ps[idx].clear().add_run(slot)
for idx in list(range(8,11)) + list(range(13,22)):
    ps[idx]._p.getparent().remove(ps[idx]._p)
# Avoid breaks introduced by template paragraphs other than natural pagination.
for p in d.paragraphs:
    p.paragraph_format.page_break_before = False
    p.paragraph_format.widow_control = True
for idx in (4, 5, 6, 11, 23, 26, 27):
    ps[idx].paragraph_format.keep_with_next = True
ps[5].paragraph_format.space_before = Pt(5)
ps[5].paragraph_format.space_after = Pt(5)
ps[1].paragraph_format.space_before = Pt(8)
ps[1].paragraph_format.space_after = Pt(8)
paragraph(ps[27], 'Для нескольких участников добавьте отдельные строки с ФИО и должностью.', 10, S, False, WD_ALIGN_PARAGRAPH.LEFT)

# Use the registration table, but keep only the fields requested on the source page.
rows = list(form.rows)
for i in (4, 6, 7, 8, 9, 10, 11, 12, 14):
    rows[i]._tr.getparent().remove(rows[i]._tr)
# Merge the consecutive participant fields into independent rows so neither row splits.
for row in (rows[2], rows[3]):
    tc0, tc1, tc2 = row._tr.tc_lst
    for tc in (tc0, tc1):
        for child in tc.xpath('./w:tcPr/w:vMerge'):
            child.getparent().remove(child)
    tc1.grid_span = 2
    row._tr.remove(tc2)
for row, (label, value) in zip(form.rows, (
    ('Название вебинара','{{FORM_TITLE}}'), ('Дата и время','{{FORM_DATE}}'),
    ('ФИО участника',''), ('Должность участника',''),
    ('Полное наименование организации',''), ('Телефон и электронная почта',''),
)):
    c0, c1, _ = row.cells
    for c in (c0, c1):
        c.text = ''
        c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    compact(paragraph(c0.paragraphs[0], label, 10, G, True), after=0)
    compact(paragraph(c1.paragraphs[0], value, 11), after=0)
    for c in (c0, c1):
        c.paragraphs[0].paragraph_format.keep_with_next = True
    prval(c0._tc.get_or_add_tcPr(), 'shd', {'val':'clear', 'fill':'F6F9F5'})
    prval(row._tr.get_or_add_trPr(), 'cantSplit', {})
    prval(row._tr.get_or_add_trPr(), 'trHeight', {'val': '400', 'hRule': 'atLeast'})
for cell in form.rows[-1].cells:
    cell.paragraphs[0].paragraph_format.keep_with_next = False
table_widths(form, (5.60, 3.0, 9.8)); margins(form, top=95, bottom=95); borders(form, ('top','bottom','left','right','insideH','insideV'))

# Remove superseded branding data and external template links from the copied package.
for element in list(d.settings.element.xpath('./w:attachedTemplate|./w:docVars')):
    element.getparent().remove(element)
for rel in list(d.part._settings_part.rels.values()):
    if rel.is_external:
        del d.part._settings_part.rels[rel.rId]
for rel in list(d.part.rels.values()):
    if rel.is_external or rel.reltype.rsplit('/',1)[-1] in ('customXml','image'):
        del d.part.rels[rel.rId]
for name in ('author','last_modified_by','comments','identifier','keywords','category','version','content_status'):
    setattr(d.core_properties, name, '')
pkg = d.part.package
blank = Document().part.package
clean_app = next(rel.target_part for rel in blank.rels.values() if rel.reltype == RT.EXTENDED_PROPERTIES)
for rid, rel in list(pkg.rels.items()):
    if rel.reltype == RT.EXTENDED_PROPERTIES:
        del pkg.rels[rid]
pkg.relate_to(clean_app, RT.EXTENDED_PROPERTIES)
d.core_properties.title = 'Шаблон программы вебинара'
d.core_properties.subject = 'Программы по опубликованному расписанию'
d.sections[0].top_margin = Cm(0.88)
out = Path('webinar_generator/layout.docx')
d.save(out)
print(out, out.stat().st_size)
