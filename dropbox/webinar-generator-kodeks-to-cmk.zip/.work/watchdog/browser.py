import io
from dataclasses import replace
from datetime import date, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Thread
from zipfile import ZipFile
from playwright.sync_api import expect, sync_playwright
from docx import Document
from gui import App, Server
from schedule_data import Schedule, load_snapshot, utc_stamp

stem='18 декабря - Оплата труда медицинских работников в 2027 году'
shots=Path('.work/watchdog')
with TemporaryDirectory() as d, sync_playwright() as pw:
    snapshot=load_snapshot()
    actual=snapshot.entries
    app=App(Path(d))
    server=Server(('127.0.0.1',0),app)
    thread=Thread(target=server.serve_forever,daemon=True); thread.start()
    try:
        endpoint=f'http://127.0.0.1:{server.server_port}/'
        browser=pw.chromium.launch()
        desktop=browser.new_page(viewport={'width':1440,'height':1060},locale='ru-RU',accept_downloads=True)
        page_errors=[]
        desktop.on('pageerror',lambda error:page_errors.append(str(error)))
        desktop.goto(endpoint)
        rows=desktop.locator('#events-body tr')
        expect(rows).to_have_count(16)
        expect(desktop.locator('#todo-count')).to_have_text('16')
        expect(desktop.locator('#done-count')).to_have_text('0')
        desktop.get_by_role('button',name='Снять выбор').click()
        search=desktop.get_by_role('searchbox',name='Поиск вебинаров')
        search.fill('18 декабря')
        expect(rows).to_have_count(1)
        rows.first.get_by_role('checkbox').check()
        desktop.get_by_role('button',name='Сформировать Word').click()
        word=desktop.get_by_role('link',name='Скачать Word',exact=True)
        archive=desktop.get_by_role('link',name='Скачать ZIP',exact=True)
        expect(word).to_be_visible()
        expect(archive).to_be_visible()
        with desktop.expect_download() as wd: word.click()
        with desktop.expect_download() as zd: archive.click()
        wd,zd=wd.value,zd.value
        assert wd.suggested_filename==stem+'.docx' and zd.suggested_filename==stem+'.zip'
        content=Path(wd.path()).read_bytes()
        assert len(Document(io.BytesIO(content)).tables)==3
        with ZipFile(zd.path()) as z:
            assert [n for n in z.namelist() if not n.endswith('/')]==[f'{stem}/{stem}.docx']
            assert z.read(f'{stem}/{stem}.docx')==content
        expect(rows.first.locator('.badge-done')).to_contain_text('Сформировано')
        desktop.screenshot(path=shots/'single-export.png',full_page=True,animations='disabled')
        desktop.reload()
        expect(desktop.locator('#done-count')).to_have_text('1')
        desktop.get_by_role('button',name='Сформировано 1').click()
        expect(rows).to_have_count(1)
        with desktop.expect_download() as saved: desktop.get_by_role('link',name='Сохранённый Word').click()
        assert Path(saved.value.path()).read_bytes()==content
        desktop.get_by_role('button',name='К подготовке 15').click()
        expect(rows).to_have_count(15)
        desktop.get_by_role('button',name='Снять выбор').click()
        rows.nth(0).get_by_role('checkbox').check()
        rows.nth(1).get_by_role('checkbox').check()
        desktop.get_by_role('button',name='Сформировать Word').click()
        expect(archive).to_be_visible()
        desktop.get_by_text('Скачать Word по одному',exact=True).click()
        expect(desktop.locator('#word-links a')).to_have_count(2)
        with desktop.expect_download() as zd2: archive.click()
        with ZipFile(zd2.value.path()) as z:
            names=[n for n in z.namelist() if not n.endswith('/')]
            assert len(names)==2 and all(n.count('/')==1 and n.split('/')[0]==n.split('/')[1][:-5] for n in names)
        expect(desktop.locator('#done-count')).to_have_text('3')
        expect(rows).to_have_count(13)
        # Simulate a completely verified check with a newly published event; session picks up shared storage.
        new=replace(actual[-1],day=max(date.today(),actual[-1].day)+timedelta(days=2),
                    url='http://www.web-kodeks.ru/test-fixture',menu_title='Тест новой карточки')
        app.store.save_schedule(Schedule((new,*actual),snapshot.home,utc_stamp()))
        desktop.evaluate("window.dispatchEvent(new Event('focus'))")
        expect(desktop.locator('.badge-new')).to_have_text('Новое')
        expect(desktop.locator('#todo-count')).to_have_text('14')
        desktop.get_by_role('button',name='Мониторинг').click()
        expect(desktop.locator('#monitor-state')).to_have_text('Автопроверка не запущена')
        expect(desktop.locator('#monitor-telegram')).to_contain_text('в очереди: 1')
        expect(desktop.locator('#monitor-times')).to_contain_text('13:30')
        desktop.screenshot(path=shots/'monitor-dialog.png',animations='disabled')
        desktop.get_by_role('button',name='Закрыть мониторинг').click()
        mobile=browser.new_page(viewport={'width':320,'height':760},locale='ru-RU',is_mobile=True,has_touch=True)
        mobile.on('pageerror',lambda error:page_errors.append(str(error)))
        mobile.goto(endpoint)
        expect(mobile.locator('.badge-new')).to_have_text('Новое')
        assert mobile.evaluate('document.documentElement.scrollWidth')==320
        mobile.screenshot(path=shots/'mobile-updated.png',animations='disabled',full_page=True)
        assert not page_errors,page_errors
    finally:
        server.shutdown(); server.server_close(); thread.join(); app.pool.shutdown()
print('Browser check: both downloads, exact folder, full multi-export, history/re-download, queue and new marking, monitoring modal and 320px — OK')
