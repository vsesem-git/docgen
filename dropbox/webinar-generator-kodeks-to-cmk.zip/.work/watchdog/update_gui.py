from pathlib import Path
p = Path('webinar_cmk_generator/gui.py')
s = p.read_text()
def replace(old, new):
    global s
    assert s.count(old)==1,repr(old)
    s = s.replace(old,new)
def between(start,end,new):
    global s
    i=s.index(start)
    j=s.index(end,i)
    s=s[:i]+new+s[j:]

replace('import secrets\n','import secrets\nimport sqlite3\n')
replace('from datetime import date, datetime, time, timezone','from datetime import datetime')
replace('''import requests

from cmk_docx import plain_title, render
from generate_webinars import safe_filename
from site_kodeks import (Event, ListingItem, SourceError, Topic, canonical_event,
                         download, following, listing, parse_event, session)

ROOT = Path(__file__).resolve().parent''','''from cmk_docx import plain_title, render
from generate_webinars import safe_filename
from schedule_data import CHECK_TIMES, MOSCOW, ROOT, Schedule, event_key, fetch_schedule, load_snapshot, next_slot
from site_kodeks import Event, SourceError, canonical_event
from storage import Store, data_dir
from telegram_notify import configured as telegram_configured
'''.rstrip())
between('@dataclass(frozen=True)\nclass Catalog:', '@dataclass\nclass Job:', '''@dataclass(frozen=True)
class Catalog:
    id: str
    entries: tuple[Event, ...]
    home: frozenset[str] | None
    checked_at: str | None
    origin: str
    tracked: bool = False

    @classmethod
    def from_schedule(cls, key: str, schedule: Schedule, *, tracked: bool = False) -> Catalog:
        return cls(key, schedule.entries, schedule.home, schedule.checked_at, schedule.origin, tracked)

    def list_payload(self, statuses: dict[str, dict]) -> dict:
        return {'id': self.id, 'origin': self.origin, 'checked_at': self.checked_at, 'tracked': self.tracked,
                'home_known': self.home is not None, 'events': [self.row(e, statuses.get(event_key(e))) for e in self.entries]}

    def row(self, e: Event, status: dict | None = None) -> dict:
        return {
            'id': e.url, 'url': e.url, 'title': e.menu_title or plain_title(e.title),
            'date': e.day.isoformat(), 'date_ru': e.date_ru, 'day_month': e.day_month,
            'hours': e.hours, 'on_home': None if self.home is None else e.url in self.home,
            'speaker_count': len(e.speakers), 'topic_count': len(e.topics), **(status or {}),
        }

    def find(self, event_id: str) -> Event:
        for e in self.entries:
            if e.url == event_id:
                return e
        raise ApiError('Карточка не найдена в этом списке. Обновите расписание.', 404)

    def detail(self, event_id: str) -> dict:
        e = self.find(event_id)
        return {**self.row(e), 'full_title': plain_title(e.title), 'abstract': e.abstract, 'audience': e.audience,
                'speakers': [{'name': n, 'role': r} for n, r in e.speakers],
                'topics': [{'title': t.title, 'details': t.details} for t in e.topics],
                'closing': e.closing, 'fee': e.fee, 'access': e.access_and_discounts, 'warnings': e.warnings}


@dataclass(frozen=True)
class Download:
    name: str
    payload: bytes
    mime: str


@dataclass(frozen=True)
class ExportBatch:
    archive: Download
    documents: tuple[Download, ...]


''')
between('def load_snapshot() -> Catalog:', 'def start_address(', '')
replace('''    def __init__(self):
        self.snapshot = load_snapshot()
        self.edits''', '''    def __init__(self, directory: Path | None = None):
        snapshot = load_snapshot()
        self.store = Store(data_dir(directory))
        self.store.seed(snapshot)
        self.snapshot = Catalog.from_schedule('snapshot', snapshot, tracked=True)
        self.latest_catalog = self.snapshot
        self.edits''')
replace('    self.bundles: OrderedDict[str, tuple[float, Bundle]] = OrderedDict()', '    self.bundles: OrderedDict[str, tuple[float, ExportBatch]] = OrderedDict()')
replace('''    def catalog(self, key: str) -> Catalog:
        if key == 'snapshot':
            return self.snapshot
        with self.lock:
            found = self.catalogs.get(key)
            if found:
                self.catalogs.move_to_end(key)
                return found
        raise ApiError('Этот список больше не сохранён. Обновите расписание.', 404)
''','''    def home_catalog(self) -> Catalog:
        with self.lock:
            db_item = self.store.latest(after=self.latest_catalog.id)
            if db_item:
                revision, schedule = db_item
                self.latest_catalog = Catalog.from_schedule(revision, schedule, tracked=True)
                self.remember(self.latest_catalog)
            return self.latest_catalog

    def remember(self, catalog: Catalog) -> None:
        # Called while holding self.lock.
        self.catalogs[catalog.id] = catalog
        self.catalogs.move_to_end(catalog.id)
        while len(self.catalogs) > 12:
            self.catalogs.popitem(last=False)

    def catalog(self, key: str) -> Catalog:
        if key == 'snapshot':
            return self.snapshot
        with self.lock:
            found = self.catalogs.get(key)
            if found:
                self.catalogs.move_to_end(key)
                return found
        latest = self.home_catalog()
        if latest.id == key:
            return latest
        raise ApiError('Этот список больше не сохранён. Обновите расписание.', 404)

    def catalog_payload(self, catalog: Catalog) -> dict:
        return catalog.list_payload(self.store.statuses(catalog.entries))

    def monitor_payload(self) -> dict:
        state = self.store.monitor()
        now = datetime.now(MOSCOW)
        return {**state, 'configured': telegram_configured(self.store.directory),
                'times': [t.strftime('%H:%M') for t in CHECK_TIMES],
                'next_check': next_slot(now).isoformat() if state['running'] else None}
''')
between('        try:\n            with session() as s:', '        except Exception as exc:', '''        try:
            schedule = fetch_schedule(mode=job.mode, start=job.start, on_page=progress)
            if job.mode == 'chain' and not job.start:
                self.store.save_schedule(schedule)
                item = self.home_catalog()
            else:
                item = Catalog.from_schedule(token(), schedule)
            with self.lock:
                self.remember(item)
                job.state, job.catalog_id, job.finished_at = 'ready', item.id, monotonic()
''')
replace("        except Exception as exc:\n            reason = str(exc) if isinstance(exc, SourceError) else 'Не удалось прочитать сайт. Проверьте адрес и повторите попытку.'", """        except Exception as exc:
            if isinstance(exc, sqlite3.Error):
                reason = 'Не удалось сохранить расписание. Проверьте папку данных и повторите попытку.'
            else:
                reason = str(exc) if isinstance(exc, SourceError) else 'Не удалось прочитать сайт. Проверьте адрес и повторите попытку.'""")
replace("            payload['catalog'] = self.catalog(key).list_payload()", "            payload['catalog'] = self.catalog_payload(self.catalog(key))")
# One rendering pass -> one DOCX per event + one ZIP with event folders.
replace('            original, j = stem, 2','            stem = stem[:95].rstrip(\' .\')  # Avoid very long path components when ZIP is unpacked on Windows.\n            original, j = stem, 2')
between("                names = tuple(name for name, _, _ in titles)", '        finally:\n            self.export_slots.release()', '''                saved = [(e, name, Path(tmp, name).read_bytes()) for name, e, _ in titles]
            docs = tuple(Download(name, content, DOCX_MIME) for _, name, content in saved)
            stream = io.BytesIO()
            with ZipFile(stream, 'w', ZIP_DEFLATED, compresslevel=5) as archive:
                for doc in docs:
                    folder = doc.name.removesuffix('.docx')
                    archive.writestr(folder + '/' + doc.name, doc.payload)
            if len(docs) == 1:
                zip_name = docs[0].name.removesuffix('.docx') + '.zip'
            else:
                days = sorted(e.day for e in events)
                span = days[0].strftime('%d.%m.%Y')
                if days[-1] != days[0]:
                    span += f'–{days[-1]:%d.%m.%Y}'
                zip_name = f'Программы ЦМК — {span}.zip'
            zip_file = Download(zip_name, stream.getvalue(), 'application/zip')
            try:
                stamp = self.store.save_programs(saved)
            except sqlite3.Error:
                raise ApiError('Не удалось сохранить программы в историю. Проверьте папку данных и повторите экспорт.', 500) from None
            bundle_id = token()
            with self.lock:
                now = monotonic()
                self.drop_old_bundles(now)
                self.bundles[bundle_id] = (now, ExportBatch(zip_file, docs))
                while len(self.bundles) > 10:
                    self.bundles.popitem(last=False)
            path = '/api/download/' + bundle_id
            return {'count': len(docs), 'generated_at': stamp,
                    'zip': {'url': path + '/zip', 'filename': zip_name},
                    'documents': [{'event_id': event.url, 'url': f'{path}/word/{i}', 'filename': name}
                                  for i, (event, name, _) in enumerate(saved)]}
''')
replace('    def bundle(self, key: str) -> Bundle:', '    def bundle(self, key: str) -> ExportBatch:')
replace("    server_version = 'CMK-GUI/1.0'", "    server_version = 'CMK-GUI/1.1'")
replace("                self.json(self.app.snapshot.list_payload())", "                self.json(self.app.catalog_payload(self.app.home_catalog()))\n            elif route == '/api/watchdog':\n                self.json(self.app.monitor_payload())")
replace("""            elif re.fullmatch(r'/api/download/[a-zA-Z0-9_-]+', route):
                bundle = self.app.bundle(route.rsplit('/', 1)[-1])
                self.reply(bundle.payload, bundle.mime, name=bundle.name)""", """            elif route == '/api/saved':
                args = parse_qs(parts.query, keep_blank_values=True, max_num_fields=10)
                catalog = self.app.catalog(args.get('catalog', [''])[0])
                event = catalog.find(args.get('event', [''])[0])
                saved = self.app.store.saved(event)
                if saved is None:
                    raise ApiError('Для этой карточки ещё нет сохранённого Word.', 404)
                self.reply(saved.content, DOCX_MIME, name=saved.filename)
            elif (match := re.fullmatch(r'/api/download/([a-zA-Z0-9_-]+)/(zip|word/([0-9]{1,3}))', route)):
                bundle = self.app.bundle(match[1])
                if match[2] == 'zip':
                    item = bundle.archive
                else:
                    idx = int(match[3])
                    if idx >= len(bundle.documents):
                        raise ApiError('Документ не найден в этом экспорте.', 404)
                    item = bundle.documents[idx]
                self.reply(item.payload, item.mime, name=item.name)""")
s=s.replace('except (ValueError, OSError) as exc:', 'except (ValueError, OSError, sqlite3.Error) as exc:')
replace("    args = parser.parse_args()\n    app = App()", "    parser.add_argument('--data-dir', type=Path, help='общая папка истории и расписания')\n    args = parser.parse_args()\n    app = App(args.data_dir)")
p.write_text(s)
