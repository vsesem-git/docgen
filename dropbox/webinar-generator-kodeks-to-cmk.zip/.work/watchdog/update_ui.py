from pathlib import Path

def for_file(name):
    global p,s
    p=Path('webinar_cmk_generator/ui')/name
    s=p.read_text()
def rep(old,new):
    global s
    assert s.count(old)==1,repr(old)
    s=s.replace(old,new)
def between(a,b,new):
    global s
    i=s.index(a)
    s=s[:i]+new+s[s.index(b,i):]

for_file('index.html')
rep('  </svg>\n\n  <header class="topbar">','''    <symbol id="i-bell" viewBox="0 0 24 24"><path d="M18 9a6 6 0 1 0-12 0c0 6-2 6.5-2 7.5h16c0-1-2-1.5-2-7.5m-8 10a2 2 0 0 0 4 0"/></symbol>
    <symbol id="i-archive" viewBox="0 0 24 24"><rect x="3.5" y="4" width="17" height="4" rx="1"/><path d="M5 8v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8m-9 5h4"/></symbol>
  </svg>

  <header class="topbar">''')
rep('''        <button type="button" class="button button-help" id="open-help" aria-haspopup="dialog">''','''        <button type="button" class="button button-help monitor-button" id="open-monitor" aria-haspopup="dialog"><svg class="icon"><use href="#i-bell"/></svg><span>Мониторинг</span></button>
        <button type="button" class="button button-help" id="open-help" aria-label="Справка" aria-haspopup="dialog">''')
rep('class="filter-tabs" aria-label="Где показаны вебинары"','class="filter-tabs" aria-label="Фильтры по статусу вебинаров"')
rep('''            <button class="filter-tab" type="button" id="show-beyond" aria-pressed="false" hidden>Вне главной <span id="beyond-count" class="tab-number"></span></button>''','''            <button class="filter-tab" type="button" id="show-beyond" aria-pressed="false" hidden>Вне главной <span id="beyond-count" class="tab-number"></span></button>
            <button class="filter-tab" type="button" id="show-todo" aria-pressed="false">К подготовке <span id="todo-count" class="tab-number">0</span></button>
            <button class="filter-tab" type="button" id="show-done" aria-pressed="false">Сформировано <span id="done-count" class="tab-number">0</span></button>''')
rep('''            <a id="download-result" class="button button-primary export-button" href="#" download><svg class="icon"><use href="#i-download"/></svg><span id="download-label">Скачать Word</span></a>''','''            <a id="download-word" class="button button-primary export-button" download hidden><svg class="icon"><use href="#i-download"/></svg><span>Скачать Word</span></a>
            <a id="download-zip" class="button button-outline export-button" download><svg class="icon"><use href="#i-archive"/></svg><span>Скачать ZIP</span></a>
            <details class="word-list" id="batch-words" hidden><summary>Скачать Word по одному</summary><ul id="word-links"></ul></details>''')
rep('id="format-badge">.DOCX</span>','id="format-badge">DOCX + ZIP</span>')
rep('Файл появится здесь после формирования','Ссылки появятся после формирования')
rep('''<svg class="icon"><use href="#i-external"/></svg></a></div>
          </div>
        </section>''','''<svg class="icon"><use href="#i-external"/></svg></a></div>
            <a class="saved-link" id="saved-word" download hidden><svg class="icon"><use href="#i-download"/></svg><span>Сохранённый Word</span></a>
          </div>
        </section>''')
rep('''<li><strong>Выберите карточки.</strong> Поиск и период сужают список. Флажок в заголовке отмечает все показанные строки. Ссылки на источники и полный текст программы доступны в карточке.</li><li><strong>Сформируйте Word.</strong> Один вебинар скачивается в DOCX, несколько — в ZIP с отдельным DOCX на каждый. Документы создаются на копии бланка ЦМК.</li>''','''<li><strong>Выберите карточки.</strong> «К подготовке» показывает вебинары без сохранённого Word. Метка «Новое» означает, что карточка появилась после известного расписания. Флажок в заголовке отмечает все показанные строки.</li><li><strong>Сформируйте Word.</strong> Можно скачать отдельный DOCX или ZIP. В ZIP лежит папка на каждый вебинар — даже если выбран только один. Последний Word для каждой карточки остаётся в истории.</li>''')
rep('''  <div id="toast" class="toast"''','''  <dialog id="monitor-dialog" class="dialog help-dialog" aria-labelledby="monitor-heading">
    <div class="dialog-head"><div><p class="eyebrow dialog-kicker">ПРОВЕРКА РАСПИСАНИЯ</p><h2 id="monitor-heading">Мониторинг Telegram</h2></div><form method="dialog"><button type="submit" class="button button-icon" aria-label="Закрыть мониторинг"><svg class="icon"><use href="#i-close"/></svg></button></form></div>
    <div class="dialog-body monitor-body">
      <p>Три проверки в день по московскому времени. Бот присылает дату, тему и ссылку только для новых карточек.</p>
      <div class="monitor-times" id="monitor-times"><span>07:00</span><span>13:30</span><span>20:00</span><small>МСК</small></div>
      <div class="monitor-summary" id="monitor-summary" role="status">
        <strong id="monitor-state">Проверяем состояние…</strong>
        <span id="monitor-telegram"></span>
        <span id="monitor-last"></span>
        <span id="monitor-next"></span>
        <span id="monitor-note"></span>
      </div>
      <ol class="help-steps monitor-steps"><li>В Windows откройте <strong>«Мониторинг Telegram.cmd» → «Подключить бота»</strong>. В терминале: <code>python watchdog.py --connect</code>.</li><li>Введите токен локально и отправьте боту показанный код. После тестового сообщения запустите мониторинг по расписанию.</li></ol>
      <p class="help-note">Компьютер или сервер должен оставаться включённым. Вкладку браузера можно закрыть.</p>
    </div>
    <div class="dialog-footer align-right"><form method="dialog"><button type="submit" class="button button-primary">Закрыть</button></form></div>
  </dialog>
  <div id="toast" class="toast"''')
p.write_text(s)

for_file('app.js')
rep("  'beyond-count', 'table-scroll'", "  'beyond-count', 'show-todo', 'todo-count', 'show-done', 'done-count', 'table-scroll'")
rep("'result-text', 'download-result', 'download-label',", "'result-text', 'download-word', 'download-zip', 'batch-words', 'word-links',")
rep("  'toast', 'toast-icon', 'toast-text', 'toast-close'", "  'saved-word', 'open-monitor', 'monitor-dialog', 'monitor-times', 'monitor-summary', 'monitor-state',\n  'monitor-telegram', 'monitor-last', 'monitor-next', 'monitor-note', 'toast', 'toast-icon', 'toast-text', 'toast-close'")
rep('function useCatalog(catalog, autoSelect = false) {','''function useCatalog(catalog, autoSelect = false, keepResult = false) {
  const oldCount = state.selected.size;''')
rep('''  state.result = null;
  refreshSchedule();
}

function refreshSchedule()''','''  if (!keepResult || oldCount !== state.selected.size) state.result = null;
  refreshSchedule();
}

const scopeButtons = { all: 'show-all', beyond: 'show-beyond', todo: 'show-todo', done: 'show-done' };

function refreshSchedule()''')
rep('''  if (!beyond) state.scope = 'all';
  el['show-beyond'].hidden = beyond === 0;
  el['show-beyond'].setAttribute('aria-pressed', String(state.scope === 'beyond'));
  el['show-all'].setAttribute('aria-pressed', String(state.scope === 'all'));
  el['beyond-count'].textContent = beyond;''','''  const done = entries.filter(e => e.generated_at).length;
  if (!beyond && state.scope === 'beyond') state.scope = 'all';
  el['show-beyond'].hidden = beyond === 0;
  for (const [scope, id] of Object.entries(scopeButtons)) el[id].setAttribute('aria-pressed', String(state.scope === scope));
  el['beyond-count'].textContent = beyond;
  el['done-count'].textContent = done;
  el['todo-count'].textContent = entries.length - done;''')
rep("    if (state.scope === 'beyond' && e.on_home !== false) return false;", """    if (state.scope === 'beyond' && e.on_home !== false) return false;
    if (state.scope === 'todo' && e.generated_at) return false;
    if (state.scope === 'done' && !e.generated_at) return false;""")
rep("    tr.dataset.event = e.id;", """    tr.dataset.event = e.id;
    tr.classList.toggle('new-event', Boolean(e.is_new && !e.generated_at));""")
rep("    if (e.on_home === false) title.append(make('span', 'row-badge', 'Вне главной'));", """    const meta = make('div', 'row-meta');
    if (e.generated_at) {
      const badge = make('span', 'row-badge badge-done');
      badge.append(icon('check'), document.createTextNode('Сформировано'));
      badge.title = `${checkedTime.format(new Date(e.generated_at))} МСК`;
      meta.append(badge);
    } else if (e.is_new) meta.append(make('span', 'row-badge badge-new', 'Новое'));
    if (e.on_home === false) meta.append(make('span', 'row-badge', 'Вне главной'));
    if (meta.children.length) title.append(meta);""")
rep("      empty.replaceChildren(icon('search'), make('p', '', 'По этим фильтрам вебинары не найдены.'), reset);", """      const statusOnly = !el['event-search'].value.trim() && !el['date-from'].value && !el['date-to'].value;
      const message = statusOnly && state.scope === 'done' ? 'Здесь будут вебинары с сохранённым Word.'
        : statusOnly && state.scope === 'todo' ? 'Все вебинары в этом списке уже сформированы.'
        : 'По этим фильтрам вебинары не найдены.';
      empty.replaceChildren(icon(state.scope === 'done' ? 'archive' : 'search'), make('p', '', message), reset);""")
rep("  const format = !n ? 'Отметьте карточки в списке' : n === 1 ? 'Один документ Word' : 'Архив с отдельными DOCX';",
    "  const format = !n ? 'Отметьте карточки в списке' : n === 1 ? 'Один Word и ZIP' : 'Word по одному или общий ZIP';")
rep("  el['format-badge'].textContent = n > 1 ? '.ZIP' : '.DOCX';\n", '')
between("  el['export-note'].textContent = state.result", '  syncRows();\n  el[\'scan-button\']', '''  const result = state.result;
  el['export-note'].textContent = result ? 'Последний Word сохранён в истории.'
    : state.exporting ? 'Заполняем бланк ЦМК' : 'Ссылки появятся после формирования';
  if (result) {
    const single = result.count === 1;
    el['result-text'].textContent = single ? 'Документ готов' : `Готово: ${result.count} ${plural(result.count, 'документ', 'документа', 'документов')}`;
    el['download-zip'].classList.toggle('button-primary', !single);
    el['download-zip'].classList.toggle('button-outline', single);
    downloadLink(el['download-zip'], result.zip);
    el['download-word'].hidden = !single;
    if (single) downloadLink(el['download-word'], result.documents[0]);
    el['batch-words'].hidden = single;
    if (!single && el['word-links'].dataset.result !== result.zip.url) {
      const links = result.documents.map(doc => {
        const li = make('li');
        const a = make('a', '', doc.filename.replace(/\\.docx$/u, ''));
        downloadLink(a, doc);
        li.append(a);
        return li;
      });
      el['word-links'].replaceChildren(...links);
      el['word-links'].dataset.result = result.zip.url;
      el['batch-words'].open = false;
    }
  } else {
    el['download-word'].removeAttribute('href');
    el['download-zip'].removeAttribute('href');
  }
''')
rep("function renderPreview() {", """function downloadLink(link, { url, filename }) {
  link.href = url;
  link.download = filename;
  link.title = filename;
}

function renderPreview() {""")
rep("  el['source-link'].href = e.url;", """  el['source-link'].href = e.url;
  el['saved-word'].hidden = !e.generated_at;
  if (e.generated_at) {
    const query = new URLSearchParams({ catalog: state.catalog.id, event: e.id });
    downloadLink(el['saved-word'], { url: '/api/saved?' + query, filename: e.saved_name });
  } else el['saved-word'].removeAttribute('href');""")
rep("    toast(state.result.count === 1 ? 'Word-документ готов к скачиванию.' : 'Архив с Word-программами готов.');", """    const names = new Map(state.result.documents.map(doc => [doc.event_id, doc.filename]));
    for (const e of state.catalog.events) if (names.has(e.id)) {
      e.generated_at = state.result.generated_at;
      e.saved_name = names.get(e.id);
    }
    toast(state.result.count === 1 ? 'Word и ZIP готовы к скачиванию.' : 'ZIP и отдельные Word готовы к скачиванию.');""")
rep("    syncSelection();\n    if (state.result) el['download-result'].focus({ preventScroll: true });", """    refreshSchedule();
    if (state.result) el[state.result.count === 1 ? 'download-word' : 'download-zip'].focus({ preventScroll: true });""")
rep("""el['show-all'].addEventListener('click', () => { state.scope = 'all'; refreshSchedule(); el['table-scroll'].scrollTop = 0; });
el['show-beyond'].addEventListener('click', () => { state.scope = 'beyond'; refreshSchedule(); el['table-scroll'].scrollTop = 0; });""", """for (const [scope, id] of Object.entries(scopeButtons)) el[id].addEventListener('click', () => {
  state.scope = scope;
  refreshSchedule();
  el['table-scroll'].scrollTop = 0;
});""")
rep("async function initialize() {", """async function refreshMonitor() {
  try {
    const data = await api('/api/watchdog');
    el['monitor-times'].replaceChildren(...data.times.map(t => make('span', '', t)), make('small', '', 'МСК'));
    el['monitor-state'].textContent = data.checking ? 'Проверяем расписание…'
      : data.running ? 'Автопроверка работает' : 'Автопроверка не запущена';
    el['monitor-summary'].classList.toggle('is-running', data.running || data.checking);
    el['monitor-telegram'].textContent = (data.configured ? 'Настройки Telegram сохранены' : 'Telegram не подключён')
      + (data.pending ? ` · в очереди: ${data.pending}` : '');
    el['monitor-last'].textContent = data.last_finish ? `Последняя проверка: ${checkedTime.format(new Date(data.last_finish))} МСК` : 'Проверок ещё не было';
    el['monitor-next'].textContent = data.next_check ? `Следующая: ${checkedTime.format(new Date(data.next_check))} МСК` : '';
    el['monitor-note'].textContent = data.last_note || '';
    el['monitor-note'].classList.toggle('is-error', data.last_ok === false);
  } catch {
    el['monitor-state'].textContent = 'Не удалось получить состояние. Откройте окно заново.';
  }
}

el['open-monitor'].addEventListener('click', () => {
  el['monitor-dialog'].showModal();
  refreshMonitor();
});

let refreshing = false;
async function refreshStored() {
  const current = state.catalog;
  if (!current?.tracked || state.scanning || state.exporting || refreshing || document.hidden) return;
  refreshing = true;
  try {
    const update = await api('/api/catalog');
    if (state.catalog !== current || state.scanning || state.exporting) return;
    if (update.id !== current.id || update.events.some((e, i) => e.generated_at !== current.events[i]?.generated_at)) {
      useCatalog(update, false, true);
    }
  } catch { /* A network hiccup must not wipe the currently displayed list. */ }
  finally { refreshing = false; }
}
window.addEventListener('focus', refreshStored);
setInterval(() => {
  refreshStored();
  if (el['monitor-dialog'].open) refreshMonitor();
}, 30_000);

async function initialize() {""")
p.write_text(s)
