import contextlib
import io
import json
import os
import unittest
from dataclasses import replace
from datetime import date, datetime, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from zipfile import ZipFile

import requests
from docx import Document
from gui import App
from schedule_data import CHECK_TIMES, MOSCOW, Schedule, due_slot, event_key, load_snapshot, next_slot, utc_stamp
from storage import Store
from telegram_notify import Bot, TelegramError
from watchdog import check_once, telegram_batches, TEST_MESSAGE, connect


class Flow(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.directory = Path(self.tmp.name)
        self.snapshot = load_snapshot()
        self.med = next(e for e in self.snapshot.entries if e.slug=='med')
        self.fresh = replace(self.med, day=max(date.today(), self.med.day)+timedelta(days=21),
                             menu_title='Новая карточка · тест')
        self.live = Schedule((self.med, self.fresh), self.snapshot.home, utc_stamp())
        self.secret = '123456:'+'mock_secret_'*3

    def test_export_and_restart(self):
        app=App(self.directory)
        self.addCleanup(app.pool.shutdown)
        self.assertIsNone(app.store.saved(self.med))
        self.assertEqual([],app.store.pending())
        result=app.make_programs({'catalog':'snapshot','event_ids':[self.med.url]})
        b=app.bundle(result['zip']['url'].split('/')[-2])
        expected='18 декабря - Оплата труда медицинских работников в 2027 году'
        self.assertEqual(1,result['count'])
        self.assertEqual(expected+'.docx',b.documents[0].name)
        self.assertEqual(expected+'.zip',b.archive.name)
        with ZipFile(io.BytesIO(b.archive.payload)) as z:
            paths=[n for n in z.namelist() if not n.endswith('/')]
            self.assertEqual([expected+'/'+expected+'.docx'],paths)
            self.assertEqual(b.documents[0].payload,z.read(paths[0]))
            self.assertIsNone(z.testzip())
        d=Document(io.BytesIO(b.documents[0].payload))
        self.assertEqual(3,len(d.tables))
        self.assertTrue(any('Ирина' in p.text for p in d.paragraphs))
        reopened=App(self.directory)
        self.addCleanup(reopened.pool.shutdown)
        self.assertEqual(b.documents[0].payload,reopened.store.saved(self.med).content)
        self.assertIn('generated_at',reopened.store.statuses([self.med])[event_key(self.med)])
        self.assertIsNone(reopened.store.saved(self.fresh))

    def test_baseline_outbox_retry_and_no_duplicates(self):
        store=Store(self.directory)
        store.seed(self.snapshot)
        self.assertFalse(store.pending())
        out=[]
        class Recorder:
            def __init__(self, key):
                assert key == self_outer.secret
            def send(self, chat, text):
                out.append((chat,text))
        self_outer=self
        class Down(Recorder):
            def send(self, chat,text):
                raise TelegramError('Тест неудачной отправки')
        with patch.dict(os.environ,{'CMK_TELEGRAM_TOKEN':self.secret,'CMK_TELEGRAM_CHAT_ID':'987654'}), contextlib.redirect_stdout(io.StringIO()):
            self.assertFalse(check_once(store, scan=lambda: self.live, bot_factory=Down))
            status=store.statuses((self.med,self.fresh))
            self.assertFalse(status[event_key(self.med)]['is_new'])
            self.assertTrue(status[event_key(self.fresh)]['is_new'])
            self.assertEqual([event_key(self.fresh)],[n.key for n in store.pending()])
            self.assertTrue(check_once(Store(self.directory),'slot-uniq',scan=lambda: self.live,bot_factory=Recorder))
            self.assertIsNone(check_once(Store(self.directory),'slot-uniq',scan=lambda: self.live,bot_factory=Recorder))
            self.assertEqual(1,len(out))
            self.assertEqual(987654,out[0][0])
            self.assertIn(self.fresh.date_ru,out[0][1])
            self.assertIn(self.fresh.url,out[0][1])
            self.assertIn(self.fresh.menu_title,out[0][1])
            self.assertTrue(check_once(Store(self.directory),'slot-other',scan=lambda: self.live,bot_factory=Recorder))
            self.assertEqual(1,len(out))
            old=store.latest()[0]
            def offline():
                raise requests.ConnectionError('нет сайта')
            self.assertFalse(check_once(store,scan=offline,bot_factory=Recorder))
            self.assertEqual(old,store.latest()[0])
            self.assertFalse(store.monitor()['last_ok'])
            self.assertFalse(store.pending())
            self.assertNotIn(self.secret,json.dumps(store.monitor()))

    def test_unconfigured_notification_is_queued(self):
        store=Store(self.directory)
        store.seed(self.snapshot)
        with patch.dict(os.environ,{},clear=True),contextlib.redirect_stdout(io.StringIO()):
            self.assertTrue(check_once(store,scan=lambda:self.live))
        self.assertEqual(1,store.monitor()['pending'])
        self.assertTrue(store.monitor()['last_ok'])
        self.assertIn('Telegram не настроен',store.monitor()['last_note'])

    def test_schedule_windows_and_serialization(self):
        day=date(2026,11,18)
        for t in CHECK_TIMES:
            slot=datetime.combine(day,t,MOSCOW)
            self.assertEqual(slot,due_slot(slot+timedelta(seconds=28)))
            self.assertIsNone(due_slot(slot+timedelta(minutes=1)))
        self.assertEqual(datetime(2026,11,19,7,0,tzinfo=MOSCOW),next_slot(datetime(2026,11,18,20,0,tzinfo=MOSCOW)))
        self.assertEqual(self.live,Schedule.from_json(self.live.to_json()))

    def test_private_pairing_and_request_envelope(self):
        class Reply:
            status_code=200
            ok=True
            def __init__(self,result): self.result=result
            def json(self): return {'ok':True,'result':self.result}
        calls=[]
        def mocked_post(url,**options):
            self.assertTrue(url.startswith('https://api.telegram.org/bot'+self.secret+'/'))
            calls.append((url.rsplit('/',1)[1],options))
            method= calls[-1][0]
            if method=='getMe': return Reply({'username':'cmk_test_bot'})
            if method=='getUpdates':
                nonce=re.search(r'CMK-[A-F0-9]+',output.getvalue())[0]
                return Reply([{'update_id':1,'message':{'text':nonce,'chat':{'type':'group','id':33}}},
                              {'update_id':2,'message':{'text':'other','chat':{'type':'private','id':34}}},
                              {'update_id':3,'message':{'text':nonce,'chat':{'type':'private','id':35}}}])
            return Reply({'message_id':1})
        import re
        output=io.StringIO()
        with patch('watchdog.getpass.getpass',return_value=self.secret),patch('telegram_notify.requests.post',side_effect=mocked_post),contextlib.redirect_stdout(output):
            connect(self.directory)
        self.assertEqual(['getMe','getUpdates','sendMessage'],[name for name,_ in calls])
        self.assertEqual({'chat_id':35,'text':TEST_MESSAGE,'link_preview_options':{'is_disabled':True}},calls[-1][1]['json'])
        self.assertFalse(calls[-1][1]['allow_redirects'])
        self.assertNotIn(self.secret,output.getvalue())
        cfg=self.directory/'telegram.json'
        self.assertEqual(35,json.loads(cfg.read_text())['chat_id'])
        if os.name == 'posix': self.assertEqual(0,cfg.stat().st_mode & 0o077)
        with patch('telegram_notify.requests.post',side_effect=requests.ConnectionError(self.secret)):
            with self.assertRaises(TelegramError) as ctx:
                Bot(self.secret).send(35,'test')
        self.assertNotIn(self.secret,str(ctx.exception))

if __name__=='__main__': unittest.main(verbosity=2)
