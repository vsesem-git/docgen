from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from sys import path
from zipfile import ZipFile

from docx import Document
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.oxml.ns import qn
from lxml import etree

path.insert(0, str(Path.cwd()))
from webinar_generator.generate_webinars import ListingItem, parse_event, full_stop

BASE = Path('.work/refs/template.docx')
EXPECTED_HASH = 'cbf545780ea9028cba938c39a3aad9953d6de43ae06b0e6aebe130dfc9d0b780'
URL = 'http://www.web-kodeks.ru/tpk'
OUT = Path('20 ноября - Новые условия подключения к сетям ЖКХ.docx')
assert sha256(sha256(BASE.read_bytes()).digest()).hexdigest() == EXPECTED_HASH
E = parse_event(Path('.work/html/tpk-live.html').read_bytes(), ListingItem(URL))
assert E.day.isoformat() == '2026-11-20' and len(E.topics) == 8 and len(E.speakers) == 4
assert '16 800 рублей (НДС не облагается)' in E.fee and E.hours == '10:00–16:00'


def fill(paragraph, *texts):
    """Change only existing run text; retain paragraph and run formatting."""
    runs = paragraph.runs
    assert len(runs) == len(texts), (paragraph.text, len(runs), len(texts))
    for run, value in zip(runs, texts):
        run.text = value


def rewrite_body(d):
    p = list(d.paragraphs)
    letterhead, info, form = d.tables
    assert len(p) == 28 and p[1].text == 'Уважаемые коллеги!'
    assert p[6].text == 'ВЕДУЩИЕ ВЕБИНАРА' and p[11].text == 'ПРОГРАММА ВЕБИНАРА'
    assert p[23].text == 'УСЛОВИЯ УЧАСТИЯ' and 'kir@vsesem.ru' in p[25].text
    assert p[26].text == 'Анкета для регистрации на вебинар'
    assert not info._tbl.xpath('./w:tblPr/w:tblpPr')

    title = E.title.capitalize()
    date_short = (f'{E.day_month} {E.day.year} г.').replace(' ', '\u00a0')
    form_title = f'{date_short} «{title}»'
    c1, c2 = info.rows[0].cells
    fill(c1.paragraphs[0], f'О проведении онлайн-трансляции {form_title}')
    fill(c2.paragraphs[0], 'Руководителям и специалистам\n'
         'предприятий теплоснабжения, водоснабжения и водоотведения,\n'
         'потребителям коммунальных ресурсов,\n'
         'представителям региональных органов регулирования и МСУ')

    fill(p[2],
         'Практика применения ',
         'новых правил подключения к сетям тепло- и водоснабжения',
         ' вызывает споры между коммунальными предприятиями и заявителями. Основные вопросы — определение ',
         'технической возможности подключения и оснований для отказа',
         ', ',
         'расчет платы для разных категорий потребителей',
         ', ',
         'обоснование расходов и их согласование с регулятором',
         ', а также порядок расчетов при ',
         'подключении по индивидуальному проекту',
         ' или ',
         'строительстве сетей силами заявителя',
         '.')
    fill(p[3], p[3].runs[0].text, E.date_ru.replace(' ', '\u00a0'),
         ' интернет-трансляции всероссийского практического вебинара с участием ',
         'представителей ФАС России',
         ', разработчиков новых правил и ведущих экспертов-практиков по подключению к коммунальным сетям:')
    fill(p[4], E.title)
    fill(p[5], p[5].runs[0].text,
         'оценить возможность присоединения; рассчитать плату за подключение к теплосетям и сетям ВКХ; '
         'обосновать расходы перед регулятором; выбрать договорную схему, в том числе при строительстве сетей заявителем.')

    # Keep each position and area of expertise; shorten only repeated organization names.
    names = {
        'жилищно-коммунального хозяйства Федеральной антимонопольной службы': 'ЖКХ ФАС России',
        'Института экономики и права жилищно-коммунального хозяйства': 'Института экономики и права ЖКХ',
        'Группы компаний «Росводоканал»': 'ГК «Росводоканал»',
        'Института экономики жилищно-коммунального хозяйства': 'Института экономики ЖКХ',
        'жилищно-коммунальной сфере': 'сфере ЖКХ',
        'в сфере тарифного регулирования и ценообразования при предоставлении коммунальных услуг и подключении к сетям ЖКХ': 'по тарифному регулированию и ценообразованию в сфере коммунальных услуг и подключения к сетям',
        'ранее – Заместитель': 'ранее — заместитель',
    }
    for row, (name, job) in zip(p[7:11], E.speakers):
        for old, new in names.items():
            job = job.replace(old, new)
        fill(row, name, ' — ' + job)
    for i, (row, topic) in enumerate(zip(p[12:22], E.topics), 1):
        fill(row, f'{i}. {full_stop(topic.title)} ', topic.details)
    for row in p[12 + len(E.topics):22]:
        row._p.getparent().remove(row._p)
    fill(p[22], f'{len(E.topics)+1}. Ответы на вопросы участников, консультации экспертов и практические рекомендации')

    # Both the source page and the event's ЦМК reference list this fee and VAT treatment.
    fill(p[24], 'Интернет-трансляция будет проходить ',
         f'{E.day_month} с {E.start:%H:%M} до {E.end:%H:%M}',
         ' (по московскому времени). Стоимость участия в вебинаре — ',
         '16\u00a0800\u00a0рублей',
         ' (НДС не облагается). В стоимость входит: доступ к онлайн-трансляции на одном компьютере, '
         'консультации экспертов в общем чате, полная видеозапись вебинара, сертификат об обучении '
         'и комплект справочно-методических материалов.')
    fill(form.rows[0].cells[1].paragraphs[0], form_title)
    fill(form.rows[1].cells[1].paragraphs[0], f'{date_short}, {E.hours} (МСК)')
    # Title and date belong together. Let Word reflow the form without a forced break.
    for tc in form.rows[0]._tr.tc_lst:
        for node in tc.xpath('./w:p'):
            from docx.text.paragraph import Paragraph
            Paragraph(node, form).paragraph_format.keep_with_next = True
    return title


def clear_stale_package_info(d, title):
    # Remove an outdated local .dotx reference and hidden metadata copied from older events.
    settings = d.part._settings_part
    for n in settings.element.xpath('./w:attachedTemplate'):
        rid = n.get(qn('r:id'))
        n.getparent().remove(n)
        if rid and rid in settings.rels:
            del settings.rels[rid]
    for rid, rel in list(d.part.rels.items()):
        if rel.reltype in (RT.IMAGE, RT.HYPERLINK) and not d.element.xpath(
            f'//*[@r:id="{rid}" or @r:embed="{rid}" or @r:link="{rid}"]'
        ):
            del d.part.rels[rid]
    pkg = d.part.package
    default_app = next(r.target_part for r in Document().part.package.rels.values() if r.reltype == RT.EXTENDED_PROPERTIES)
    for rid, r in list(pkg.rels.items()):
        if r.reltype == RT.EXTENDED_PROPERTIES:
            del pkg.rels[rid]
    pkg.relate_to(default_app, RT.EXTENDED_PROPERTIES)
    core = d.core_properties
    core.title = title
    core.subject = 'Программа вебинара Центра Межрегиональных Коммуникаций'
    core.author = 'Центр Межрегиональных Коммуникаций'
    core.last_modified_by = ''
    core.comments = ''
    core.created = core.modified = datetime.now(timezone.utc)
    core.revision = 1


def xml(element):
    return etree.tostring(element, method='c14n')


def check_delivery(original, result):
    d = Document(result)
    assert len(d.tables) == len(original.tables) == 3
    assert xml(d.tables[0]._tbl) == xml(original.tables[0]._tbl), 'Изменена шапка'
    assert xml(d.paragraphs[0]._p) == xml(original.paragraphs[0]._p)
    assert xml(d.paragraphs[-3]._p) == xml(original.paragraphs[-3]._p), 'Изменены контакты регистрации'
    assert d.paragraphs[-3].text == original.paragraphs[-3].text
    assert set(h.address for h in d.paragraphs[-3].hyperlinks) == {h.address for h in original.paragraphs[-3].hyperlinks}
    form, sample_form = d.tables[-1], original.tables[-1]
    assert len(form.rows) == len(sample_form.rows)
    for i in range(2, len(form.rows)):
        assert xml(form.rows[i]._tr) == xml(sample_form.rows[i]._tr), 'Изменены поля анкеты'
    assert all(r._tr.xpath('./w:trPr/w:cantSplit') for r in form.rows)
    assert '20\u00a0ноября\u00a02026' in form.rows[0].cells[1].text
    assert E.hours in form.rows[1].cells[1].text
    assert all('deca' not in r.target_ref for r in d.part.rels.values() if r.is_external)
    with ZipFile(result) as result_zip, ZipFile(BASE) as source_zip:
        assert result_zip.testzip() is None
        assert result_zip.read('word/media/image1.png') == source_zip.read('word/media/image1.png')
        x = result_zip.read('word/document.xml').decode('utf-8')
        assert all(t not in x for t in ('10 декабря', '40-41-40','@kodeks','КРСОИ','НИФОНТОВ','{{'))
        assert '16\u00a0800\u00a0рублей' in x and 'КОВАЛЕВА' in x and 'БУДНИЦКИЙ' in x
        assert len(d.element.xpath('.//w:drawing')) == len(original.element.xpath('.//w:drawing'))


d = Document(BASE)
title = rewrite_body(d)
clear_stale_package_info(d, title)
d.save(OUT)
check_delivery(Document(BASE), OUT)
print(OUT, OUT.stat().st_size, 'bytes')
