#!/usr/bin/env bash
set -euo pipefail

usage() {
  printf '%s\n' 'Внутри нового LXC Debian: bash deploy/install-lxc.sh --ip IP_КОНТЕЙНЕРА [--port 8443] [--user cmk]'
}
if [[ ${1:-} == '--help' || ${1:-} == '-h' ]]; then usage; exit 0; fi
if [[ "${EUID}" -ne 0 || "$(systemd-detect-virt --container 2>/dev/null || true)" != lxc ]]; then
  printf '%s\n' 'Установщик запускается от root внутри LXC, не на хосте Proxmox.' >&2
  exit 1
fi
if [[ ! -t 0 ]]; then
  printf '%s\n' 'Откройте интерактивную консоль контейнера: pct enter CTID.' >&2
  exit 1
fi
if [[ -f /etc/cmk-lan/config.json ]]; then
  printf '%s\n' 'LAN уже настроен. Для изменения используйте cmk-lan-config port, ip или password.' >&2
  exit 1
fi

ip= port=8443 lan_user=cmk
while (($#)); do
  if (($#<2)); then usage; exit 2; fi
  case "$1" in
    --ip) ip=$2 ;;
    --port) port=$2 ;;
    --user) lan_user=$2 ;;
    *) usage; exit 2 ;;
  esac
  shift 2
done
if [[ -z "$ip" || ! "$port" =~ ^[0-9]{4,5}$ || ! "$lan_user" =~ ^[a-zA-Z0-9][a-zA-Z0-9_-]{0,31}$ ]]; then
  usage
  exit 2
fi
if systemctl is-active --quiet caddy.service; then
  printf '%s\n' 'В контейнере уже работает обычный Caddy. Используйте новый выделенный LXC.' >&2
  exit 1
fi
# Keep the package's example site off; the panel uses its own Caddy service.
systemctl mask caddy.service
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends python3 python3-venv ca-certificates caddy
python3 - <<'PY'
import sys
if sys.version_info < (3,10):
    raise SystemExit('Нужен Python 3.10+. Используйте шаблон Debian 12 или новее.')
PY

root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
app=/opt/cmk-webinars
if ! id -u cmk-webinars >/dev/null 2>&1; then
  useradd --system --user-group --home-dir /var/lib/cmk-webinars --no-create-home --shell /usr/sbin/nologin cmk-webinars
fi
install -d -m 0755 "$app" /etc/systemd/system/cmk-webinars.service.d
if [[ "$root" != "$app" ]]; then
  cp -R "$root/." "$app/"
fi
chown -R root:root "$app"
python3 -m venv "$app/.venv"
"$app/.venv/bin/python" -m pip install --disable-pip-version-check -r "$app/requirements.txt"
install -d -m 0700 -o cmk-webinars -g cmk-webinars /var/lib/cmk-webinars
install -m 0644 "$app/deploy/cmk-webinars.service" /etc/systemd/system/cmk-webinars.service
install -m 0644 "$app/deploy/lxc-webinars.conf" /etc/systemd/system/cmk-webinars.service.d/lan.conf
install -m 0644 "$app/deploy/cmk-lan-proxy.service" /etc/systemd/system/cmk-lan-proxy.service
install -m 0755 "$app/deploy/cmk-lan-config" /usr/local/sbin/cmk-lan-config
cmk-lan-config init --ip "$ip" --port "$port" --user "$lan_user"
