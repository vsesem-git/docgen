"""Opt-in administration behind the authenticated, local HTTPS proxy."""
from __future__ import annotations

import ipaddress
import os
import re
import secrets
from dataclasses import dataclass, field
from urllib.parse import urlsplit

LAN_NETWORKS = tuple(map(ipaddress.IPv4Network, ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16')))
PROXY_HEADER = 'X-CMK-Lan-Key'
PROXY_KEY_ENV = 'CMK_LAN_PROXY_KEY'
PROXY_ORIGIN_ENV = 'CMK_LAN_ORIGIN'


def lan_ipv4(raw: str) -> str:
    try:
        address = ipaddress.IPv4Address(raw)
        if any(address in block for block in LAN_NETWORKS):
            return str(address)
    except (ipaddress.AddressValueError, TypeError):
        pass
    raise ValueError('Укажите частный IPv4-адрес контейнера: 10.*, 172.16–31.* или 192.168.*.')


@dataclass(frozen=True)
class LanGateway:
    origin: str
    authority: str
    port: int
    key: str = field(repr=False)

    @classmethod
    def from_env(cls) -> LanGateway | None:
        origin, key = os.environ.get(PROXY_ORIGIN_ENV), os.environ.get(PROXY_KEY_ENV)
        if origin is None and key is None:
            return None
        try:
            url = urlsplit(origin or '')
            ip = lan_ipv4(url.hostname or '')
            port = url.port or 0
            authority = f'{ip}:{port}'
            if (origin == 'https://' + authority and 1024 <= port <= 65535
                    and isinstance(key, str) and re.fullmatch(r'[0-9a-f]{64}', key)):
                return cls(origin, authority, port, key)
        except ValueError:
            pass
        raise ValueError('Некорректные настройки защищённого LAN-прокси.')

    def authorizes(self, headers, authority: str) -> bool:
        keys = headers.get_all(PROXY_HEADER, [])
        return (authority == self.authority and headers.get_all('X-Forwarded-Proto', []) == ['https']
                and len(keys) == 1 and bool(re.fullmatch(r'[0-9a-f]{64}', keys[0]))
                and secrets.compare_digest(keys[0], self.key))
