'use strict';

const byId = id => document.getElementById(id);
const el = {};
[ 'scan-form', 'start-url', 'scan-status', 'scan-button', 'event-count', 'schedule-range',
  'catalog-status', 'catalog-status-text', 'event-search', 'date-toggle', 'date-controls',
  'date-from', 'date-to', 'date-indicator', 'date-reset', 'date-error', 'show-all', 'show-beyond',
  'beyond-count', 'show-todo', 'todo-count', 'show-done', 'done-count', 'table-scroll', 'select-visible', 'events-body', 'table-empty', 'shown-count',
  'clear-selection', 'selected-count', 'selected-label', 'selection-hint', 'format-badge',
  'make-docs', 'export-result', 'export-note', 'result-text', 'download-word', 'download-zip', 'batch-words', 'word-links',
  'remake-docs', 'preview-empty', 'preview-content', 'preview-title', 'preview-date', 'speaker-count',
  'topic-count', 'open-program', 'source-link', 'program-dialog', 'program-dialog-heading',
  'program-dialog-date', 'program-dialog-body', 'program-source', 'help-dialog', 'open-help',
  'saved-word', 'open-monitor', 'monitor-dialog', 'monitor-times', 'monitor-summary', 'monitor-state',
  'monitor-telegram', 'monitor-last', 'monitor-next', 'monitor-note', 'monitor-restricted', 'monitor-toggle',
  'monitor-check-now', 'monitor-feedback', 'telegram-form', 'telegram-token', 'telegram-connect', 'telegram-test',
  'telegram-disconnect', 'telegram-cancel', 'telegram-env-note', 'pair-box', 'pair-bot', 'pair-code', 'pair-copy',
  'pair-remaining', 'open-settings', 'settings-dialog', 'port-form', 'server-port', 'save-port', 'active-port',
  'saved-port', 'active-port-label', 'saved-port-label', 'port-help', 'port-feedback', 'toast', 'toast-icon', 'toast-text', 'toast-close'
].forEach(id => { el[id] = byId(id); });

const state = {
  catalog: null,
  visible: [],
  selected: new Set(),
  active: null,
  scope: 'all',
  initializing: true,
  scanning: false,
  exporting: false,
  result: null,
  loadError: '',
};
const ns = 'http://www.w3.org/2000/svg';
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
let detailVersion = 0;
let toastTimer;
const checkedTime = new Intl.DateTimeFormat('ru-RU', {
  timeZone: 'Europe/Moscow', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit',
});

function make(tag, className = '', text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function icon(name) {
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('class', 'icon');
  svg.setAttribute('aria-hidden', 'true');
  const use = document.createElementNS(ns, 'use');
  use.setAttribute('href', '#i-' + name);
  svg.append(use);
  return svg;
}

function plural(n, one, few, many) {
  const mod = n % 100;
  if (mod >= 11 && mod <= 14) return many;
  return n % 10 === 1 ? one : [2, 3, 4].includes(n % 10) ? few : many;
}

function plainSearch(text) {
  return text.toLocaleLowerCase('ru-RU').replaceAll('ё', 'е').trim();
}

function readableDate(iso) {
  const [y, m, d] = iso.slice(0, 10).split('-');
  return `${d}.${m}.${y}`;
}

async function api(url, payload) {
  const options = payload === undefined ? undefined : {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  };
  const response = await fetch(url, options);
  let data;
  try { data = await response.json(); } catch { throw new Error('Сервер не вернул данные. Повторите попытку.'); }
  if (!response.ok) throw new Error(data.error || 'Не удалось выполнить запрос.');
  return data;
}

function toast(text, error = false) {
  clearTimeout(toastTimer);
  el.toast.classList.toggle('is-error', error);
  el['toast-icon'].setAttribute('href', error ? '#i-alert' : '#i-check');
  el['toast-text'].textContent = text;
  el.toast.hidden = false;
  toastTimer = setTimeout(() => { el.toast.hidden = true; }, error ? 9000 : 4500);
}

function activeEvent() {
  return state.catalog?.events.find(e => e.id === state.active) || null;
}

function useCatalog(catalog, autoSelect = false, keepResult = false) {
  const oldCount = state.selected.size;
  const previous = new Map((state.catalog?.events ?? []).map(e => [e.id, e.date]));
  state.catalog = catalog;
  state.loadError = '';
  const dates = new Map(catalog.events.map(e => [e.id, e.date]));
  state.selected = autoSelect ? new Set(catalog.events.slice(0, 1).map(e => e.id))
    : new Set([...state.selected].filter(id => dates.has(id) && dates.get(id) === previous.get(id)));
  if (!dates.has(state.active) || autoSelect) state.active = catalog.events[0]?.id || null;
  if (!keepResult || oldCount !== state.selected.size) state.result = null;
  refreshSchedule();
}

const scopeButtons = { all: 'show-all', beyond: 'show-beyond', todo: 'show-todo', done: 'show-done' };

function refreshSchedule() {
  const entries = state.catalog?.events ?? [];
  const beyond = entries.filter(e => e.on_home === false).length;
  const done = entries.filter(e => e.generated_at).length;
  if (!beyond && state.scope === 'beyond') state.scope = 'all';
  el['show-beyond'].hidden = beyond === 0;
  for (const [scope, id] of Object.entries(scopeButtons)) el[id].setAttribute('aria-pressed', String(state.scope === scope));
  el['beyond-count'].textContent = beyond;
  el['done-count'].textContent = done;
  el['todo-count'].textContent = entries.length - done;
  el['event-count'].textContent = state.initializing ? '—' : entries.length;
  el['event-count'].setAttribute('aria-label', `${entries.length} ${plural(entries.length, 'вебинар', 'вебинара', 'вебинаров')}`);

  const ordered = entries.slice().sort((a, b) => a.date.localeCompare(b.date));
  const start = ordered[0], end = ordered.at(-1);
  let range = 'Московское время (МСК)';
  if (start && end) {
    if (start.date === end.date) range = `${start.date_ru} · Время МСК`;
    else {
      const early = start.date.slice(0, 4) === end.date.slice(0, 4) ? start.day_month : start.date_ru;
      range = `${early} — ${end.date_ru} · Время МСК`;
    }
  } else if (state.initializing) range = 'Загружаем список…';
  el['schedule-range'].textContent = range;
  const checked = state.catalog?.checked_at;
  el['catalog-status'].hidden = !checked;
  if (checked) {
    const live = state.catalog.origin === 'live';
    el['catalog-status'].classList.toggle('live', live);
    el['catalog-status-text'].textContent = live ? 'Обновлено с сайта' : `Снимок от ${readableDate(checked)}`;
    el['catalog-status'].title = live ? `${checkedTime.format(new Date(checked))} МСК`
      : 'Сохранённое расписание. Чтобы проверить актуальность, обновите его с сайта.';
  }

  const from = el['date-from'].value, to = el['date-to'].value;
  const badRange = Boolean(from && to && from > to);
  el['date-error'].hidden = !badRange;
  el['date-indicator'].hidden = !(from || to);
  const terms = plainSearch(el['event-search'].value).split(/\s+/u).filter(Boolean);
  state.visible = badRange ? [] : entries.filter(e => {
    if (state.scope === 'beyond' && e.on_home !== false) return false;
    if (state.scope === 'todo' && e.generated_at) return false;
    if (state.scope === 'done' && !e.generated_at) return false;
    if ((from && from > e.date) || (to && e.date > to)) return false;
    const searchable = plainSearch(`${e.title} ${e.date_ru} ${e.date} ${readableDate(e.date)} ${e.hours}`);
    return terms.every(term => searchable.includes(term));
  });
  if (state.visible.length && !state.visible.some(e => e.id === state.active)) state.active = state.visible[0].id;
  renderRows();
  syncSelection();
  renderPreview();
}

function renderRows() {
  const list = document.createDocumentFragment();
  for (const e of state.visible) {
    const tr = make('tr');
    tr.dataset.event = e.id;
    tr.classList.toggle('new-event', Boolean(e.is_new && !e.generated_at));
    const select = make('td');
    const checkbox = make('input');
    checkbox.type = 'checkbox';
    checkbox.setAttribute('aria-label', `Выбрать: ${e.title}, ${e.day_month}`);
    checkbox.checked = state.selected.has(e.id);
    checkbox.addEventListener('change', () => {
      if (checkbox.checked) {
        state.selected.add(e.id);
        state.active = e.id;
      } else state.selected.delete(e.id);
      selectionChanged();
    });
    const checkArea = make('label', 'check-area');
    checkArea.append(checkbox);
    select.append(checkArea);
    const date = make('td');
    const time = make('span', 'row-time', e.hours);
    time.append(make('span', 'row-zone', ' МСК'));
    date.append(make('span', 'row-date', e.day_month), time);
    const title = make('td');
    title.append(make('div', 'row-title', e.title));
    const meta = make('div', 'row-meta');
    if (e.generated_at) {
      const badge = make('span', 'row-badge badge-done');
      badge.append(icon('check'), document.createTextNode('Сформировано'));
      badge.title = `${checkedTime.format(new Date(e.generated_at))} МСК`;
      meta.append(badge);
    } else if (e.is_new) meta.append(make('span', 'row-badge badge-new', 'Новое'));
    if (e.on_home === false) meta.append(make('span', 'row-badge', 'Вне главной'));
    if (meta.children.length) title.append(meta);
    const action = make('td');
    const open = make('button', 'button row-open');
    open.type = 'button';
    open.title = 'Открыть карточку';
    open.setAttribute('aria-label', 'Карточка: ' + e.title);
    open.append(icon('chevron'));
    open.addEventListener('click', () => {
      selectPreview(e.id);
      if (matchMedia('(max-width: 730px)').matches) openProgram();
    });
    action.append(open);
    tr.append(select, date, title, action);
    tr.addEventListener('click', event => {
      if (!event.target.closest('button, label, a')) selectPreview(e.id);
    });
    list.append(tr);
  }
  el['events-body'].replaceChildren(list);
  const empty = el['table-empty'];
  empty.hidden = Boolean(state.visible.length);
  if (!empty.hidden) {
    if (state.initializing) {
      empty.replaceChildren(make('span', 'spinner'), make('p', '', 'Загружаем расписание…'));
    } else if (state.loadError) {
      empty.replaceChildren(icon('alert'), make('p', '', 'Не удалось загрузить список. Обновите его с сайта.'));
    } else if (!state.catalog?.events.length) {
      empty.replaceChildren(icon('calendar'), make('p', '', 'Здесь появятся вебинары после обновления с сайта.'));
    } else {
      const reset = make('button', 'button button-quiet', 'Очистить фильтры');
      reset.type = 'button';
      reset.addEventListener('click', resetFilters);
      const statusOnly = !el['event-search'].value.trim() && !el['date-from'].value && !el['date-to'].value;
      const message = statusOnly && state.scope === 'done' ? 'Здесь будут вебинары с сохранённым Word.'
        : statusOnly && state.scope === 'todo' ? 'Все вебинары в этом списке уже сформированы.'
        : 'По этим фильтрам вебинары не найдены.';
      empty.replaceChildren(icon(state.scope === 'done' ? 'archive' : 'search'), make('p', '', message), reset);
    }
  }
}

function resetFilters() {
  el['event-search'].value = '';
  el['date-from'].value = '';
  el['date-to'].value = '';
  state.scope = 'all';
  refreshSchedule();
  el['event-search'].focus();
}

function selectPreview(id) {
  state.active = id;
  syncRows();
  renderPreview();
}

function syncRows() {
  for (const tr of el['events-body'].rows) {
    const id = tr.dataset.event;
    tr.classList.toggle('active', id === state.active);
    const box = tr.querySelector('input');
    box.checked = state.selected.has(id);
    box.disabled = state.exporting;
  }
}

function selectionChanged() {
  state.result = null;
  syncSelection();
  renderPreview();
}

function syncSelection() {
  const n = state.selected.size;
  const visibleSelected = state.visible.filter(e => state.selected.has(e.id)).length;
  const all = el['select-visible'];
  all.checked = visibleSelected > 0 && visibleSelected === state.visible.length;
  all.indeterminate = visibleSelected > 0 && !all.checked;
  all.disabled = state.visible.length === 0 || state.exporting;
  el['clear-selection'].hidden = n === 0;
  el['clear-selection'].disabled = state.exporting;
  el['shown-count'].textContent = `Показано ${state.visible.length} из ${state.catalog?.events.length ?? 0}`;
  el['selected-count'].textContent = n;
  const noun = plural(n, 'вебинар', 'вебинара', 'вебинаров');
  el['selected-label'].textContent = `${noun === 'вебинар' ? 'Выбран' : 'Выбрано'} ${noun}`;
  const format = !n ? 'Отметьте карточки в списке' : n === 1 ? 'Один Word и ZIP' : 'Word по одному или общий ZIP';
  const hidden = n - visibleSelected;
  el['selection-hint'].textContent = hidden ? `${format} · скрыто фильтрами: ${hidden}` : format;
  el['make-docs'].disabled = !n || state.exporting || state.scanning;
  el['remake-docs'].disabled = state.exporting || state.scanning;
  el['make-docs'].hidden = Boolean(state.result);
  el['make-docs'].setAttribute('aria-busy', String(state.exporting));
  el['make-docs'].querySelector('span').textContent = state.exporting ? 'Формируем…' : 'Сформировать Word';
  el['make-docs'].querySelector('use').setAttribute('href', state.exporting ? '#i-refresh' : '#i-file');
  el['make-docs'].classList.toggle('is-loading', state.exporting);
  el['export-result'].hidden = !state.result;
  const result = state.result;
  el['export-note'].textContent = result ? 'Последний Word сохранён в истории.'
    : state.exporting ? 'Заполняем бланк ЦМК' : 'Ссылки появятся после формирования';
  if (result) {
    const single = result.count === 1;
    el['result-text'].textContent = single ? 'Документ готов' : `Готово: ${result.count} ${plural(result.count, 'документ', 'документа', 'документов')}`;
    el['download-zip'].classList.toggle('button-primary', !single);
    el['download-zip'].classList.toggle('button-outline', single);
    downloadLink(el['download-zip'], result.zip);
    el['download-word'].hidden = !single;
    if (single) downloadLink(el['download-word'], result.documents[0]);
    el['batch-words'].hidden = single;
    if (!single && el['word-links'].dataset.result !== result.zip.url) {
      const links = result.documents.map(doc => {
        const li = make('li');
        const a = make('a', '', doc.filename.replace(/\.docx$/u, ''));
        downloadLink(a, doc);
        li.append(a);
        return li;
      });
      el['word-links'].replaceChildren(...links);
      el['word-links'].dataset.result = result.zip.url;
      el['batch-words'].open = false;
    }
  } else {
    el['download-word'].removeAttribute('href');
    el['download-zip'].removeAttribute('href');
  }
  syncRows();
  el['scan-button'].disabled = state.scanning || state.exporting;
}

function downloadLink(link, { url, filename }) {
  link.href = url;
  link.download = filename;
  link.title = filename;
}

function renderPreview() {
  const e = activeEvent();
  el['preview-content'].hidden = !e;
  el['preview-empty'].hidden = Boolean(e);
  if (!e) return;
  el['preview-date'].textContent = `${e.day_month} · ${e.hours} МСК`;
  el['preview-title'].textContent = e.title;
  el['speaker-count'].textContent = `${e.speaker_count} ${plural(e.speaker_count, 'ведущий', 'ведущих', 'ведущих')}`;
  el['topic-count'].textContent = `${e.topic_count} ${plural(e.topic_count, 'тема', 'темы', 'тем')}`;
  el['source-link'].href = e.url;
  el['saved-word'].hidden = !e.generated_at;
  if (e.generated_at) {
    const query = new URLSearchParams({ catalog: state.catalog.id, event: e.id });
    downloadLink(el['saved-word'], { url: '/api/saved?' + query, filename: e.saved_name });
  } else el['saved-word'].removeAttribute('href');
}

function scanMode() {
  return el['scan-form'].querySelector('[name="scan-mode"]:checked').value;
}

function scanFeedback(message, error = false) {
  el['scan-status'].textContent = message;
  el['scan-status'].hidden = !message;
  el['scan-status'].classList.toggle('is-error', error);
}

function scanBusy(active) {
  state.scanning = active;
  el['scan-button'].querySelector('span').textContent = active ? 'Обновляем…' : 'Обновить с сайта';
  el['scan-button'].classList.toggle('is-loading', active);
  el['scan-button'].setAttribute('aria-busy', String(active));
  el['start-url'].readOnly = active;
  for (const n of el['scan-form'].querySelectorAll('[type=radio]')) n.disabled = active;
  syncSelection();
}

async function scan(event) {
  event.preventDefault();
  if (state.scanning || state.exporting) return;
  const mode = scanMode(), start = el['start-url'].value.trim();
  if (mode === 'single' && !start) {
    scanFeedback('Для одного вебинара укажите ссылку или код карточки.', true);
    el['start-url'].setAttribute('aria-invalid', 'true');
    el['start-url'].focus();
    return;
  }
  el['start-url'].removeAttribute('aria-invalid');
  scanBusy(true);
  scanFeedback(mode === 'chain' ? 'Проверяем переходы «Следующий вебинар»…' : 'Открываем карточку вебинара…');
  try {
    const job = await api('/api/scan', { mode, start });
    for (let i = 0; i < 180; i++) {
      await delay(i === 0 ? 470 : 950);
      const progress = await api('/api/scan/' + encodeURIComponent(job.id));
      if (progress.state === 'error') throw new Error(progress.error);
      if (progress.state === 'ready') {
        if (mode === 'single') {
          el['event-search'].value = '';
          el['date-from'].value = '';
          el['date-to'].value = '';
          state.scope = 'all';
        }
        useCatalog(progress.catalog, mode === 'single');
        scanFeedback('');
        const n = progress.catalog.events.length;
        toast(`Расписание обновлено: ${n} ${plural(n, 'вебинар', 'вебинара', 'вебинаров')}.`);
        el['table-scroll'].scrollTop = 0;
        return;
      }
      if (progress.count) scanFeedback(`Проверено карточек: ${progress.count}. Читаем расписание…`);
    }
    throw new Error('Проверка занимает больше времени. Попробуйте обновить список ещё раз.');
  } catch (error) {
    scanFeedback(error.message || 'Не удалось обновить расписание.', true);
    if (state.catalog?.events.length) toast('Обновление не завершилось. Предыдущий список сохранён.', true);
  } finally {
    scanBusy(false);
  }
}

async function makeDocs() {
  if (!state.selected.size || state.exporting || state.scanning) return;
  state.exporting = true;
  state.result = null;
  syncSelection();
  try {
    state.result = await api('/api/export', { catalog: state.catalog.id, event_ids: [...state.selected] });
    const names = new Map(state.result.documents.map(doc => [doc.event_id, doc.filename]));
    for (const e of state.catalog.events) if (names.has(e.id)) {
      e.generated_at = state.result.generated_at;
      e.saved_name = names.get(e.id);
    }
    toast(state.result.count === 1 ? 'Word и ZIP готовы к скачиванию.' : 'ZIP и отдельные Word готовы к скачиванию.');
  } catch (error) {
    toast(error.message || 'Не удалось сформировать файлы.', true);
  } finally {
    state.exporting = false;
    refreshSchedule();
    if (state.result) el[state.result.count === 1 ? 'download-word' : 'download-zip'].focus({ preventScroll: true });
  }
}

function dialogBody(e) {
  const out = document.createDocumentFragment();
  out.append(make('p', '', e.abstract), make('p', '', e.audience));
  if (e.speakers.length) {
    out.append(make('h3', '', 'Ведущие'));
    const ul = make('ul');
    for (const s of e.speakers) {
      const li = make('li');
      li.append(make('strong', '', s.name), document.createTextNode(' — ' + s.role));
      ul.append(li);
    }
    out.append(ul);
  }
  out.append(make('h3', '', 'Темы'));
  const topics = make('ol');
  for (const t of e.topics) {
    const li = make('li');
    const title = t.title.trim();
    li.append(make('strong', '', /[.!?…]$/u.test(title) ? title : title + '.'), document.createTextNode(' ' + t.details));
    topics.append(li);
  }
  if (e.closing) topics.append(make('li', '', e.closing[0].toLocaleUpperCase('ru-RU') + e.closing.slice(1) + '.'));
  out.append(topics);
  if (e.fee || e.access) out.append(make('h3', '', 'Условия участия'), make('p', '', [e.fee, e.access].filter(Boolean).join(' ')));
  for (const warning of e.warnings || []) out.append(make('p', 'help-note', warning));
  return out;
}

async function openProgram() {
  const e = activeEvent();
  if (!e) return;
  const version = ++detailVersion;
  const dialog = el['program-dialog'];
  el['program-dialog-heading'].textContent = e.title;
  el['program-dialog-date'].textContent = `${e.date_ru} · ${e.hours} МСК`;
  el['program-source'].href = e.url;
  const wait = make('div', 'dialog-loading');
  wait.append(make('span', 'spinner'), make('span', 'subtle', 'Загружаем программу…'));
  el['program-dialog-body'].replaceChildren(wait);
  if (!dialog.open) dialog.showModal();
  dialog.scrollTop = 0;
  try {
    const params = new URLSearchParams({ catalog: state.catalog.id, event: e.id });
    const detail = await api('/api/detail?' + params);
    if (version !== detailVersion) return;
    el['program-dialog-heading'].textContent = detail.full_title;
    el['program-dialog-body'].replaceChildren(dialogBody(detail));
  } catch (error) {
    if (version === detailVersion) el['program-dialog-body'].replaceChildren(make('p', 'help-note', error.message));
  }
}

el['scan-form'].addEventListener('submit', scan);
for (const mode of el['scan-form'].querySelectorAll('[type=radio]')) mode.addEventListener('change', () => {
  const one = scanMode() === 'single';
  el['start-url'].placeholder = one ? 'Ссылка или код' : 'Начать с главной';
  el['start-url'].required = one;
  el['start-url'].removeAttribute('aria-invalid');
  scanFeedback('');
});
el['start-url'].setAttribute('aria-describedby', 'scan-status');
el['start-url'].addEventListener('input', () => {
  if (el['start-url'].hasAttribute('aria-invalid')) {
    el['start-url'].removeAttribute('aria-invalid');
    scanFeedback('');
  }
});
el['event-search'].addEventListener('input', () => { refreshSchedule(); el['table-scroll'].scrollTop = 0; });
for (const [scope, id] of Object.entries(scopeButtons)) el[id].addEventListener('click', () => {
  state.scope = scope;
  refreshSchedule();
  el['table-scroll'].scrollTop = 0;
});
el['date-toggle'].addEventListener('click', () => {
  const open = el['date-controls'].hidden;
  el['date-controls'].hidden = !open;
  el['date-toggle'].setAttribute('aria-expanded', String(open));
  if (open) el['date-from'].focus();
});
for (const key of ['date-from', 'date-to']) el[key].addEventListener('change', () => { refreshSchedule(); el['table-scroll'].scrollTop = 0; });
el['date-reset'].addEventListener('click', () => {
  el['date-from'].value = '';
  el['date-to'].value = '';
  refreshSchedule();
});
el['select-visible'].addEventListener('change', () => {
  const checked = el['select-visible'].checked;
  for (const e of state.visible) {
    if (checked) state.selected.add(e.id);
    else state.selected.delete(e.id);
  }
  selectionChanged();
});
el['clear-selection'].addEventListener('click', () => { state.selected.clear(); selectionChanged(); });
el['make-docs'].addEventListener('click', makeDocs);
el['remake-docs'].addEventListener('click', makeDocs);
el['open-program'].addEventListener('click', openProgram);
el['program-dialog'].addEventListener('close', () => { detailVersion++; });
el['open-help'].addEventListener('click', () => el['help-dialog'].showModal());
el['toast-close'].addEventListener('click', () => { el.toast.hidden = true; });

const monitorUi = { data: null, pending: false, task: null, pollId: null, loading: false };
const taskActive = task => ['starting', 'waiting', 'finishing', 'cancelling'].includes(task?.state);

function feedback(id, message = '', error = false) {
  const box = el[id];
  box.textContent = message;
  box.hidden = !message;
  box.classList.toggle('is-error', error);
}

function renderMonitor(data) {
  const previous = monitorUi.data;
  monitorUi.data = data;
  el['monitor-restricted'].hidden = Boolean(data.admin);
  el['monitor-times'].replaceChildren(...data.times.map(t => make('span', '', t)));
  el['monitor-state'].textContent = data.checking ? 'Проверяем расписание…'
    : data.managed && data.enabled ? 'Расписание включено'
    : data.external ? 'Запущен отдельный мониторинг'
    : data.managed ? 'Расписание приостановлено' : 'Автопроверка не запущена';
  el['monitor-summary'].classList.toggle('is-running', data.running || data.checking);
  el['monitor-telegram'].textContent = (data.configured ? 'Чат подключён' : 'Чат не подключён')
    + (data.pending ? ` · в очереди: ${data.pending}` : '');
  el['monitor-telegram'].classList.toggle('is-connected', data.configured);
  el['monitor-last'].textContent = data.last_finish ? `Последняя проверка: ${checkedTime.format(new Date(data.last_finish))} МСК` : 'Проверок ещё не было';
  el['monitor-next'].textContent = data.next_check ? `Следующая: ${checkedTime.format(new Date(data.next_check))} МСК` : '';
  el['monitor-note'].textContent = data.last_note || '';
  el['monitor-note'].classList.toggle('is-error', data.last_ok === false);
  if (data.task && !monitorUi.pollId) followTelegramTask(data.task);
  renderMonitorControls();
  if (!data.checking && (previous?.checking || (data.last_finish && data.last_finish !== previous?.last_finish))) refreshStored();
}

function renderMonitorControls() {
  const opt = monitorUi.data;
  const locked = !opt?.admin || monitorUi.pending;
  const job = monitorUi.task;
  const busy = taskActive(job);
  el['monitor-toggle'].disabled = locked || !opt?.managed;
  el['monitor-toggle'].querySelector('span').textContent = opt?.enabled ? 'Приостановить расписание' : 'Включить расписание';
  el['monitor-check-now'].disabled = locked || !opt?.managed || Boolean(opt.checking);
  el['telegram-token'].disabled = el['telegram-connect'].disabled = locked || busy || Boolean(opt?.env_managed);
  el['telegram-connect'].textContent = opt?.configured ? 'Перепривязать бота' : 'Привязать бота';
  el['telegram-env-note'].hidden = !opt?.env_managed;
  el['telegram-form'].hidden = Boolean(opt?.env_managed);
  el['telegram-test'].hidden = !opt?.configured;
  el['telegram-test'].disabled = locked || busy;
  el['telegram-disconnect'].hidden = !opt?.configured || Boolean(opt?.env_managed);
  el['telegram-disconnect'].disabled = locked || busy;
  el['telegram-cancel'].hidden = !(job?.kind === 'pair' && ['starting','waiting','cancelling'].includes(job.state));
  el['telegram-cancel'].disabled = locked || job?.state === 'cancelling';
}

async function refreshMonitor() {
  if (monitorUi.loading) return;
  monitorUi.loading = true;
  try {
    renderMonitor(await api('/api/watchdog'));
  } catch {
    el['monitor-state'].textContent = 'Не удалось получить состояние. Откройте окно заново.';
  } finally {
    monitorUi.loading = false;
  }
}

function renderTelegramTask(task) {
  monitorUi.task = task;
  el['pair-box'].hidden = task.state !== 'waiting';
  if (!el['pair-box'].hidden) {
    el['pair-bot'].href = task.bot_url;
    el['pair-bot'].textContent = '@' + task.username;
    el['pair-code'].textContent = task.code;
    el['pair-remaining'].textContent = `Код действует ещё ${task.remaining} с.`;
  } else {
    el['pair-code'].textContent = '';
    el['pair-bot'].removeAttribute('href');
  }
  const message = task.state === 'waiting' ? '' : task.message;
  if (el['monitor-feedback'].textContent !== message) feedback('monitor-feedback', message, task.state === 'error');
  renderMonitorControls();
}

async function followTelegramTask(start) {
  renderTelegramTask(start);
  if (monitorUi.pollId === start.id) return;
  if (!taskActive(start)) {
    refreshMonitor();
    return;
  }
  monitorUi.pollId = start.id;
  let task = start;
  try {
    while (taskActive(task) && monitorUi.pollId === start.id) {
      await delay(1050);
      task = await api('/api/watchdog/task/' + encodeURIComponent(start.id));
      if (monitorUi.pollId !== start.id) break;
      renderTelegramTask(task);
    }
  } catch (error) {
    renderTelegramTask({ ...task, state: 'error', message: error.message || 'Не удалось получить состояние привязки.' });
  } finally {
    if (monitorUi.pollId === start.id) monitorUi.pollId = null;
    refreshMonitor();
  }
}

async function monitorAction(action, params = {}, success = '') {
  if (!monitorUi.data?.admin || monitorUi.pending) return;
  monitorUi.pending = true;
  feedback('monitor-feedback');
  renderMonitorControls();
  try {
    const result = await api('/api/watchdog', {action, ...params});
    if (result.id) followTelegramTask(result);
    else {
      renderMonitor(result);
      feedback('monitor-feedback', success);
    }
  } catch (error) {
    feedback('monitor-feedback', error.message || 'Не удалось выполнить действие.', true);
  } finally {
    monitorUi.pending = false;
    renderMonitorControls();
  }
}

el['open-monitor'].addEventListener('click', () => {
  el['monitor-dialog'].showModal();
  refreshMonitor();
});
el['monitor-dialog'].addEventListener('close', () => {
  el['telegram-token'].value = '';
  refreshStored();
});
el['monitor-toggle'].addEventListener('click', () => {
  const enabled = !monitorUi.data?.enabled;
  monitorAction('schedule', {enabled}, enabled ? 'Расписание сохранено и включено.' : 'Следующие автоматические проверки приостановлены.');
});
el['monitor-check-now'].addEventListener('click', () => monitorAction('check', {}, 'Проверка запущена. Результат появится выше.'));
el['telegram-form'].addEventListener('submit', e => {
  e.preventDefault();
  const secret = el['telegram-token'].value.trim();
  el['telegram-token'].value = '';
  if (secret) monitorAction('pair', {token: secret});
});
el['telegram-test'].addEventListener('click', () => monitorAction('test'));
el['telegram-disconnect'].addEventListener('click', () => {
  if (window.confirm('Отвязать этот чат? История вебинаров останется.')) monitorAction('disconnect', {}, 'Чат отвязан. Новые уведомления останутся в очереди.');
});
el['telegram-cancel'].addEventListener('click', () => {
  if (monitorUi.task) monitorAction('cancel', {id: monitorUi.task.id});
});
el['pair-copy'].addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(el['pair-code'].textContent);
    toast('Код скопирован.');
  } catch {
    const range = document.createRange();
    range.selectNodeContents(el['pair-code']);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
  }
});

let serverSettings = null;
let settingsBusy = false;
function renderSettings(data) {
  serverSettings = data;
  const lan = Boolean(data.lan_port);
  el['active-port-label'].textContent = lan ? 'HTTPS-порт в LAN' : 'Сейчас на сервере';
  el['active-port'].textContent = lan ? data.lan_port : data.active_port;
  el['saved-port-label'].textContent = lan ? 'Внутренний порт службы' : 'Порт в настройках';
  el['saved-port'].textContent = lan ? data.active_port : data.saved_port;
  el['port-form'].hidden = lan;
  el['server-port'].value = data.saved_port;
  el['server-port'].disabled = el['save-port'].disabled = !data.admin || data.fixed_port || settingsBusy;
  el['port-help'].textContent = lan ? `Панель: ${data.lan_url}/. Для смены HTTPS-порта выполните в консоли LXC: cmk-lan-config port НОМЕР_ПОРТА.`
    : !data.admin ? 'Изменение доступно из локальной панели или через SSH-туннель.'
    : data.fixed_port ? 'Порт задан параметром --port. Запустите панель без этого параметра, чтобы менять сохранённый порт.'
    : 'Новый порт вступит в силу после перезапуска панели. На VPS: sudo systemctl restart cmk-webinars. Затем обновите назначение SSH-туннеля.';
}

el['open-settings'].addEventListener('click', async () => {
  el['settings-dialog'].showModal();
  el['server-port'].disabled = el['save-port'].disabled = true;
  feedback('port-feedback');
  try {
    renderSettings(await api('/api/settings'));
  } catch (error) {
    feedback('port-feedback', error.message || 'Не удалось прочитать настройки.', true);
  }
});
el['port-form'].addEventListener('submit', async e => {
  e.preventDefault();
  if (settingsBusy || !serverSettings?.admin || serverSettings.fixed_port) return;
  const port = el['server-port'].valueAsNumber;
  if (!Number.isInteger(port) || port < 1024 || port > 65535) {
    feedback('port-feedback', 'Укажите целое число от 1024 до 65535.', true);
    return;
  }
  settingsBusy = true;
  el['server-port'].disabled = el['save-port'].disabled = true;
  try {
    const result = await api('/api/settings', {port});
    renderSettings(result);
    feedback('port-feedback', port === result.active_port ? `Порт ${port} сохранён и уже используется.`
      : `Порт ${port} сохранён. Сейчас панель остаётся на порту ${result.active_port}.`);
  } catch (error) {
    feedback('port-feedback', error.message || 'Не удалось сохранить порт.', true);
  } finally {
    settingsBusy = false;
    el['server-port'].disabled = el['save-port'].disabled = !serverSettings?.admin || serverSettings.fixed_port;
  }
});

let refreshing = false;
async function refreshStored() {
  const current = state.catalog;
  if (!current?.tracked || state.scanning || state.exporting || refreshing || document.hidden) return;
  refreshing = true;
  try {
    const update = await api('/api/catalog');
    if (state.catalog !== current || state.scanning || state.exporting) return;
    if (update.id !== current.id || update.events.some((e, i) => e.generated_at !== current.events[i]?.generated_at)) {
      useCatalog(update, false, true);
    }
  } catch { /* A network hiccup must not wipe the currently displayed list. */ }
  finally { refreshing = false; }
}
window.addEventListener('focus', refreshStored);
setInterval(refreshStored, 30_000);
setInterval(() => { if (el['monitor-dialog'].open) refreshMonitor(); }, 3000);

async function initialize() {
  try {
    const catalog = await api('/api/catalog');
    // Do not replace a live list if a user started an update on a slow connection.
    if (!state.catalog) useCatalog(catalog, true);
  } catch (error) {
    state.loadError = error.message;
  } finally {
    state.initializing = false;
    refreshSchedule();
  }
}
initialize();
