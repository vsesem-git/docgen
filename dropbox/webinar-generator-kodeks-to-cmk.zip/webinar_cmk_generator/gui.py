#!/usr/bin/env python3
"""Локальная браузерная панель поверх генератора программ ЦМК."""
from __future__ import annotations

import argparse
import io
import ipaddress
import json
import re
import secrets
import signal
import socket
import sqlite3
import sys
import webbrowser
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import BoundedSemaphore, Lock, Timer
from time import monotonic
from urllib.parse import parse_qs, quote, urlsplit
from zipfile import ZIP_DEFLATED, ZipFile

from cmk_docx import plain_title, render
from generate_webinars import safe_filename
from lan_gateway import LanGateway, PROXY_HEADER
from schedule_data import ROOT, Schedule, event_key, fetch_schedule, load_snapshot
from site_kodeks import Event, SourceError, canonical_event
from storage import DEFAULT_WEB_PORT, Store, data_dir, validate_web_port
from telegram_notify import TelegramError
from web_monitor import ControlError, WebMonitor

UI = ROOT / 'ui'
TEMPLATE = ROOT / 'layout-cmk.docx'
DOCX_MIME = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
ASSETS = {
    'index.html': 'text/html; charset=utf-8', 'styles.css': 'text/css; charset=utf-8',
    'app.js': 'text/javascript; charset=utf-8', 'logo.svg': 'image/svg+xml', 'hero.svg': 'image/svg+xml',
    'golos-latin.woff2': 'font/woff2', 'golos-cyrillic.woff2': 'font/woff2',
}
CSP = "default-src 'none'; script-src 'self'; style-src 'self'; font-src 'self'; img-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'"


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def token() -> str:
    return secrets.token_urlsafe(18)


@dataclass(frozen=True)
class Catalog:
    id: str
    entries: tuple[Event, ...]
    home: frozenset[str] | None
    checked_at: str | None
    origin: str
    tracked: bool = False

    @classmethod
    def from_schedule(cls, key: str, schedule: Schedule, *, tracked: bool = False) -> Catalog:
        return cls(key, schedule.entries, schedule.home, schedule.checked_at, schedule.origin, tracked)

    def list_payload(self, statuses: dict[str, dict]) -> dict:
        return {'id': self.id, 'origin': self.origin, 'checked_at': self.checked_at, 'tracked': self.tracked,
                'home_known': self.home is not None, 'events': [self.row(e, statuses.get(event_key(e))) for e in self.entries]}

    def row(self, e: Event, status: dict | None = None) -> dict:
        return {
            'id': e.url, 'url': e.url, 'title': e.menu_title or plain_title(e.title),
            'date': e.day.isoformat(), 'date_ru': e.date_ru, 'day_month': e.day_month,
            'hours': e.hours, 'on_home': None if self.home is None else e.url in self.home,
            'speaker_count': len(e.speakers), 'topic_count': len(e.topics), **(status or {}),
        }

    def find(self, event_id: str) -> Event:
        for e in self.entries:
            if e.url == event_id:
                return e
        raise ApiError('Карточка не найдена в этом списке. Обновите расписание.', 404)

    def detail(self, event_id: str) -> dict:
        e = self.find(event_id)
        return {**self.row(e), 'full_title': plain_title(e.title), 'abstract': e.abstract, 'audience': e.audience,
                'speakers': [{'name': n, 'role': r} for n, r in e.speakers],
                'topics': [{'title': t.title, 'details': t.details} for t in e.topics],
                'closing': e.closing, 'fee': e.fee, 'access': e.access_and_discounts, 'warnings': e.warnings}


@dataclass(frozen=True)
class Download:
    name: str
    payload: bytes
    mime: str


@dataclass(frozen=True)
class ExportBatch:
    archive: Download
    documents: tuple[Download, ...]


@dataclass
class Job:
    id: str
    mode: str
    start: str | None
    state: str = 'working'
    progress: int = 0
    catalog_id: str = ''
    error: str = ''
    finished_at: float = 0.


def start_address(raw: str) -> str:
    if re.match(r'^(?:www\.)?web-kodeks\.ru(?=/|$)', raw, re.I):
        raw = 'http://' + raw
    try:
        u = canonical_event(raw)
    except (ValueError, TypeError) as exc:
        raise ApiError('Укажите ссылку на карточку web-kodeks.ru или её код, например tpk.') from exc
    parts = urlsplit(u)
    if parts.query or not re.fullmatch(r'/[a-z0-9][a-z0-9_-]{0,80}(?:\.html)?', parts.path, re.I):
        raise ApiError('Нужен адрес карточки, например http://www.web-kodeks.ru/tpk.')
    return u


class App:
    def __init__(self, directory: Path | None = None):
        snapshot = load_snapshot()
        self.store = Store(data_dir(directory))
        self.store.seed(snapshot)
        self.watch = WebMonitor(self.store)
        self.snapshot = Catalog.from_schedule('snapshot', snapshot, tracked=True)
        self.latest_catalog = self.snapshot
        self.edits = json.loads((ROOT / 'editorial.json').read_text(encoding='utf-8'))
        self.lock = Lock()
        self.pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix='schedule')
        self.export_slots = BoundedSemaphore(2)
        self.catalogs: OrderedDict[str, Catalog] = OrderedDict()
        self.jobs: dict[str, Job] = {}
        self.bundles: OrderedDict[str, tuple[float, ExportBatch]] = OrderedDict()

    def home_catalog(self) -> Catalog:
        with self.lock:
            db_item = self.store.latest(after=self.latest_catalog.id)
            if db_item:
                revision, schedule = db_item
                self.latest_catalog = Catalog.from_schedule(revision, schedule, tracked=True)
                self.remember(self.latest_catalog)
            return self.latest_catalog

    def remember(self, catalog: Catalog) -> None:
        # Called while holding self.lock.
        self.catalogs[catalog.id] = catalog
        self.catalogs.move_to_end(catalog.id)
        while len(self.catalogs) > 12:
            self.catalogs.popitem(last=False)

    def catalog(self, key: str) -> Catalog:
        if key == 'snapshot':
            return self.snapshot
        with self.lock:
            found = self.catalogs.get(key)
            if found:
                self.catalogs.move_to_end(key)
                return found
        latest = self.home_catalog()
        if latest.id == key:
            return latest
        raise ApiError('Этот список больше не сохранён. Обновите расписание.', 404)

    def catalog_payload(self, catalog: Catalog) -> dict:
        return catalog.list_payload(self.store.statuses(catalog.entries))

    def monitor_payload(self, admin: bool = False) -> dict:
        return self.watch.status(admin)

    def start_scan(self, data: dict) -> str:
        mode, raw = data.get('mode'), data.get('start', '')
        if mode not in ('chain', 'single') or not isinstance(raw, str) or len(raw) > 250:
            raise ApiError('Проверьте режим поиска и адрес карточки.')
        value = raw.strip()
        if mode == 'single' and not value:
            raise ApiError('Для одного вебинара укажите адрес карточки.')
        start = start_address(value) if value else None
        with self.lock:
            now = monotonic()
            for job_id, j in list(self.jobs.items()):
                if j.state != 'working' and now - j.finished_at > 3600:
                    del self.jobs[job_id]
            active = [j for j in self.jobs.values() if j.state == 'working']
            for j in active:
                if (mode, start) == (j.mode, j.start):
                    return j.id
            if len(active) >= 2:
                raise ApiError('Сейчас уже обновляются два списка. Попробуйте немного позже.', 429)
            job = Job(token(), mode, start)
            self.jobs[job.id] = job
        self.pool.submit(self.scan, job)
        return job.id

    def scan(self, job: Job) -> None:
        def progress(total: int):
            with self.lock:
                job.progress = total

        try:
            schedule = fetch_schedule(mode=job.mode, start=job.start, on_page=progress)
            if job.mode == 'chain' and not job.start:
                self.store.save_schedule(schedule)
                item = self.home_catalog()
            else:
                item = Catalog.from_schedule(token(), schedule)
            with self.lock:
                self.remember(item)
                job.state, job.catalog_id, job.finished_at = 'ready', item.id, monotonic()
        except Exception as exc:
            if isinstance(exc, sqlite3.Error):
                reason = 'Не удалось сохранить расписание. Проверьте папку данных и повторите попытку.'
            else:
                reason = str(exc) if isinstance(exc, SourceError) else 'Не удалось прочитать сайт. Проверьте адрес и повторите попытку.'
            with self.lock:
                job.state, job.error, job.finished_at = 'error', reason, monotonic()

    def job_payload(self, job_id: str) -> dict:
        with self.lock:
            j = self.jobs.get(job_id)
            if j is None:
                raise ApiError('Проверка не найдена. Обновите расписание ещё раз.', 404)
            state, count, key, error = j.state, j.progress, j.catalog_id, j.error
        payload = {'state': state, 'count': count}
        if state == 'ready':
            payload['catalog'] = self.catalog_payload(self.catalog(key))
        if error:
            payload['error'] = error
        return payload

    def make_programs(self, data: dict) -> dict:
        key, ids = data.get('catalog'), data.get('event_ids')
        if (not isinstance(key, str) or not isinstance(ids, list) or not (1 <= len(ids) <= 180)
                or not all(isinstance(i, str) and len(i) < 600 for i in ids)):
            raise ApiError('Отметьте хотя бы один вебинар в списке.')
        catalog = self.catalog(key)
        wanted = set(ids)
        events = tuple(e for e in catalog.entries if e.url in wanted)
        if len(events) != len(wanted):
            raise ApiError('Некоторые карточки больше не в списке. Отметьте их снова.', 404)
        existing = set()
        titles = []
        for event in events:
            edit = self.edits.get(f'{event.day.isoformat()}/{event.slug}', {})
            stem = safe_filename(f'{event.day_month} - {edit.get("file_title") or event.menu_title or plain_title(event.title)}')
            stem = stem[:95].rstrip(' .')  # Avoid very long path components when ZIP is unpacked on Windows.
            original, j = stem, 2
            while stem.casefold() in existing:
                stem = f'{original} ({j})'
                j += 1
            existing.add(stem.casefold())
            titles.append((stem + '.docx', event, edit))
        if not self.export_slots.acquire(blocking=False):
            raise ApiError('Генератор занят. Повторите экспорт через несколько секунд.', 429)
        try:
            with TemporaryDirectory(prefix='cmk-webinars-') as tmp:
                for name, e, edit in titles:
                    try:
                        render(e, Path(tmp, name), TEMPLATE, edit)
                    except Exception as exc:
                        raise ApiError(f'Не удалось оформить вебинар «{e.menu_title or plain_title(e.title)}». Проверьте исходную карточку и шаблон.', 422) from exc
                saved = [(e, name, Path(tmp, name).read_bytes()) for name, e, _ in titles]
            docs = tuple(Download(name, content, DOCX_MIME) for _, name, content in saved)
            stream = io.BytesIO()
            with ZipFile(stream, 'w', ZIP_DEFLATED, compresslevel=5) as archive:
                for doc in docs:
                    folder = doc.name.removesuffix('.docx')
                    archive.writestr(folder + '/', b'')
                    archive.writestr(folder + '/' + doc.name, doc.payload)
            if len(docs) == 1:
                zip_name = docs[0].name.removesuffix('.docx') + '.zip'
            else:
                days = sorted(e.day for e in events)
                span = days[0].strftime('%d.%m.%Y')
                if days[-1] != days[0]:
                    span += f'–{days[-1]:%d.%m.%Y}'
                zip_name = f'Программы ЦМК — {span}.zip'
            zip_file = Download(zip_name, stream.getvalue(), 'application/zip')
            try:
                stamp = self.store.save_programs(saved)
            except sqlite3.Error:
                raise ApiError('Не удалось сохранить программы в историю. Проверьте папку данных и повторите экспорт.', 500) from None
            bundle_id = token()
            with self.lock:
                now = monotonic()
                self.drop_old_bundles(now)
                self.bundles[bundle_id] = (now, ExportBatch(zip_file, docs))
                while len(self.bundles) > 10:
                    self.bundles.popitem(last=False)
            path = '/api/download/' + bundle_id
            return {'count': len(docs), 'generated_at': stamp,
                    'zip': {'url': path + '/zip', 'filename': zip_name},
                    'documents': [{'event_id': event.url, 'url': f'{path}/word/{i}', 'filename': name}
                                  for i, (event, name, _) in enumerate(saved)]}
        finally:
            self.export_slots.release()

    def drop_old_bundles(self, now: float) -> None:
        expired = [key for key, (time_created, _) in self.bundles.items() if now - time_created > 3600]
        for key in expired:
            del self.bundles[key]

    def bundle(self, key: str) -> ExportBatch:
        with self.lock:
            self.drop_old_bundles(monotonic())
            found = self.bundles.get(key)
            if found:
                return found[1]
        raise ApiError('Время скачивания истекло. Сформируйте файлы заново.', 404)


class Server(ThreadingHTTPServer):
    request_queue_size = 32
    daemon_threads = True

    def __init__(self, address: tuple[str, int], app: App, *, fixed_port: bool = False):
        self.app = app
        self.fixed_port = fixed_port
        self.lan = LanGateway.from_env()
        super().__init__(address, Handler)
        self.loopback_only = ipaddress.ip_address(self.server_address[0]).is_loopback
        if self.lan and not self.loopback_only:
            self.server_close()
            raise ValueError('За LAN-прокси сама панель должна слушать только 127.0.0.1.')
        if self.loopback_only:
            self.app.watch.start()

    def server_close(self) -> None:
        self.app.watch.close()
        super().server_close()


class Handler(BaseHTTPRequestHandler):
    server_version = 'CMK-GUI/1.3'

    def log_request(self, code='-', size='-') -> None:
        if isinstance(code, int) and code >= 400:
            super().log_request(code, size)

    @property
    def app(self) -> App:
        return self.server.app

    def reply(self, body: bytes, content_type: str, status: int = 200, *, name: str | None = None, cache=False) -> None:
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cache-Control', 'public, max-age=600' if cache else 'no-store')
        if content_type.startswith('text/html'):
            local = self.server.loopback_only
            self.send_header('Content-Security-Policy', CSP + ("; frame-ancestors 'none'" if local else ''))
            if local:
                self.send_header('X-Frame-Options', 'DENY')
        if name:
            fallback = 'programs.zip' if name.endswith('.zip') else 'program.docx'
            self.send_header('Content-Disposition', f"attachment; filename=\"{fallback}\"; filename*=UTF-8''{quote(name, safe='')}")
        self.end_headers()
        if self.command != 'HEAD':
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def json(self, body: dict, status: int = 200) -> None:
        self.reply(json.dumps(body, ensure_ascii=False).encode('utf-8'), 'application/json; charset=utf-8', status)

    def read_json(self) -> dict:
        if self.headers.get_content_type() != 'application/json':
            raise ApiError('Ожидается запрос в формате JSON.', 415)
        try:
            length = int(self.headers.get('Content-Length', 0))
            if not 1 <= length <= 96 * 1024:
                raise ApiError('Запрос пуст или слишком велик.', 413)
            value = json.loads(self.rfile.read(length).decode('utf-8'))
        except (ValueError, UnicodeDecodeError) as exc:
            raise ApiError('Не удалось прочитать запрос.') from exc
        if not isinstance(value, dict):
            raise ApiError('Неверный формат запроса.')
        return value

    def admin_origin(self) -> str | None:
        if not self.server.loopback_only or not ipaddress.ip_address(self.client_address[0]).is_loopback:
            return None
        values = self.headers.get_all('Host', [])
        if len(values) != 1:
            return None
        host = values[0].lower()
        gateway = self.server.lan
        if gateway and gateway.authorizes(self.headers, host):
            return gateway.origin
        # Without the opt-in, a proxy header is not authorization.
        if any(h in self.headers for h in (PROXY_HEADER,'Forwarded','X-Forwarded-Host','X-Forwarded-For','X-Forwarded-Proto')):
            return None
        match = re.fullmatch(r'(localhost|127(?:\.[0-9]{1,3}){3})(?::([0-9]{1,5}))?', host)
        if not match or (match[2] is not None and not 1 <= int(match[2]) <= 65535):
            return None
        try:
            if match[1] != 'localhost' and not ipaddress.ip_address(match[1]).is_loopback:
                return None
        except ValueError:
            return None
        return 'http://' + host

    def require_admin(self, *, write: bool = False) -> None:
        origin = self.admin_origin()
        if not origin:
            raise ApiError('Откройте локальную панель, SSH-туннель или защищённый HTTPS-адрес в LAN.', 403)
        if write and self.headers.get_all('Origin', []) != [origin]:
            raise ApiError('Повторите действие с основного адреса панели.', 403)

    def settings_payload(self) -> dict:
        origin = self.admin_origin()
        result = {'admin': origin is not None, 'fixed_port': self.server.fixed_port or self.server.lan is not None,
                  'active_port': self.server.server_port, 'saved_port': self.app.store.web_port()}
        if self.server.lan and origin:
            result.update(lan_port=self.server.lan.port, lan_url=self.server.lan.origin)
        return result

    def set_port(self, value: object) -> None:
        if self.server.lan:
            raise ApiError('В режиме LAN HTTPS-порт меняется через cmk-lan-config port НОМЕР_ПОРТА.', 409)
        if self.server.fixed_port:
            raise ApiError('Порт задан через --port. Уберите этот параметр, чтобы управлять портом из панели.', 409)
        try:
            port = validate_web_port(value)
        except ValueError as exc:
            raise ApiError(str(exc)) from None
        if port != self.server.server_port:
            try:
                with socket.socket(self.server.address_family) as probe:
                    probe.bind((self.server.server_address[0], port))
            except OSError:
                raise ApiError(f'Порт {port} занят или недоступен. Выберите другой порт.', 409) from None
        self.app.store.set_web_port(port)

    def watch_action(self, data: dict) -> None:
        action, watch = data.get('action'), self.app.watch
        if action == 'pair':
            self.json(watch.begin_pair(data.get('token')), 202)
        elif action == 'test':
            self.json(watch.begin_test(), 202)
        elif action == 'cancel':
            self.json(watch.cancel_task(data.get('id')))
        elif action == 'schedule':
            watch.toggle(data.get('enabled'))
            self.json(self.app.monitor_payload(True))
        elif action == 'check':
            watch.check_now()
            self.json(self.app.monitor_payload(True), 202)
        elif action == 'disconnect':
            watch.disconnect()
            self.json(self.app.monitor_payload(True))
        else:
            raise ApiError('Действие мониторинга не найдено.', 404)

    def do_HEAD(self) -> None:
        self.do_GET()

    def do_GET(self) -> None:
        try:
            parts = urlsplit(self.path)
            route = parts.path
            if self.server.lan:
                self.require_admin()
            if route == '/' or route.removeprefix('/assets/') in ASSETS and route.startswith('/assets/'):
                file = 'index.html' if route == '/' else route.removeprefix('/assets/')
                self.reply((UI / file).read_bytes(), ASSETS[file], cache=file.endswith(('.woff2', '.svg')))
            elif route == '/api/catalog':
                self.json(self.app.catalog_payload(self.app.home_catalog()))
            elif route == '/api/watchdog':
                self.json(self.app.monitor_payload(self.admin_origin() is not None))
            elif (task := re.fullmatch(r'/api/watchdog/task/([a-zA-Z0-9_-]+)', route)):
                self.require_admin()
                self.json(self.app.watch.get_task(task[1]))
            elif route == '/api/settings':
                self.json(self.settings_payload())
            elif route == '/api/detail':
                args = parse_qs(parts.query, keep_blank_values=True, max_num_fields=10)
                catalog = self.app.catalog(args.get('catalog', [''])[0])
                self.json(catalog.detail(args.get('event', [''])[0]))
            elif re.fullmatch(r'/api/scan/[a-zA-Z0-9_-]+', route):
                self.json(self.app.job_payload(route.rsplit('/', 1)[-1]))
            elif route == '/api/saved':
                args = parse_qs(parts.query, keep_blank_values=True, max_num_fields=10)
                catalog = self.app.catalog(args.get('catalog', [''])[0])
                event = catalog.find(args.get('event', [''])[0])
                saved = self.app.store.saved(event)
                if saved is None:
                    raise ApiError('Для этой карточки ещё нет сохранённого Word.', 404)
                self.reply(saved.content, DOCX_MIME, name=saved.filename)
            elif (match := re.fullmatch(r'/api/download/([a-zA-Z0-9_-]+)/(zip|word/([0-9]{1,3}))', route)):
                bundle = self.app.bundle(match[1])
                if match[2] == 'zip':
                    item = bundle.archive
                else:
                    idx = int(match[3])
                    if idx >= len(bundle.documents):
                        raise ApiError('Документ не найден в этом экспорте.', 404)
                    item = bundle.documents[idx]
                self.reply(item.payload, item.mime, name=item.name)
            else:
                raise ApiError('Страница не найдена.', 404)
        except (ApiError, ControlError) as exc:
            self.json({'error': str(exc)}, exc.status)
        except TelegramError as exc:
            self.json({'error': str(exc)}, 400)
        except (ValueError, OSError, sqlite3.Error) as exc:
            self.log_error('GET failed: %s', exc)
            self.json({'error': 'Не удалось обработать запрос.'}, 500)

    def do_POST(self) -> None:
        try:
            route = urlsplit(self.path).path
            if self.server.lan:
                self.require_admin(write=True)
            if route == '/api/scan':
                key = self.app.start_scan(self.read_json())
                self.json({'id': key}, 202)
            elif route == '/api/export':
                self.json(self.app.make_programs(self.read_json()), 201)
            elif route == '/api/watchdog':
                self.require_admin(write=True)
                self.watch_action(self.read_json())
            elif route == '/api/settings':
                self.require_admin(write=True)
                self.set_port(self.read_json().get('port'))
                self.json(self.settings_payload())
            else:
                raise ApiError('Страница не найдена.', 404)
        except (ApiError, ControlError) as exc:
            self.json({'error': str(exc)}, exc.status)
        except TelegramError as exc:
            self.json({'error': str(exc)}, 400)
        except (ValueError, OSError, sqlite3.Error) as exc:
            self.log_error('POST failed: %s', exc)
            self.json({'error': 'Не удалось обработать запрос.'}, 500)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', default='127.0.0.1', help='интерфейс; по умолчанию только этот компьютер')
    ports = parser.add_mutually_exclusive_group()
    ports.add_argument('--port', type=int, help=f'порт текущего запуска, скрывает изменение из панели; иначе сохранённый или {DEFAULT_WEB_PORT}')
    ports.add_argument('--set-port', type=int, metavar='PORT', help='сохранить порт для будущих запусков, не открывая панель')
    parser.add_argument('--no-browser', action='store_true', help='не открывать вкладку браузера автоматически')
    parser.add_argument('--data-dir', type=Path, help='общая папка истории, расписания и настроек')
    args = parser.parse_args(argv)
    directory = data_dir(args.data_dir)
    if args.set_port is not None:
        try:
            port = validate_web_port(args.set_port)
            Store(directory).set_web_port(port)
        except ValueError as exc:
            parser.error(str(exc))
        except (OSError, sqlite3.Error):
            print('Не удалось сохранить порт. Проверьте права на папку данных.', file=sys.stderr)
            return 1
        print(f'Порт {port} сохранён. Он вступит в силу при следующем запуске панели (без --port).')
        return 0
    if args.port is not None and not 0 <= args.port <= 65535:
        parser.error('Укажите порт от 0 до 65535.')
    try:
        app = App(directory)
        port = args.port if args.port is not None else app.store.web_port()
    except (OSError, ValueError, sqlite3.Error):
        print('Не удалось прочитать настройки или историю. Проверьте папку данных.', file=sys.stderr)
        return 1
    try:
        with Server((args.host, port), app, fixed_port=args.port is not None) as server:
            host = '127.0.0.1' if args.host == '0.0.0.0' else args.host
            url = f'http://{host}:{server.server_port}/'
            print(f'Панель ЦМК запущена: {url}\nДля остановки нажмите Ctrl+C.', flush=True)
            if not args.no_browser:
                timer = Timer(.35, webbrowser.open, args=(url,))
                timer.daemon = True
                timer.start()

            def stop_on_signal(_signum, _frame):
                raise KeyboardInterrupt

            previous = signal.signal(signal.SIGTERM, stop_on_signal)
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                pass
            finally:
                signal.signal(signal.SIGTERM, previous)
    except ValueError as exc:
        print(f'Ошибка запуска: {exc}', file=sys.stderr)
        return 1
    except OSError:
        print(f'Не удалось открыть панель на {args.host}:{port}. Проверьте, что порт свободен, или задайте другой через --set-port.', file=sys.stderr)
        return 1
    finally:
        app.pool.shutdown(wait=False, cancel_futures=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
