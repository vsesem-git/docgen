@echo off
cd /d "%~dp0"
call "%~dp0_run.cmd" gui.py %*
exit /b %errorlevel%
