"""Заполнение копии утверждённого бланка программы ЦМК."""
from __future__ import annotations

import re
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

from docx import Document
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph

from site_kodeks import Event, SourceError


ACRONYMS = ('ТКО', 'ЖКХ', 'МКД', 'ВС', 'РФ', 'ГОЗ', 'СНТ', 'НДС', 'УК', 'СЗЗ', 'ВКХ', 'ФАС', 'МСУ', 'РОП', 'БПЛА')


def plain_title(s: str) -> str:
    value = s.capitalize() if s.isupper() else s
    return re.sub(r'\b(' + '|'.join(ACRONYMS) + r')\b', lambda m: m[0].upper(), value, flags=re.I)


def set_runs(p, *segments: str) -> None:
    runs = p.runs
    if len(runs) != len(segments):
        raise SourceError(f'Формат абзаца в шаблоне отличается от утверждённого: {p.text[:65]}')
    for r, s in zip(runs, segments):
        r.text = s


def formatted_abstract(p, source: str, edit: dict) -> None:
    if 'abstract_runs' in edit:
        set_runs(p, *edit['abstract_runs'])
        return
    source = edit.get('abstract') or source
    # Highlight the first compact meaningful phrase without changing the text.
    match = re.match(r'(К \d{4} году|В \d{4} году|В течение \d{4} года|С \d{2}\.\d{2}\.\d{4})\b', source)
    spans = list(p.runs)
    if len(spans) < 3:
        raise SourceError('Не найдено оформление аннотации в шаблоне.')
    if match:
        spans[0].text = ''
        spans[1].text = match[0]
        spans[2].text = source[match.end():]
        remove = spans[3:]
    else:
        spans[0].text = source
        remove = spans[1:]
    for run in remove:
        run._r.getparent().remove(run._r)


def clone_paragraph(prototype, before):
    node = deepcopy(prototype._p)
    for attr in tuple(node.attrib):
        if attr.rsplit('}', 1)[-1] in {'paraId', 'textId'}:
            node.attrib.pop(attr)
    before._p.addprevious(node)
    return Paragraph(node, prototype._parent)


def speaker_role(role: str, edit: dict) -> str:
    words = {'жилищно-коммунального хозяйства Федеральной антимонопольной службы': 'ЖКХ ФАС России',
             'Института экономики и права жилищно-коммунального хозяйства': 'Института экономики и права ЖКХ',
             'Института экономики жилищно-коммунального хозяйства': 'Института экономики ЖКХ',
             'Группы компаний «Росводоканал»': 'ГК «Росводоканал»',
             'жилищно-коммунальной сфере': 'сфере ЖКХ',
             'ранее – Заместитель': 'ранее — заместитель'}
    for old, short in {**words, **edit.get('role_shortenings', {})}.items():
        role = role.replace(old, short)
    return role


def conditions_parts(event: Event) -> tuple[str, str, str, str, str]:
    day = f'{event.day_month} с {event.start:%H:%M} до {event.end:%H:%M}'
    price = re.match(r'(Стоимость участия в вебинаре\s*[–—-]\s*)([\d ]+ рубл\w*)(.*)', event.fee)
    prefix = ' (по московскому времени).'
    amount, detail = '', ''
    if price:
        prefix += ' Стоимость участия в вебинаре — '
        amount = price[2].replace(' ', '\u00a0')
        detail = price[3]
    elif event.fee:
        detail = ' ' + event.fee
    extra = event.access_and_discounts
    extra = extra.replace('возможность получить индивидуальные рекомендации экспертов и коллег в общем чате',
                          'консультации экспертов в общем чате')
    extra = extra.replace(
        'комплект справочно-методических материалов, сертификат об обучении, полную видеозапись вебинара и '
        'консультации экспертов в общем чате.',
        'консультации экспертов в общем чате, полная видеозапись вебинара, сертификат об обучении '
        'и комплект справочно-методических материалов.',
    )
    if extra:
        detail += ' ' + extra
    return 'Интернет-трансляция будет проходить ', day, prefix, amount, detail


def clean_package(doc):
    """Не переносить старый внешний .dotx и неиспользуемые вложения в новые выпуски."""
    settings = doc.part._settings_part
    for n in settings.element.xpath('./w:attachedTemplate'):
        rid = n.get(qn('r:id'))
        n.getparent().remove(n)
        if rid and rid in settings.rels:
            del settings.rels[rid]
    for rid, rel in list(doc.part.rels.items()):
        if rel.reltype in (RT.IMAGE, RT.HYPERLINK) and not doc.element.xpath(
            f'//*[@r:id="{rid}" or @r:embed="{rid}" or @r:link="{rid}"]'
        ):
            del doc.part.rels[rid]
    package = doc.part.package
    clean_app = next(r.target_part for r in Document().part.package.rels.values()
                     if r.reltype == RT.EXTENDED_PROPERTIES)
    for rid, rel in list(package.rels.items()):
        if rel.reltype == RT.EXTENDED_PROPERTIES:
            del package.rels[rid]
    package.relate_to(clean_app, RT.EXTENDED_PROPERTIES)


def render(event: Event, dest: Path, layout: Path, edit: dict) -> None:
    doc = Document(layout)
    p = list(doc.paragraphs)
    if (len(doc.tables) != 3 or len(p) != 28 or p[1].text != 'Уважаемые коллеги!'
            or p[6].text != 'ВЕДУЩИЕ ВЕБИНАРА' or p[11].text != 'ПРОГРАММА ВЕБИНАРА'
            or p[23].text != 'УСЛОВИЯ УЧАСТИЯ' or 'kir@vsesem.ru' not in p[25].text
            or p[26].text != 'Анкета для регистрации на вебинар'):
        raise SourceError('Ожидается утверждённый «ШАБЛОН — программа вебинара.docx» ЦМК.')
    _, info, form = doc.tables
    for node in info._tbl.xpath('./w:tblPr/w:tblpPr'):
        node.getparent().remove(node)
    title = plain_title(event.title)
    date_short = f'{event.day_month} {event.day.year} г.'.replace(' ', '\u00a0')
    form_title = f'{date_short} «{title}»'
    a, b = info.rows[0].cells
    set_runs(a.paragraphs[0], f'О проведении онлайн-трансляции {form_title}')
    set_runs(b.paragraphs[0], edit.get('audience') or event.audience.rstrip('.'))
    formatted_abstract(p[2], event.abstract, edit)
    kind = {'всероссийский практический вебинар': 'всероссийского практического вебинара',
            'практический вебинар': 'практического вебинара',
            'консультационный вебинар': 'консультационного вебинара'}.get(event.kind.casefold(), 'вебинара')
    who = edit.get('with_whom') or event.with_whom
    set_runs(p[3], p[3].runs[0].text, event.date_ru.replace(' ', '\u00a0'),
             f' интернет-трансляции {kind}' + (' с участием ' if who else ''),
             who, edit.get('intro_suffix', ':'))
    set_runs(p[4], event.title)
    benefit = edit.get('benefit') or ('разобраться в следующих вопросах: '
                                      + '; '.join(plain_title(t.title).lower() if t.title.isupper()
                                                  else t.title[:1].lower() + t.title[1:]
                                                  for t in event.topics[:4]) + '.')
    set_runs(p[5], p[5].runs[0].text, benefit)

    # Reuse available paragraphs; clone the reference only when a page has extra items.
    for i, (name, role) in enumerate(event.speakers):
        item = p[7 + i] if i < 4 else clone_paragraph(p[7], p[11])
        set_runs(item, name, ' — ' + speaker_role(role, edit))
    for item in p[7 + len(event.speakers):11]:
        item._p.getparent().remove(item._p)
    for i, topic in enumerate(event.topics, 1):
        item = p[11 + i] if i <= 10 else clone_paragraph(p[12], p[22])
        name = edit.get('rename_topics', {}).get(str(i), topic.title).rstrip(' .')
        details = edit.get('topic_details', {}).get(str(i), topic.details)
        set_runs(item, f'{i}. {name}. ', details)
    for item in p[12 + len(event.topics):22]:
        item._p.getparent().remove(item._p)
    if event.closing:
        close = event.closing.capitalize()
        if close == 'Ответы на вопросы участников и практические рекомендации экспертов':
            close = 'Ответы на вопросы участников, консультации экспертов и практические рекомендации'
        set_runs(p[22], f'{len(event.topics) + 1}. {close}')
    else:
        p[22]._p.getparent().remove(p[22]._p)
    set_runs(p[24], *conditions_parts(event))

    set_runs(form.rows[0].cells[1].paragraphs[0], form_title)
    set_runs(form.rows[1].cells[1].paragraphs[0], f'{date_short}, {event.hours} (МСК)')
    # Bind the form's event title to its date row, without adding a forced page break.
    for cell in form.rows[0]._tr.tc_lst:
        for n in cell.xpath('./w:p'):
            Paragraph(n, form).paragraph_format.keep_with_next = True

    clean_package(doc)
    core = doc.core_properties
    core.title, core.subject = title, 'Программа вебинара Центра Межрегиональных Коммуникаций'
    core.author, core.last_modified_by, core.comments = 'Центр Межрегиональных Коммуникаций', '', ''
    core.created = core.modified = datetime.now(timezone.utc)
    core.revision = 1
    with dest.open('xb') as output:
        try:
            doc.save(output)
        except Exception:
            output.close()
            dest.unlink(missing_ok=True)
            raise
