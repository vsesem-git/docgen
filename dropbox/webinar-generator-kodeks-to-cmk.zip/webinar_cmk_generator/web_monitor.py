"""Встроенный планировщик и управление ботом из локальной веб-панели."""
from __future__ import annotations

import secrets
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from threading import Event, Lock, Thread
from time import monotonic

from schedule_data import CHECK_TIMES, MOSCOW, due_slot, next_slot
from storage import Store
from telegram_notify import (CONFIG, Bot, TelegramConfig, TelegramError, check_token,
                             configured, managed_by_env, read_config, write_config)
from watchdog import TEST_MESSAGE, check_once


class ControlError(RuntimeError):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


@dataclass
class TelegramJob:
    id: str
    kind: str
    state: str = 'starting'
    message: str = ''
    username: str = ''
    code: str = ''
    expires: float = 0
    cancel: Event = field(default_factory=Event, repr=False)

    @property
    def active(self) -> bool:
        return self.state in {'starting', 'waiting', 'finishing', 'cancelling'}

    def payload(self) -> dict:
        data = {'id': self.id, 'kind': self.kind, 'state': self.state, 'message': self.message}
        if self.state == 'waiting':
            data.update(bot_url='https://t.me/' + self.username, username=self.username,
                        code=self.code, remaining=max(0, int(self.expires - monotonic() + .99)))
        return data


class WebMonitor:
    def __init__(self, store: Store):
        self.store = store
        self.lock = Lock()
        self.stopping = Event()
        self.wake = Event()
        self.worker: Thread | None = None
        self.enabled = store.web_monitor_enabled()
        self.manual = False
        self.owner: str | None = None
        self.task: TelegramJob | None = None

    @property
    def online(self) -> bool:
        return self.worker is not None and self.worker.is_alive() and not self.stopping.is_set()

    def start(self) -> None:
        self.worker = Thread(target=self.loop, daemon=True, name='embedded-watchdog')
        self.worker.start()

    def close(self) -> None:
        self.stopping.set()
        self.wake.set()
        with self.lock:
            if self.task and self.task.active:
                self.task.cancel.set()
        if self.worker is not None:
            self.worker.join(timeout=.9)
        with self.lock:
            owner = self.owner
        if owner is not None:
            try:
                self.store.finish_check(owner, False, 'Проверка прервана при остановке сервиса.')
            except sqlite3.Error:
                pass  # The lease expires; never delete a different process's reservation.

    def status(self, admin: bool) -> dict:
        state = self.store.monitor()
        with self.lock:
            enabled, busy = self.enabled, bool(self.manual or self.owner)
            task = self.task.payload() if admin and self.task and self.task.active else None
        external, managed = state['running'], self.online
        running = (managed and enabled) or external
        return {**state, 'checking': state['checking'] or busy, 'running': running,
                'enabled': enabled, 'managed': managed, 'external': external,
                'configured': configured(self.store.directory), 'env_managed': managed_by_env(),
                'admin': admin, 'task': task, 'times': [t.strftime('%H:%M') for t in CHECK_TIMES],
                'next_check': next_slot(datetime.now(MOSCOW)).isoformat() if running else None}

    def toggle(self, enabled: bool) -> None:
        if not isinstance(enabled, bool):
            raise ControlError('Укажите, включено ли расписание.')
        if not self.online:
            raise ControlError('Встроенный мониторинг не запущен.', 409)
        with self.lock:
            self.store.set_web_monitor_enabled(enabled)
            self.enabled = enabled
        self.wake.set()

    def check_now(self) -> None:
        if not self.online:
            raise ControlError('Встроенный мониторинг не запущен.', 409)
        with self.lock:
            if self.manual or self.owner or self.store.monitor()['checking']:
                raise ControlError('Проверка уже выполняется.', 409)
            self.manual = True
        self.wake.set()

    def loop(self) -> None:
        last_slot = None
        while not self.stopping.is_set():
            self.wake.clear()
            try:
                now = datetime.now(MOSCOW)
                slot = due_slot(now)
                key = slot.isoformat() if slot else None
                owner = None
                with self.lock:
                    due = key if self.enabled and key != last_slot else None
                    if not self.stopping.is_set() and (due or self.manual):
                        owner = self.store.try_start_check(due)
                        self.owner = owner
                        self.manual = False
                        if due:
                            last_slot = due  # The SQLite slot reservation also handles restarts.
                if owner is not None:
                    try:
                        check_once(self.store, owner=owner, cancelled=self.stopping.is_set)
                    finally:
                        with self.lock:
                            self.owner = None
                now = datetime.now(MOSCOW)
                wait = max(.15, min(20.0, (next_slot(now)-now).total_seconds()))
            except (sqlite3.Error, OSError):
                print('ЦМК: временно недоступна папка истории мониторинга; повторим попытку.', flush=True)
                wait = 12.0
            self.wake.wait(wait)

    def begin_pair(self, raw_secret: object) -> dict:
        if managed_by_env():
            raise ControlError('Telegram задан окружением службы. Для настройки в панели уберите переменные CMK_TELEGRAM_*.', 409)
        return self.new_task('pair', check_token(raw_secret))

    def begin_test(self) -> dict:
        cfg = read_config(self.store.directory)
        if cfg is None:
            raise ControlError('Сначала привяжите бота к личному чату.', 409)
        return self.new_task('test', cfg)

    def new_task(self, kind: str, credential: str | TelegramConfig) -> dict:
        with self.lock:
            if self.task and self.task.active:
                raise ControlError('Другая операция с Telegram ещё выполняется.', 409)
            job = TelegramJob(secrets.token_urlsafe(16), kind,
                              'starting' if kind == 'pair' else 'finishing',
                              'Связываемся с Telegram…' if kind == 'pair' else 'Отправляем тестовое сообщение…')
            self.task = job
            result = job.payload()
        Thread(target=self.run_task, args=(job, credential), daemon=True, name='telegram-config').start()
        return result

    def get_task(self, key: str) -> dict:
        with self.lock:
            if not self.task or self.task.id != key:
                raise ControlError('Операция с Telegram не найдена. Начните заново.', 404)
            return self.task.payload()

    def cancel_task(self, key: str) -> dict:
        with self.lock:
            job = self.task
            if not job or job.id != key:
                raise ControlError('Операция с Telegram не найдена.', 404)
            if job.state in ('starting', 'waiting'):
                job.cancel.set()
                job.state, job.message = 'cancelling', 'Отменяем привязку…'
            elif job.state == 'finishing':
                raise ControlError('Сообщение уже отправляется. Дождитесь результата.', 409)
            return job.payload()

    def disconnect(self) -> None:
        with self.lock:
            if managed_by_env():
                raise ControlError('Удалите настройки Telegram из окружения службы и перезапустите её.', 409)
            if self.task and self.task.active:
                raise ControlError('Сначала дождитесь завершения операции с Telegram.', 409)
            try:
                (self.store.directory / CONFIG).unlink(missing_ok=True)
            except OSError:
                raise ControlError('Не удалось удалить локальные настройки Telegram.', 500) from None

    def run_task(self, job: TelegramJob, credential: str | TelegramConfig) -> None:
        def cancelled() -> bool:
            return job.cancel.is_set() or self.stopping.is_set()

        def code_ready(username: str, code: str) -> None:
            with self.lock:
                if not cancelled():
                    job.state, job.message = 'waiting', 'Отправьте этот код боту в личном чате.'
                    job.username, job.code, job.expires = username, code, monotonic() + 180

        def finish(state: str, message: str) -> None:
            with self.lock:
                job.state, job.message, job.code, job.username = state, message, '', ''

        try:
            if job.kind == 'pair':
                bot = Bot(credential)
                chat = bot.pair_private(code_ready, cancelled=cancelled)
                with self.lock:
                    if cancelled():
                        raise TelegramError('Привязка отменена.')
                    job.state, job.message = 'finishing', 'Код принят. Отправляем тестовое сообщение…'
                bot.send(chat, TEST_MESSAGE)
                if cancelled():
                    raise TelegramError('Привязка прервана.')
                write_config(self.store.directory, TelegramConfig(credential, chat))
                finish('done', 'Бот привязан. Тестовое сообщение отправлено в этот чат.')
            else:
                if cancelled():
                    raise TelegramError('Отправка отменена.')
                Bot(credential.token).send(credential.chat_id, TEST_MESSAGE)
                finish('done', 'Telegram подтвердил отправку тестового сообщения.')
        except TelegramError as exc:
            if cancelled():
                finish('cancelled', 'Операция отменена. Привязка не изменена.')
            else:
                finish('error', str(exc))
        except Exception:
            # In particular never return or log an exception mentioning a request URL.
            finish('error', 'Не удалось завершить операцию с Telegram. Повторите попытку.')
