#!/usr/bin/env python3
"""Проверка сайта по расписанию и уведомления о новых вебинарах в Telegram."""
from __future__ import annotations

import argparse
import getpass
import sqlite3
import sys
import warnings
from datetime import datetime
from pathlib import Path
from time import sleep

import requests

from schedule_data import CHECK_TIMES, MOSCOW, due_slot, fetch_schedule, load_snapshot, next_slot
from site_kodeks import SourceError
from storage import Notice, Store, data_dir
from telegram_notify import Bot, TelegramConfig, TelegramError, check_chat, check_token, read_config, write_config

TEST_MESSAGE = 'ЦМК · Тестовое уведомление. Бот подключён: здесь будут сообщения о новых вебинарах.'


def telegram_batches(notices: list[Notice]):
    header = 'ЦМК · Новые вебинары'

    def length(value: str) -> int:
        return len(value.encode('utf-16-le')) // 2

    message, keys = header, []
    for n in notices:
        title = ' '.join(n.title.split())
        if len(title) > 350:
            title = title[:349] + '…'
        item = f'\n\n{n.date_ru} · {n.hours} МСК\n{title}\n{n.url}'
        if length(message + item) > 3900 and keys:
            yield keys, message
            keys, message = [], header
        message += item
        keys.append(n.key)
    if keys:
        yield keys, message


def check_once(store: Store, slot: str | None = None, *, scan=fetch_schedule, bot_factory=Bot,
               owner: str | None = None, cancelled=lambda: False) -> bool | None:
    owner = owner or store.try_start_check(slot)
    if owner is None:
        return None
    site_ok, send_ok = False, True
    notes = []
    try:
        if cancelled():
            return False
        try:
            schedule = scan()
            if cancelled():
                return False
            store.save_schedule(schedule)
            site_ok = True
            notes.append(f'Проверено карточек: {len(schedule.entries)}.')
        except (requests.RequestException, SourceError, OSError, ValueError, TypeError, KeyError, sqlite3.Error):
            # Do not turn incomplete parses into a published schedule or a notification.
            notes.append('Не удалось обновить сайт. Предыдущий список сохранён.')
        if cancelled():
            return False
        outstanding, sent = store.pending(), 0
        if outstanding:
            try:
                config = read_config(store.directory)
                if config is None:
                    notes.append('Telegram не настроен; новые карточки сохранены для отправки.')
                else:
                    bot = bot_factory(config.token)
                    for keys, text in telegram_batches(outstanding):
                        if cancelled():
                            return False
                        bot.send(config.chat_id, text)
                        store.mark_sent(keys)
                        sent += len(keys)
            except TelegramError as exc:
                send_ok = False
                notes.append(str(exc))
        elif site_ok:
            notes.append('Нет новых карточек для уведомления.')
        if sent:
            notes.append(f'Уведомлено о карточках: {sent}.')
    finally:
        stopped = cancelled()
        message = 'Проверка прервана при остановке сервиса.' if stopped else (' '.join(notes) or 'Проверка не завершена.')
        store.finish_check(owner, site_ok and send_ok and not stopped, message)
        print(f'[{datetime.now(MOSCOW):%d.%m.%Y %H:%M} МСК] {message}', flush=True)
    return site_ok and send_ok


def serve(store: Store) -> None:
    slots = ', '.join(t.strftime('%H:%M') for t in CHECK_TIMES)
    print(f'Мониторинг ЦМК: {slots} МСК. Для остановки нажмите Ctrl+C.', flush=True)
    print(f'История: {store.directory}', flush=True)
    last_attempted = None
    while True:
        store.pulse()
        now = datetime.now(MOSCOW)
        if (slot := due_slot(now)) is not None:
            key = slot.isoformat()
            if key != last_attempted:
                result = check_once(store, key)
                # None may mean that another process is checking: the database also
                # protects this slot from duplicates if this process is restarted.
                if result is not None:
                    last_attempted = key
                continue_pause = 5
            else:
                continue_pause = 20
        else:
            continue_pause = max(0.2, min(25, (next_slot(now) - now).total_seconds()))
        sleep(continue_pause)


def connect(directory: Path, explicit_chat: str | None = None) -> None:
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', getpass.GetPassWarning)
            secret = check_token(getpass.getpass('Токен Telegram-бота (ввод скрыт): '))
    except (getpass.GetPassWarning, EOFError):
        raise TelegramError('Для безопасного ввода токена запустите настройку в обычном терминале.') from None
    bot = Bot(secret)

    def show_code(name: str, code: str) -> None:
        print(f'Откройте https://t.me/{name} в личном чате, нажмите «Запустить» и отправьте код:', flush=True)
        print(f'    {code}\nКод действует 3 минуты.', flush=True)

    chat = check_chat(explicit_chat) if explicit_chat is not None else bot.pair_private(show_code)
    bot.send(chat, TEST_MESSAGE)
    write_config(directory, TelegramConfig(secret, chat))
    print('Тестовое сообщение отправлено. Настройки сохранены только на этом компьютере.', flush=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--connect', action='store_true', help='привязать Telegram и отправить тестовое сообщение')
    modes.add_argument('--test', action='store_true', help='отправить тест в уже настроенный чат')
    modes.add_argument('--once', action='store_true', help='проверить сайт сейчас один раз, независимо от времени')
    parser.add_argument('--chat-id', help='явный ID чата (только вместе с --connect)')
    parser.add_argument('--data-dir', type=Path, help='общая с GUI папка истории и настроек')
    args = parser.parse_args(argv)
    if args.chat_id and not args.connect:
        parser.error('--chat-id используется только вместе с --connect')
    directory = data_dir(args.data_dir)
    try:
        if args.connect:
            connect(directory, args.chat_id)
            return 0
        if args.test:
            config = read_config(directory)
            if config is None:
                raise TelegramError('Сначала подключите бота: python watchdog.py --connect')
            Bot(config.token).send(config.chat_id, TEST_MESSAGE)
            print('Telegram подтвердил отправку тестового сообщения.', flush=True)
            return 0
        store = Store(directory)
        store.seed(load_snapshot())
        if args.once:
            result = check_once(store)
            if result is None:
                print('Другая проверка уже выполняется.', flush=True)
                return 0
            return 0 if result else 1
        serve(store)
    except KeyboardInterrupt:
        print('\nМониторинг остановлен.', flush=True)
        return 0
    except TelegramError as exc:
        print(f'Ошибка: {exc}', file=sys.stderr)
        return 1
    except (sqlite3.Error, OSError):
        print('Не удалось открыть или сохранить локальную историю. Проверьте доступ к папке данных.', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
