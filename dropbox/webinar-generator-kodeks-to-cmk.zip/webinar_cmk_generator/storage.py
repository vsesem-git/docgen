"""Локальная история программ, надёжный каталог и очередь уведомлений."""
from __future__ import annotations

import os
import secrets
import sqlite3
import sys
from contextlib import closing, contextmanager
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from time import time
from typing import Iterable

from schedule_data import MOSCOW, Schedule, event_key, utc_stamp
from site_kodeks import Event

DEFAULT_WEB_PORT = 7860


def validate_web_port(value: int) -> int:
    if type(value) is not int or not 1024 <= value <= 65535:
        raise ValueError('Укажите целое число от 1024 до 65535.')
    return value


SCHEMA = '''
CREATE TABLE IF NOT EXISTS known_card (
  key TEXT PRIMARY KEY, title TEXT NOT NULL, day TEXT NOT NULL,
  date_ru TEXT NOT NULL, hours TEXT NOT NULL, url TEXT NOT NULL,
  is_new INTEGER NOT NULL, sent_at TEXT
);
CREATE TABLE IF NOT EXISTS saved_word (
  key TEXT PRIMARY KEY, filename TEXT NOT NULL, generated_at TEXT NOT NULL,
  content BLOB NOT NULL
);
CREATE TABLE IF NOT EXISTS full_schedule (
  singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
  revision TEXT NOT NULL, checked_at TEXT NOT NULL, payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS monitor_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS monitor_slot (slot TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS monitor_lock (
  singleton INTEGER PRIMARY KEY CHECK (singleton = 1), owner TEXT NOT NULL, expiration REAL NOT NULL
);
'''


def data_dir(value: Path | str | None = None) -> Path:
    value = value or os.environ.get('CMK_DATA_DIR')
    if value:
        return Path(value).expanduser().resolve()
    if os.name == 'nt':
        return Path(os.environ.get('LOCALAPPDATA') or (Path.home() / 'AppData' / 'Local')) / 'CMKWebinars'
    if sys.platform == 'darwin':
        return Path.home() / 'Library' / 'Application Support' / 'CMKWebinars'
    return Path(os.environ.get('XDG_STATE_HOME') or (Path.home() / '.local' / 'state')) / 'cmk-webinars'


@dataclass(frozen=True)
class Notice:
    key: str
    title: str
    day: str
    date_ru: str
    hours: str
    url: str


@dataclass(frozen=True)
class SavedWord:
    filename: str
    generated_at: str
    content: bytes


class Store:
    def __init__(self, directory: Path):
        self.directory = directory
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.path = directory / 'history.sqlite3'
        with closing(self.connect()) as db:
            db.execute('PRAGMA journal_mode = WAL')
            db.executescript(SCHEMA)

    def connect(self) -> sqlite3.Connection:
        db = sqlite3.connect(self.path, timeout=12)
        db.row_factory = sqlite3.Row
        return db

    @contextmanager
    def write(self):
        with closing(self.connect()) as db, db:
            db.execute('BEGIN IMMEDIATE')
            yield db

    @staticmethod
    def card_row(e: Event, is_new: bool) -> tuple:
        return event_key(e), e.menu_title or e.title, e.day.isoformat(), e.date_ru, e.hours, e.url, int(is_new)

    def seed(self, snapshot: Schedule) -> None:
        # The shipped list is already known, but not marked generated or sent.
        with self.write() as db:
            db.executemany('''INSERT OR IGNORE INTO known_card
                (key, title, day, date_ru, hours, url, is_new) VALUES (?,?,?,?,?,?,?)''',
                (self.card_row(e, False) for e in snapshot.entries))

    def save_schedule(self, schedule: Schedule) -> str:
        """Only call on a fully verified chain from the source's homepage."""
        if schedule.origin != 'live' or not schedule.entries or not schedule.checked_at:
            raise ValueError('Нельзя заменить каталог непроверенным или пустым списком.')
        payload, revision = schedule.to_json(), secrets.token_urlsafe(16)
        today = datetime.fromisoformat(schedule.checked_at).astimezone(MOSCOW).date()
        with self.write() as db:
            row = db.execute('SELECT revision, checked_at FROM full_schedule WHERE singleton=1').fetchone()
            if row is not None and row['checked_at'] > schedule.checked_at:
                return row['revision']
            db.executemany('''INSERT INTO known_card (key,title,day,date_ru,hours,url,is_new) VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(key) DO UPDATE SET title=excluded.title, hours=excluded.hours, url=excluded.url''',
                (self.card_row(e, e.day >= today) for e in schedule.entries))
            db.execute('''INSERT INTO full_schedule (singleton,revision,checked_at,payload) VALUES (1,?,?,?)
                ON CONFLICT(singleton) DO UPDATE SET revision=excluded.revision, checked_at=excluded.checked_at,
                payload=excluded.payload''', (revision, schedule.checked_at, payload))
        return revision

    def latest(self, after: str | None = None) -> tuple[str, Schedule] | None:
        with closing(self.connect()) as db:
            row = db.execute('SELECT revision,payload FROM full_schedule WHERE singleton=1 AND revision<>?',
                             (after or '',)).fetchone()
        return (row['revision'], Schedule.from_json(row['payload'])) if row is not None else None

    def statuses(self, events: Iterable[Event]) -> dict[str, dict]:
        keys = tuple(dict.fromkeys(map(event_key, events)))
        if not keys:
            return {}
        query_args = ','.join('?' for _ in keys)
        result = {key: {} for key in keys}
        with closing(self.connect()) as db:
            for row in db.execute('SELECT key,is_new FROM known_card WHERE key IN ('+query_args+')', keys):
                result[row['key']]['is_new'] = bool(row['is_new'])
            for row in db.execute('SELECT key,filename,generated_at FROM saved_word WHERE key IN ('+query_args+')', keys):
                result[row['key']].update(generated_at=row['generated_at'], saved_name=row['filename'])
        return result

    def save_programs(self, rows: Iterable[tuple[Event, str, bytes]]) -> str:
        stamp = utc_stamp()
        with self.write() as db:
            db.executemany('''INSERT INTO saved_word (key,filename,generated_at,content) VALUES (?,?,?,?)
                ON CONFLICT(key) DO UPDATE SET filename=excluded.filename,
                generated_at=excluded.generated_at, content=excluded.content''',
                ((event_key(event), name, stamp, content) for event, name, content in rows))
        return stamp

    def saved(self, event: Event) -> SavedWord | None:
        with closing(self.connect()) as db:
            row = db.execute('SELECT filename, generated_at, content FROM saved_word WHERE key=?', (event_key(event),)).fetchone()
        return SavedWord(*row) if row is not None else None

    def pending(self) -> list[Notice]:
        today = datetime.now(MOSCOW).date().isoformat()
        with closing(self.connect()) as db:
            rows = db.execute('''SELECT key,title,day,date_ru,hours,url FROM known_card
                WHERE is_new=1 AND sent_at IS NULL AND day>=? ORDER BY day,hours,key''', (today,)).fetchall()
        return [Notice(*row) for row in rows]

    def mark_sent(self, keys: Iterable[str]) -> None:
        stamp = utc_stamp()
        with self.write() as db:
            db.executemany('UPDATE known_card SET sent_at=? WHERE key=? AND sent_at IS NULL', ((stamp,k) for k in keys))

    @staticmethod
    def put(db: sqlite3.Connection, fields: dict[str, str]) -> None:
        db.executemany('''INSERT INTO monitor_meta (key,value) VALUES (?,?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value''', fields.items())

    def setting(self, key: str) -> str | None:
        with closing(self.connect()) as db:
            row = db.execute('SELECT value FROM monitor_meta WHERE key=?', (key,)).fetchone()
        return row['value'] if row else None

    def set_web_port(self, port: int) -> None:
        with self.write() as db:
            self.put(db, {'web_port': str(validate_web_port(port))})

    def web_port(self) -> int:
        return validate_web_port(int(self.setting('web_port') or DEFAULT_WEB_PORT))

    def web_monitor_enabled(self) -> bool:
        return self.setting('web_monitor_enabled') == '1'

    def set_web_monitor_enabled(self, enabled: bool) -> None:
        with self.write() as db:
            self.put(db, {'web_monitor_enabled': '1' if enabled else '0'})

    def pulse(self) -> None:
        with self.write() as db:
            self.put(db, {'service_until': str(time()+75)})

    def try_start_check(self, slot: str | None) -> str | None:
        """Reserve a window and serialize watchdog runs across separate processes."""
        owner, now = secrets.token_urlsafe(16), time()
        with self.write() as db:
            busy = db.execute('SELECT 1 FROM monitor_lock WHERE singleton=1 AND expiration>?', (now,)).fetchone()
            if busy:
                return None
            if slot is not None:
                claim = db.execute('INSERT OR IGNORE INTO monitor_slot (slot) VALUES (?)', (slot,))
                if not claim.rowcount:
                    return None
            db.execute('REPLACE INTO monitor_lock (singleton,owner,expiration) VALUES (1,?,?)', (owner, now+1800))
            self.put(db, {'last_start': utc_stamp(), 'last_ok': '', 'last_note': 'Проверяем расписание…'})
        return owner

    def finish_check(self, owner: str, ok: bool, note: str) -> None:
        with self.write() as db:
            claimed = db.execute('DELETE FROM monitor_lock WHERE singleton=1 AND owner=?', (owner,))
            if claimed.rowcount:
                self.put(db, {'last_finish': utc_stamp(), 'last_ok': '1' if ok else '0', 'last_note': note})

    def monitor(self) -> dict:
        now = time()
        with closing(self.connect()) as db:
            meta = dict(db.execute('SELECT key,value FROM monitor_meta'))
            checking = db.execute('SELECT 1 FROM monitor_lock WHERE singleton=1 AND expiration>?', (now,)).fetchone() is not None
        return {'running': float(meta.get('service_until', 0)) > now, 'checking': checking,
                'last_start': meta.get('last_start'), 'last_finish': meta.get('last_finish'),
                'last_ok': meta.get('last_ok') == '1' if meta.get('last_ok') else None, 'last_note': meta.get('last_note'),
                'pending': len(self.pending())}
