"""Telegram Bot API: локальная конфигурация, привязка личного чата и отправка."""
from __future__ import annotations

import json
import os
import re
import secrets
from dataclasses import dataclass, field
from pathlib import Path
from tempfile import NamedTemporaryFile
from time import monotonic, sleep

import requests

TOKEN_RE = re.compile(r'[0-9]{5,20}:[A-Za-z0-9_-]{20,100}')
TOKEN_ENV = 'CMK_TELEGRAM_TOKEN'
CHAT_ENV = 'CMK_TELEGRAM_CHAT_ID'
CONFIG = 'telegram.json'


class TelegramError(RuntimeError):
    pass


@dataclass(frozen=True)
class TelegramConfig:
    token: str = field(repr=False)
    chat_id: int


def check_token(value: str) -> str:
    if not isinstance(value, str) or not TOKEN_RE.fullmatch(value.strip()):
        raise TelegramError('Токен бота неверного формата. Получите новый в BotFather.')
    return value.strip()


def check_chat(value: object) -> int:
    if not re.fullmatch(r'-?[0-9]{1,20}', str(value or '').strip()):
        raise TelegramError('Нужен числовой ID чата Telegram.')
    chat = int(str(value).strip())
    if not chat or abs(chat) >= 2**63:
        raise TelegramError('Нужен действительный ID чата Telegram.')
    return chat


def managed_by_env() -> bool:
    return TOKEN_ENV in os.environ or CHAT_ENV in os.environ


def configured(directory: Path) -> bool:
    if managed_by_env():
        return bool(os.environ.get(TOKEN_ENV) and os.environ.get(CHAT_ENV))
    return (directory / CONFIG).is_file()


def read_config(directory: Path) -> TelegramConfig | None:
    if managed_by_env():
        if not os.environ.get(TOKEN_ENV) or not os.environ.get(CHAT_ENV):
            raise TelegramError('Задайте обе переменные: CMK_TELEGRAM_TOKEN и CMK_TELEGRAM_CHAT_ID.')
        return TelegramConfig(check_token(os.environ[TOKEN_ENV]), check_chat(os.environ[CHAT_ENV]))
    config = directory / CONFIG
    try:
        raw = json.loads(config.read_text(encoding='utf-8'))
    except FileNotFoundError:
        return None
    except (ValueError, OSError):
        raise TelegramError('Не удалось прочитать локальные настройки Telegram. Выполните привязку заново.') from None
    if not isinstance(raw, dict):
        raise TelegramError('Некорректные настройки Telegram. Выполните привязку заново.')
    return TelegramConfig(check_token(raw.get('token')), check_chat(raw.get('chat_id')))


def write_config(directory: Path, config: TelegramConfig) -> None:
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    name = None
    try:
        # The temp file is user-only on POSIX; replace atomically after the bot's test response.
        with NamedTemporaryFile('w', dir=directory, encoding='utf-8', prefix='.telegram-', delete=False) as tmp:
            name = Path(tmp.name)
            json.dump({'token': config.token, 'chat_id': config.chat_id}, tmp)
            tmp.flush()
            os.fsync(tmp.fileno())
        os.replace(name, directory / CONFIG)
    except OSError:
        raise TelegramError('Не удалось сохранить настройки Telegram в локальной папке данных.') from None
    finally:
        if name is not None:
            name.unlink(missing_ok=True)


class Bot:
    def __init__(self, token: str):
        self._token = check_token(token)

    def request(self, method: str, payload: dict | None = None, *, read_timeout: int = 20):
        # Bot API necessarily carries its token in the HTTPS path. Never log that path,
        # pass on raw exceptions or follow a redirect carrying authentication material.
        try:
            r = requests.post(f'https://api.telegram.org/bot{self._token}/{method}',
                              json=payload or {}, timeout=(8, read_timeout), allow_redirects=False)
            data = r.json()
        except (requests.RequestException, ValueError):
            raise TelegramError('Нет связи с Telegram. Проверьте сеть и попробуйте снова.') from None
        if r.status_code == 200 and isinstance(data, dict) and data.get('ok') is True and 'result' in data:
            return data['result']
        error = data.get('error_code', r.status_code) if isinstance(data, dict) else r.status_code
        if error in (401, 404):
            raise TelegramError('Telegram отклонил токен. Перевыпустите его или выполните привязку заново.')
        if error in (403, 400) and method == 'sendMessage':
            raise TelegramError('Бот не смог написать в указанный чат. Нажмите «Запустить» у бота и проверьте привязку.')
        if error == 409:
            raise TelegramError('Этот бот уже использует webhook или другой приёмник. Для привязки возьмите отдельного бота или задайте chat ID вручную.')
        if error == 429:
            raise TelegramError('Telegram временно ограничил отправку. Повторите позже.')
        raise TelegramError('Telegram не подтвердил запрос. Уведомление будет доступно для повтора.')

    def send(self, chat_id: int, text: str) -> None:
        self.request('sendMessage', {'chat_id': check_chat(chat_id), 'text': text,
                                     'link_preview_options': {'is_disabled': True}})

    def username(self) -> str:
        me = self.request('getMe')
        name = me.get('username') if isinstance(me, dict) else None
        if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z0-9_]{4,32}', name):
            raise TelegramError('Telegram не вернул имя бота.')
        return name

    def pair_private(self, on_code, *, seconds: int = 180, cancelled=lambda: False) -> int:
        if cancelled():
            raise TelegramError('Привязка отменена.')
        name = self.username()
        if cancelled():
            raise TelegramError('Привязка отменена.')
        nonce = 'CMK-' + secrets.token_hex(5).upper()
        on_code(name, nonce)
        end, offset = monotonic() + seconds, 0
        while monotonic() < end and not cancelled():
            polling = max(1, min(10, int(end - monotonic())))
            updates = self.request('getUpdates', {'offset': offset, 'timeout': polling, 'allowed_updates': ['message']},
                                   read_timeout=polling + 8)
            if cancelled():
                raise TelegramError('Привязка отменена.')
            if not isinstance(updates, list):
                raise TelegramError('Telegram вернул неверный список сообщений.')
            for item in updates:
                if not isinstance(item, dict) or not isinstance(item.get('update_id'), int):
                    continue
                offset = max(offset, item['update_id'] + 1)
                msg = item.get('message')
                if not isinstance(msg, dict) or str(msg.get('text', '')).strip() != nonce:
                    continue
                chat = msg.get('chat')
                if isinstance(chat, dict) and chat.get('type') == 'private':
                    return check_chat(chat.get('id'))
            if not updates:
                sleep(.15)
        if cancelled():
            raise TelegramError('Привязка отменена.')
        raise TelegramError('Код не получен. Откройте личный чат с ботом и повторите привязку.')
