@echo off
chcp 65001 >nul
cd /d "%~dp0"
setlocal
set "CPY=python"
where py >nul 2>nul
if not errorlevel 1 set "CPY=py -3"
%CPY% -c "import sys; assert sys.version_info >= (3,10)" >nul 2>nul
if errorlevel 1 goto :python_missing
if not exist ".venv\Scripts\python.exe" (
  echo Создаём локальное окружение Python...
  %CPY% -m venv .venv
  if errorlevel 1 goto :failed
)
".venv\Scripts\python.exe" -c "import bs4, requests, docx" >nul 2>nul
if errorlevel 1 (
  echo Устанавливаем зависимости генератора...
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 goto :failed
)
".venv\Scripts\python.exe" %*
if errorlevel 1 goto :failed
exit /b 0
:python_missing
echo Установите Python 3.10 или новее. Затем повторите запуск.
pause
exit /b 1
:failed
echo Не удалось выполнить команду. Подробности показаны выше.
pause
exit /b 1
