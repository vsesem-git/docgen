"""Чтение публичных карточек, витрины и навигации web-kodeks.ru."""
from __future__ import annotations

import copy
import re
from dataclasses import dataclass
from datetime import date, time
from typing import Callable
from urllib.parse import urljoin, urlsplit, urlunsplit

import requests
from bs4 import BeautifulSoup, Tag
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


HOME = 'http://www.web-kodeks.ru/'
HOSTS = {'web-kodeks.ru', 'www.web-kodeks.ru'}
MONTHS = ('января февраля марта апреля мая июня июля августа сентября октября ноября декабря').split()
DATE_PATTERN = re.compile(r'(?<!\d)(\d{1,2})\s+(' + '|'.join(MONTHS) + r')\s+(20\d\d)(?!\d)', re.I)
RANGE_PATTERN = re.compile(r'(\d{1,2}[:.]\d{2})\s*(?:до|[–—−-])\s*(\d{1,2}[:.]\d{2})', re.I)


class SourceError(ValueError):
    """Страница не даёт надёжно извлечь обязательные данные."""


@dataclass(frozen=True)
class ListingItem:
    url: str
    title: str = ''
    day: date | None = None
    date_text: str = ''


@dataclass(frozen=True)
class Topic:
    title: str
    details: str


@dataclass(frozen=True)
class Event:
    url: str
    menu_title: str
    title: str
    kind: str
    with_whom: str
    day: date
    start: time
    end: time
    abstract: str
    audience: str
    speakers: tuple[tuple[str, str], ...]
    topics: tuple[Topic, ...]
    closing: str
    fee: str
    access_and_discounts: str
    warnings: tuple[str, ...]

    @property
    def day_month(self) -> str:
        return f'{self.day.day} {MONTHS[self.day.month - 1]}'

    @property
    def date_ru(self) -> str:
        return f'{self.day_month} {self.day.year} года'

    @property
    def hours(self) -> str:
        return f'{self.start:%H:%M}–{self.end:%H:%M}'

    @property
    def slug(self) -> str:
        return urlsplit(self.url).path.strip('/').split('/')[-1]


def normalize(s: str) -> str:
    s = re.sub(r'\s+', ' ', s).strip()
    return re.sub(r' +([,.;:!?])', r'\1', s)


def proofread(s: str) -> str:
    # Только явные опечатки из расписания. Содержательные факты не заменяются.
    swaps = {
        'обспечение': 'обеспечение',
        'земельно-правововым': 'земельно-правовым',
        'гособронзаказа': 'гособоронзаказа',
        'XML-cхем': 'XML-схем',
        'требования к обустройству и обслуживания': 'требования к обустройству и обслуживанию',
        'Требования к обустройству и обслуживания': 'Требования к обустройству и обслуживанию',
        'при обращения с коммунальными отходами': 'при обращении с коммунальными отходами',
        'Рекомендацию по ведению': 'Рекомендации по ведению',
        'нежилых помещениям': 'нежилых помещений',
        'I-м квартале': 'I квартале',
        'бразузеры': 'браузеры',
        'Google Chromе': 'Google Chrome',
        'промышленой экологии': 'промышленной экологии',
    }
    for old, new in swaps.items():
        s = s.replace(old, new)
    if s.startswith('словия '):
        s = 'У' + s
    return s


def text(node: Tag, omit: str | None = None) -> str:
    if omit:
        node = copy.copy(node)
        for part in node.select(omit):
            part.decompose()
    return proofread(normalize(node.get_text(' ', strip=True)))


def same_site(value: str, base: str = HOME) -> str:
    value = value.strip()
    u = urlsplit(urljoin(base, value))
    if (u.scheme not in {'http', 'https'} or u.hostname not in HOSTS
            or u.username or u.password or u.port not in {None, 80, 443}):
        raise SourceError(f'Ожидалась ссылка на web-kodeks.ru: {value!r}')
    return urlunsplit((u.scheme, u.netloc.lower(), u.path or '/', u.query, ''))


def canonical_event(value: str) -> str:
    u = urlsplit(same_site(value))
    if not u.path.strip('/'):
        raise SourceError('Ожидалась ссылка на карточку вебинара, а не на главную.')
    # Главная сайта публикует карточки на HTTP; не угадываем внешние адреса.
    return urlunsplit(('http', 'www.web-kodeks.ru', u.path.rstrip('/'), u.query, ''))


def session() -> requests.Session:
    s = requests.Session()
    retry = Retry(total=2, connect=2, read=2, status=2, backoff_factor=.5,
                  status_forcelist=(429, 500, 502, 503, 504), allowed_methods={'GET'})
    s.mount('http://', HTTPAdapter(max_retries=retry))
    s.mount('https://', HTTPAdapter(max_retries=retry))
    s.headers['User-Agent'] = 'KodeksWebinarProgram/1.0 (public webinar schedule reader)'
    return s


def download(s: requests.Session, url: str) -> requests.Response:
    for _ in range(4):
        url = same_site(url)
        r = s.get(url, timeout=(6, 20), allow_redirects=False)
        if r.is_redirect:
            url = same_site(r.headers['Location'], base=url)
            continue
        r.raise_for_status()
        return r
    raise SourceError(f'Слишком много переадресаций: {url}')


def listing(s: requests.Session) -> list[ListingItem]:
    home = download(s, HOME)
    html = home.content.decode('utf-8-sig')
    # Именно этот JSON загружает интерфейс «Ближайшие вебинары».
    endpoint = re.search(r'''(?:['"])([\w/.-]*getWebs\.php)(?:['"])''', html, re.I)
    if endpoint:
        raw = download(s, same_site(endpoint[1], base=home.url)).json()
        found = schedule_rows(raw)
    else:
        html = BeautifulSoup(html, 'html.parser')
        courses = html.select_one('ul.js-get-webinars, ul.mainpage__vebinars__menu')
        if courses is None or re.search(r'display\s*:\s*none', courses.get('style', ''), re.I):
            raise SourceError('Актуальный список на главной не найден. Укажите адрес карточки вручную.')
        found = []
        for a in courses.select('a[href]'):
            label, title = a.select_one('.date'), a.select_one('.underline')
            if label and title:
                found.append(ListingItem(canonical_event(a['href']), text(title), date_text=text(label)))
    if not found:
        raise SourceError('На главной нет опубликованных вебинаров.')
    unique: dict[str, ListingItem] = {}
    for entry in found:
        if entry.url in unique and unique[entry.url] != entry:
            raise SourceError(f'Одна карточка указана для разных записей: {entry.url}')
        unique[entry.url] = entry
    return list(unique.values())


def timestamp(s: str) -> time:
    h, m = (int(x) for x in re.split(r'[:.]', s))
    return time(h, m)


def parse_range(line: str) -> tuple[time, time] | None:
    m = RANGE_PATTERN.search(line)
    return (timestamp(m[1]), timestamp(m[2])) if m else None


def validate_format(soup: BeautifulSoup, hours: tuple[time, time]) -> None:
    blocks = [text(n.parent, '.place__title') for n in soup.select('#tab3 + .place .place__title')]
    repeated_hours = parse_range(' '.join(blocks))
    if repeated_hours and repeated_hours != hours:
        raise SourceError('Время в шапке отличается от времени в разделе «Формат».')


def parse_event(html: bytes | str, item: ListingItem) -> Event:
    if isinstance(html, bytes):
        html = html.decode('utf-8-sig')
    soup = BeautifulSoup(html, 'html.parser')
    mast = soup.select_one('.first-frame__content:has(.first-frame__content__title)')
    if mast is None:
        raise SourceError('Нет заголовка карточки вебинара.')
    full_title = text(mast.select_one('.first-frame__content__title'))
    meta = [text(t) for t in mast.select('.first-frame__content__text')]
    timing = next((m for m in meta if DATE_PATTERN.search(m) and parse_range(m)), '')
    dm, hours = DATE_PATTERN.search(timing), parse_range(timing)
    if not dm or not hours or hours[1] <= hours[0] or 'московск' not in timing.casefold():
        raise SourceError('Не удалось подтвердить полную дату и время трансляции по Москве.')
    day = date(int(dm[3]), MONTHS.index(dm[2].lower()) + 1, int(dm[1]))
    if item.day and item.day != day:
        raise SourceError(f'Дата в списке ({item.day}) не совпадает с карточкой ({day}).')
    if item.date_text and not re.match(rf'^0?{day.day}\s+{MONTHS[day.month - 1]}\b', item.date_text, re.I):
        raise SourceError(f'Дата в списке («{item.date_text}») не совпадает с карточкой ({day}).')

    kind_line = next((m for m in meta if m != timing and 'вебинар' in m.lower()), '')
    kind, _, who = kind_line.partition(' с участием ')
    columns = soup.select('#conception > .layout > .clearfix > .content__half-col')
    if len(columns) < 2:
        raise SourceError('Не найдены аннотация и описание аудитории.')
    abstract, about = (text(n, '.h5') for n in columns[:2])
    audience_text = re.split(r'\s*В работе вебинара\b', about, maxsplit=1)[0]
    audience_match = re.search(r'\b(руководителей|специалистов|представителей|работников)\b.*', audience_text, re.I)
    audience = 'Для ' + audience_match[0].rstrip('.') + '.' if audience_match else audience_text

    speakers = []
    for n in soup.select('.experts .expert__item'):
        name_n = n.select_one('.expert__item__name')
        role = text(n, '.expert__item__name')
        if name_n and text(name_n) and role:
            speakers.append((text(name_n), role.rstrip(' .;') + '.'))
        elif text(n):
            raise SourceError('В карточке эксперта нет имени или описания должности.')

    topics, closing = [], []
    for n in soup.select('.programm .programm__item'):
        label = n.select_one('.programm__item__title')
        if label is None:
            continue
        name, details = text(label), text(n, '.programm__item__title')
        if re.match(r'^(ответы на вопросы|практические рекомендации)\b', name, re.I) and not details:
            closing.append(name.strip(' .;:').lower())
        elif name:
            topics.append(Topic(name, details))
    if not (full_title and kind and abstract and audience and speakers and topics):
        raise SourceError('Не найден один из обязательных блоков: название, описание, аудитория, эксперты или программа.')

    warnings = []
    fee = extra = ''
    for n in soup.select('.conditions .conditions__text__item'):
        h = n.select_one('.conditions__text__title')
        if h is None:
            continue
        heading, details = text(h).casefold(), text(n, '.conditions__text__title')
        if 'стоимост' in heading:
            cost, inclusion, tail = details.partition('Участие в вебинаре включает в себя:')
            fee, extra = cost.strip(), ('В стоимость входит: ' + tail.strip()) if inclusion else ''
    if not fee:
        warnings.append('На странице не найдена стоимость; в документе она не указана.')
    validate_format(soup, hours)
    return Event(item.url, item.title, full_title, kind, who, day, *hours, abstract,
                 audience, tuple(speakers), tuple(topics), ' и '.join(dict.fromkeys(closing)),
                 fee, extra, tuple(warnings))


def schedule_rows(raw: object) -> list[ListingItem]:
    """Порядок $.each: ключи-индексы JS идут по номеру, остальные — в порядке ответа."""
    if isinstance(raw, dict):
        indices = sorted(
            (k for k in raw if re.fullmatch(r'0|[1-9]\d{0,9}', k) and int(k) < 2**32 - 1),
            key=int,
        )
        numeric = set(indices)
        rows = [raw[k] for k in indices] + [v for k, v in raw.items() if k not in numeric]
    elif isinstance(raw, list):
        rows = raw
    else:
        raise SourceError('Неизвестный формат списка вебинаров.')
    values = []
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get('url'), str) or not row['url'].strip():
            raise SourceError('В расписании есть запись без ссылки.')
        day = date.fromisoformat(row['date']) if row.get('date') else None
        values.append(ListingItem(canonical_event(row['url']), normalize(row.get('title') or ''),
                                  day, normalize(row.get('dateText') or '')))
    return values


def inert(href: str) -> bool:
    value = re.sub(r'\s+', '', href).lower().rstrip(';')
    return value in {'', '#', 'javascript:void(0)', 'javascript:void0'}


def navigation(s: requests.Session, page: BeautifulSoup, base: str) -> list[ListingItem]:
    """Повторить чтение данных, которое /js/script.js делает для кнопок перехода."""
    script = next((script for script in page.select('script[src]')
                   if urlsplit(script['src']).path.endswith('/js/script.js')), None)
    if script is None:
        raise SourceError('Кнопка неактивна, но скрипт навигации не найден; конец цепочки не подтверждён.')
    code = download(s, same_site(script['src'], base)).content.decode('utf-8-sig')
    endpoint = re.search(r'''['"]([\w./-]*getWebs2\.php)['"]''', code)
    if not endpoint or not re.search(r'\ball\s*:\s*true\b', code) or '.js-next' not in code:
        raise SourceError('Навигация сайта изменилась; конец цепочки не подтверждён.')
    url = same_site(endpoint[1] + '?all=true', base)
    values = schedule_rows(download(s, url).json())
    if not values:
        raise SourceError('Сайт вернул пустую навигацию; конец цепочки не подтверждён.')
    return values


def following(s: requests.Session, *, start: str | None = None, max_pages: int = 180,
              home_items: list[ListingItem] | None = None,
              on_page: Callable[[int], None] | None = None) -> list[tuple[ListingItem, bytes]]:
    """От первой карточки на главной (либо --start) до подтверждённого конца кнопки «следующий»."""
    on_home = (listing(s) if home_items is None else home_items) if start is None else []
    if start is None and not on_home:
        raise SourceError('На главной нет опубликованных вебинаров.')
    current = on_home[0] if on_home else ListingItem(canonical_event(start))
    homepage = {i.url: i for i in on_home}
    catalog = None
    result = []
    visited = set()
    while True:
        if current.url in visited:
            raise SourceError(f'Цикл в кнопке «Следующий вебинар»: повтор {current.url}.')
        if len(visited) >= max_pages:
            raise SourceError(f'Достигнут предел {max_pages} карточек; конец цепочки не подтверждён.')
        visited.add(current.url)
        address = current.url
        try:
            response = download(s, current.url)
            page = BeautifulSoup(response.content.decode('utf-8-sig'), 'html.parser')
            button = page.select_one('a.js-next')
            if button is None:
                button = next((a for a in page.select('.first-frame__bottom a[href]')
                               if text(a).casefold() == 'следующий вебинар'), None)
            if button is None:
                raise SourceError('Кнопка «Следующий вебинар» не найдена; конец цепочки не подтверждён.')
            href = button.get('href', '')
            if inert(href):
                if catalog is None:
                    catalog = navigation(s, page, response.url)
                meta = page.select_one('meta[name=date][content]')
                if meta is None:
                    raise SourceError('У карточки нет даты для сопоставления с навигацией.')
                day = date.fromisoformat(meta['content'])
                # JS перебирает весь список: при совпадении даты берёт последнее совпадение.
                indices = [i for i, item in enumerate(catalog) if item.day == day]
                if not indices:
                    raise SourceError('Даты карточки нет в навигации; конец цепочки не подтверждён.')
                i = indices[-1]
                recorded = catalog[i]
                if recorded.url not in {current.url, canonical_event(response.url)}:
                    raise SourceError('Дата найдена у другой карточки в навигации; проверьте дубли в расписании.')
                if current.day is not None and current.day != recorded.day:
                    raise SourceError(f'Даты витрины и навигации отличаются: {current.day} / {recorded.day}.')
                result.append((recorded, response.content))
                if on_page:
                    on_page(len(result))
                if i == len(catalog) - 1:
                    break
                current = catalog[i + 1]
            else:
                # Также поддерживается уже подставленный реальный href.
                result.append((current, response.content))
                if on_page:
                    on_page(len(result))
                nxt = canonical_event(same_site(href, response.url))
                current = homepage.get(nxt, ListingItem(nxt))
        except (requests.RequestException, ValueError, TypeError, KeyError) as exc:
            raise SourceError(f'{address}: {exc}') from exc
    missing = homepage.keys() - {item.url for item, _ in result}
    if missing:
        raise SourceError('Цепочка не охватила карточки с главной: ' + ', '.join(sorted(missing)))
    return result
