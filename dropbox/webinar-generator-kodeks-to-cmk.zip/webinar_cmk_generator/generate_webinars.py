#!/usr/bin/env python3
"""Пройти цепочку «Следующий вебинар» и собрать программы по шаблону ЦМК."""
from __future__ import annotations

import argparse
import json
import re
import sqlite3
import sys
from collections import Counter
from datetime import date
from pathlib import Path

import requests

from site_kodeks import (ListingItem, SourceError, canonical_event, download,
                         following, normalize, parse_event, session)

ROOT = Path(__file__).resolve().parent


def safe_filename(value: str) -> str:
    value = re.sub(r'[:/\\|]+', ' — ', value)
    return normalize(re.sub(r'["<>?*\x00-\x1f]', '', value)).strip(' .')[:175].rstrip(' .')


def main(argv: list[str] | None = None) -> int:
    cli = argparse.ArgumentParser(description=__doc__)
    start = cli.add_mutually_exclusive_group()
    start.add_argument('--start', help='начать цепочку с указанной карточки вместо первой на главной')
    start.add_argument('--url', action='append', default=[], help='скачать только указанные карточки; флаг можно повторять')
    cli.add_argument('--list', action='store_true', help='показать найденные карточки, ничего не записывать')
    cli.add_argument('--from-date', type=date.fromisoformat, help='дата от (включительно), ГГГГ-ММ-ДД')
    cli.add_argument('--to-date', type=date.fromisoformat, help='дата до (включительно), ГГГГ-ММ-ДД')
    cli.add_argument('--output', type=Path, default=Path('programmy-cmk'), help='папка для DOCX; существующие файлы не заменяются')
    cli.add_argument('--template', type=Path, default=ROOT / 'layout-cmk.docx', help='копия утверждённого Word-шаблона ЦМК')
    cli.add_argument('--editorial', type=Path, default=ROOT / 'editorial.json', help='редакторские уточнения для известных карточек')
    cli.add_argument('--data-dir', type=Path, help='общая папка истории GUI и консольного режима')
    args = cli.parse_args(argv)
    if args.from_date and args.to_date and args.from_date > args.to_date:
        cli.error('--from-date должна быть не позже --to-date')
    try:
        with session() as s:
            if args.url:
                items = dict.fromkeys(canonical_event(url) for url in args.url)
                pages = [(ListingItem(u), download(s, u).content) for u in items]
            else:
                pages = following(s, start=args.start)
        events, errors = [], []
        for item, html in pages:
            try:
                event = parse_event(html, item)
            except (ValueError, TypeError, KeyError) as exc:
                errors.append(f'{item.url}: {exc}')
                continue
            if (args.from_date and event.day < args.from_date) or (args.to_date and event.day > args.to_date):
                continue
            events.append(event)
        if args.url:
            events.sort(key=lambda e: (e.day, e.start, e.url))
        for error in errors:
            print('Ошибка: ' + error, file=sys.stderr)
        if errors:
            print('Не все карточки подтверждены. Файлы не созданы.', file=sys.stderr)
            return 1
        if args.list:
            for e in events:
                print(f'{e.date_ru}, {e.hours} МСК | {e.menu_title or e.title} | {e.url}')
            print(f'Найдено: {len(events)}. Word-файлы не создавались.')
            return 0
        if not events:
            print('В выбранном диапазоне дат нет карточек.')
            return 0
        from cmk_docx import plain_title, render
        from storage import Store, data_dir
        if not args.template.is_file():
            raise SourceError('Не найден Word-шаблон ЦМК.')
        edits = json.loads(args.editorial.read_text(encoding='utf-8'))
        if not isinstance(edits, dict) or not all(isinstance(item, dict) for item in edits.values()):
            raise SourceError('В редакторском JSON ожидались настройки, привязанные к дате и коду карточки.')
        def editor(e):
            return edits.get(f'{e.day.isoformat()}/{e.slug}', {})
        stems = {e.url: safe_filename(f'{e.day_month} - {editor(e).get("file_title") or e.menu_title or plain_title(e.title)}')
                 for e in events}
        counts = Counter(v.casefold() for v in stems.values())
        history = Store(data_dir(args.data_dir))
        args.output.mkdir(parents=True, exist_ok=True)
        done = 0
        for e in events:
            name = stems[e.url]
            if counts[name.casefold()] > 1:
                name += ' — ' + safe_filename(e.slug)
            dest = args.output / (name + '.docx')
            try:
                render(e, dest, args.template, editor(e))
            except FileExistsError:
                errors.append(f'{dest}: файл уже есть; выберите другую папку (--output).')
                continue
            except (OSError, ValueError, KeyError, TypeError) as exc:
                errors.append(f'{dest}: {exc}')
                continue
            done += 1
            print(dest.name)
            try:
                history.save_programs([(e, dest.name, dest.read_bytes())])
            except (sqlite3.Error, OSError):
                errors.append(f'{dest.name}: Word создан, но запись в историю не сохранилась.')
            for note in e.warnings:
                print(f'  Внимание: {note}', file=sys.stderr)
        for error in errors:
            print('Ошибка: ' + error, file=sys.stderr)
        print(f'Готово: {done} DOCX. Ошибок: {len(errors)}.')
        return 1 if errors else 0
    except (OSError, ValueError, TypeError, KeyError, requests.RequestException, sqlite3.Error) as exc:
        print(f'Ошибка: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
