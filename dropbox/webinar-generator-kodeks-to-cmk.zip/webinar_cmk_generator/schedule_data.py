"""Общий проверенный каталог для панели и фонового наблюдения."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Callable
from urllib.parse import urlsplit

import requests

from site_kodeks import (Event, ListingItem, SourceError, Topic, download, following,
                         listing, parse_event, session)

ROOT = Path(__file__).resolve().parent
MOSCOW = timezone(timedelta(hours=3), 'МСК')
CHECK_TIMES = (time(7, 0), time(13, 30), time(20, 0))


def utc_stamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def event_key(event: Event) -> str:
    path = urlsplit(event.url).path.rstrip('/')
    return event.day.isoformat() + path


@dataclass(frozen=True)
class Schedule:
    entries: tuple[Event, ...]
    home: frozenset[str] | None
    checked_at: str | None
    origin: str = 'live'

    def to_json(self) -> str:
        return json.dumps({
            'checked_at': self.checked_at,
            'homepage': sorted(self.home) if self.home is not None else None,
            'webinars': [asdict(e) for e in self.entries],
        }, ensure_ascii=False, separators=(',', ':'), default=lambda v: v.isoformat())

    @classmethod
    def from_json(cls, value: str, origin: str = 'live') -> Schedule:
        raw = json.loads(value)
        events = []
        for p in raw['webinars']:
            props = dict(p)
            props['day'] = date.fromisoformat(props['day'])
            props['start'], props['end'] = time.fromisoformat(props['start']), time.fromisoformat(props['end'])
            props['topics'] = tuple(Topic(**t) for t in props['topics'])
            props['speakers'] = tuple(map(tuple, props['speakers']))
            props['warnings'] = tuple(props['warnings'])
            events.append(Event(**props))
        home = frozenset(raw['homepage']) if raw['homepage'] is not None else None
        return cls(tuple(events), home, raw['checked_at'], origin)


def load_snapshot() -> Schedule:
    source = ROOT / 'catalog_snapshot.json'
    if not source.is_file():
        return Schedule((), None, None, 'empty')
    return Schedule.from_json(source.read_text(encoding='utf-8'), 'snapshot')


def fetch_schedule(*, mode: str = 'chain', start: str | None = None,
                   on_page: Callable[[int], None] | None = None) -> Schedule:
    with session() as s:
        home_info = None
        if mode == 'single':
            if not start:
                raise SourceError('Для одного вебинара нужен адрес карточки.')
            pages = [(ListingItem(start), download(s, start).content)]
            if on_page:
                on_page(1)
        elif start:
            pages = following(s, start=start, on_page=on_page)
        else:
            home_info = listing(s)
            pages = following(s, home_items=home_info, on_page=on_page)
        if home_info is None:
            try:
                home_info = listing(s)
            except (requests.RequestException, ValueError, TypeError, KeyError):
                # A missing home marker must not hide a verified manually picked card.
                pass
    verified = []
    for item, html in pages:
        try:
            verified.append(parse_event(html, item))
        except (ValueError, TypeError, KeyError) as exc:
            raise SourceError(f'{item.url}: {exc}') from exc
    if not verified:
        raise SourceError('Карточки не найдены.')
    return Schedule(tuple(verified), None if home_info is None else frozenset(x.url for x in home_info), utc_stamp())


def due_slot(now: datetime) -> datetime | None:
    """Запуск только в минуту слота; пропуск не вызывает серию проверок задним числом."""
    local = now.astimezone(MOSCOW)
    minute = local.replace(second=0, microsecond=0)
    return minute if minute.time() in CHECK_TIMES else None


def next_slot(now: datetime) -> datetime:
    local = now.astimezone(MOSCOW)
    for start in CHECK_TIMES:
        slot = datetime.combine(local.date(), start, MOSCOW)
        if slot > local:
            return slot
    return datetime.combine(local.date() + timedelta(days=1), CHECK_TIMES[0], MOSCOW)
