@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Мониторинг вебинаров ЦМК
echo [1] Подключить бота и отправить тест
echo [2] Запустить мониторинг по расписанию
echo [3] Проверить новые вебинары сейчас
choice /C 123 /N /M "Выберите действие: "
if errorlevel 255 goto :end
if errorlevel 3 goto :once
if errorlevel 2 goto :scheduled
if errorlevel 1 goto :connect
goto :end
:connect
call "%~dp0_run.cmd" watchdog.py --connect
pause
goto :end
:scheduled
call "%~dp0_run.cmd" watchdog.py
exit /b %errorlevel%
:once
call "%~dp0_run.cmd" watchdog.py --once
pause
:end
exit /b
